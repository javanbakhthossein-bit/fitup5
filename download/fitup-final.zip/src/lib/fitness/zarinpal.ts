/**
 * Zarinpal Payment Gateway helper
 * Docs: https://www.zarinpal.com/docs/paymentGateway/
 *
 * Amount unit: Tomans (تومان) — Zarinpal uses تومان, not ریال
 * Test mode: merchant_id = "TEST" — API calls will fail/sandbox, simulated fallback used
 * Production: replace process.env.ZARINPAL_MERCHANT_ID with real merchant UUID
 */

const ZARINPAL_REQUEST_URL = "https://api.zarinpal.com/pg/v4/payment/request.json";
const ZARINPAL_VERIFY_URL = "https://api.zarinpal.com/pg/v4/payment/verify.json";
const ZARINPAL_STARTPAY_URL = "https://www.zarinpal.com/pg/StartPay";

export interface ZarinpalRequestParams {
  amount: number; // Tomans
  description: string;
  callbackUrl: string;
  mobile?: string;
}

export interface ZarinpalRequestResult {
  ok: boolean;
  authority: string | null;
  gatewayUrl: string | null;
  code: number | null;
  error?: string;
}

/**
 * Calls Zarinpal request API to create a new payment authority.
 * Returns ok=false (no authority) if the API call fails — caller should fall back to simulated flow.
 */
export async function zarinpalRequest({
  amount,
  description,
  callbackUrl,
  mobile,
}: ZarinpalRequestParams): Promise<ZarinpalRequestResult> {
  const merchantId = process.env.ZARINPAL_MERCHANT_ID;

  if (!merchantId) {
    return {
      ok: false,
      authority: null,
      gatewayUrl: null,
      code: null,
      error: "ZARINPAL_MERCHANT_ID not configured",
    };
  }

  const body: Record<string, unknown> = {
    merchant_id: merchantId,
    amount,
    description,
    callback_url: callbackUrl,
  };
  if (mobile) {
    body.metadata = { mobile };
  }

  try {
    const res = await fetch(ZARINPAL_REQUEST_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      cache: "no-store",
    });

    const data = await res.json();

    // Zarinpal response shape: { data: { authority, code }, errors: [...] }
    if (data?.data?.authority && data?.data?.code === 100) {
      const authority = data.data.authority as string;
      return {
        ok: true,
        authority,
        gatewayUrl: `${ZARINPAL_STARTPAY_URL}/${authority}`,
        code: data.data.code,
      };
    }

    // Errors array is present when something went wrong
    const errMsg = Array.isArray(data?.errors) && data.errors[0]
      ? (data.errors[0].message ?? "Zarinpal request failed")
      : "Zarinpal request failed";

    return {
      ok: false,
      authority: null,
      gatewayUrl: null,
      code: data?.data?.code ?? null,
      error: errMsg,
    };
  } catch (e) {
    return {
      ok: false,
      authority: null,
      gatewayUrl: null,
      code: null,
      error: e instanceof Error ? e.message : "Network error",
    };
  }
}

export interface ZarinpalVerifyParams {
  authority: string;
  amount: number; // Tomans — must match the original request
}

export interface ZarinpalVerifyResult {
  ok: boolean;
  code: number | null;
  refId: string | null;
  cardPan?: string | null;
  cardHash?: string | null;
  error?: string;
  alreadyVerified?: boolean;
}

/**
 * Calls Zarinpal verify API to confirm a payment.
 * code === 100 → success
 * code === 101 → already verified (treated as success)
 * anything else → failure
 */
export async function zarinpalVerify({
  authority,
  amount,
}: ZarinpalVerifyParams): Promise<ZarinpalVerifyResult> {
  const merchantId = process.env.ZARINPAL_MERCHANT_ID;

  if (!merchantId) {
    return {
      ok: false,
      code: null,
      refId: null,
      error: "ZARINPAL_MERCHANT_ID not configured",
    };
  }

  try {
    const res = await fetch(ZARINPAL_VERIFY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        merchant_id: merchantId,
        authority,
        amount,
      }),
      cache: "no-store",
    });

    const data = await res.json();

    // Success codes
    const code = data?.data?.code;
    if (code === 100 || code === 101) {
      return {
        ok: true,
        code,
        refId: data?.data?.ref_id != null ? String(data.data.ref_id) : null,
        cardPan: data?.data?.card_pan ?? null,
        cardHash: data?.data?.card_hash ?? null,
        alreadyVerified: code === 101,
      };
    }

    const errMsg = Array.isArray(data?.errors) && data.errors[0]
      ? (data.errors[0].message ?? "Zarinpal verify failed")
      : "Zarinpal verify failed";

    return {
      ok: false,
      code: code ?? null,
      refId: null,
      error: errMsg,
    };
  } catch (e) {
    return {
      ok: false,
      code: null,
      refId: null,
      error: e instanceof Error ? e.message : "Network error",
    };
  }
}

/**
 * Returns true if a real merchant ID is configured (i.e., not the "TEST" placeholder).
 * Used to decide whether to attempt the real API or skip straight to simulated flow.
 */
export function isZarinpalConfigured(): boolean {
  const m = process.env.ZARINPAL_MERCHANT_ID;
  return !!m && m !== "TEST";
}

/**
 * Builds the callback URL Zarinpal should redirect to after the user pays.
 * Uses the current request's origin + ?payment_verify=1 so the client can detect the return.
 */
export function buildCallbackUrl(origin: string): string {
  return `${origin}/?payment_verify=1`;
}
