import { db } from "@/lib/db";

/**
 * Create a notification for a user.
 *
 * @param userId  Target user id
 * @param type    Notification type (welcome | workout_reminder | water_reminder |
 *                subscription | achievement | system | upgrade | renewal |
 *                re_engagement | checkup | coach)
 * @param title   Persian title
 * @param body    Persian body
 * @param link    Optional internal app path for clickable notifications
 *                 (e.g. "?tab=plans", "?tab=progress")
 * @param meta    Optional extra data — will be JSON-stringified
 */
export async function createNotification(
  userId: string,
  type: string,
  title: string,
  body: string,
  link?: string,
  meta?: any
) {
  try {
    return await db.notification.create({
      data: {
        userId,
        type,
        title,
        body,
        link: link ?? null,
        meta: meta ? JSON.stringify(meta) : null,
        read: false,
      },
    });
  } catch (err) {
    console.error("[createNotification] failed:", err);
    return null;
  }
}

/**
 * Generate a unique per-user renewal discount code for loyalty.
 * Format: FITAP15-{USERID-SHORT-6-CHARS}
 * (FITAP15 = 15% off renewal loyalty, private per-user, only shown in dashboard)
 */
export function buildRenewalDiscountCode(userId: string, percent: number): string {
  // First 6 chars of the userId (cuid), uppercased, alphanumeric only
  const short = userId.replace(/[^a-z0-9]/gi, "").slice(0, 6).toUpperCase().padEnd(6, "0");
  return `FITAP15-${short}`;
}

/**
 * Ensure a user has an active (non-expired, non-used) per-user discount code
 * for renewal. If they already have one, reuse it; otherwise create a new one.
 *
 * Default percent = 15 (FITAP15 loyalty code).
 */
export async function ensureRenewalDiscountCode(
  userId: string,
  percent = 15,
  validForDays = 14
): Promise<{ code: string; value: number; type: "percent" } | null> {
  // Look for an existing active (non-used, non-expired) renewal code
  const now = new Date();
  const existing = await db.userDiscountCode.findFirst({
    where: {
      userId,
      isUsed: false,
      reason: "renewal_loyalty",
      OR: [{ validUntil: null }, { validUntil: { gt: now } }],
    },
    orderBy: { createdAt: "desc" },
  });
  if (existing) {
    return { code: existing.code, value: existing.value, type: "percent" as const };
  }

  // Otherwise create a new one (retry on unique collision)
  const validUntil = new Date();
  validUntil.setDate(validUntil.getDate() + validForDays);

  for (let attempt = 0; attempt < 5; attempt++) {
    // The base code is deterministic per user (FITAP15-{short6}). On collision
    // (already exists for another user due to short hash), append a numeric suffix.
    const suffix = attempt === 0 ? "" : String(attempt);
    const code = `${buildRenewalDiscountCode(userId, percent)}${suffix}`;
    try {
      const created = await db.userDiscountCode.create({
        data: {
          userId,
          code,
          type: "percent",
          value: percent,
          reason: "renewal_loyalty",
          isUsed: false,
          validUntil,
        },
      });
      return { code: created.code, value: created.value, type: "percent" as const };
    } catch (err: any) {
      // P2002 = unique constraint failure — retry with new code
      if (err?.code !== "P2002" && err?.name !== "PrismaClientKnownRequestError") {
        console.error("[ensureRenewalDiscountCode] failed:", err);
        return null;
      }
    }
  }
  return null;
}
