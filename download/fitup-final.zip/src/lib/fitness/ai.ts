import OpenAI from "openai";
import { db } from "@/lib/db";
import type {
  OnboardingData,
  WorkoutPlanContent,
  MealPlanContent,
  Plan,
} from "./types";
import { GOAL_LABELS, ACTIVITY_LABELS, GENDER_LABELS, WORKOUT_PLACE_LABELS, DIET_LABELS, PERSIAN_WEEKDAYS, PLAN_LABELS, getCapabilities, TRAINING_EXPERIENCE_LABELS } from "./types";
import { bloodTestPromptSummary } from "./blood-tests";

// AvalAI OpenAI-compatible client singleton
export const avalaiClient = new OpenAI({
  apiKey: process.env.AVALAI_API_KEY,
  baseURL: process.env.AVALAI_BASE_URL || "https://api.avalai.ir/v1",
});

export const TEXT_MODEL = process.env.AVALAI_TEXT_MODEL || "deepseek-v4-flash";
export const VISION_MODEL = process.env.AVALAI_VISION_MODEL || "gemini-3.5-flash";

// Get AI config from DB (admin-configurable system prompts)
export async function getAiConfig(key: string, fallback: string): Promise<string> {
  const cfg = await db.aiConfig.findUnique({ where: { key } });
  return cfg?.value || fallback;
}

// Default system prompts (used if admin hasn't configured)
export const DEFAULT_COACH_PROMPT = `تو مربی هوشمند فیتاپ هستی — یک مربی متخصص و تمام‌عیار ورزشی، رژیدرمانی و مکمل‌ها. کاملاً به زبان فارسی و با لحنی حرفه‌ای، علمی، جدی و انگیزشی پاسخ می‌دهی. تو به تمام داده‌های آنبوردینگ ورزشکار (سن، قد، وزن، هدف، سطح فعالیت، آسیب‌دیدگی‌ها، رژیم غذایی، آلرژی‌ها، آزمایش خون) دسترسی کامل داری و بر اساس آن‌ها صحبت می‌کنی. قابلیت‌های تو: ارائه برنامه‌های تمرینی هفتگی، تجویز دقیق کالری و درشت‌مغذی‌ها، معرفی مکمل‌ها با دوز مصرف، و پاسخ به سوالات فنی تمرینات. همیشه نکات ایمنی را رعایت کن و در صورت نیاز هشدار پزشکی بده.

قوانین علمی مکمل‌ها (بسیار مهم):
- مکمل‌ها باید بر اساس آخرین تحقیقات علمی و ایمن باشند.
- دوز مکمل‌ها باید در محدوده ایمن و توصیه‌شده باشد. هرگز دوز بالا تجویز نکن.
- ویتامین D: حداکثر ۱۰۰۰-۲۰۰۰ واحد بین‌المللی در روز (نه ۲۰۰۰ واحد ۳ بار در روز!). دوز بالای ویتامین D سم‌زا است.
- ویتامین D soluble در چربی است و در بدن ذخیره می‌شود — نیازی به دوز بالا نیست.
- کراتین مونوهیدرات: ۳-۵ گرم در روز (بدون فاز بارگیری ضروری نیست).
- پروتئین وی: ۲۵-۳۰ گرم در وعده (نه بیشتر از ۵۰ گرم).
- امگا ۳: ۱-۲ گرم در روز.
- مولتی‌ویتامین: ۱ قرص در روز.
- از تجویز مکمل‌های خطرناک یا هورمونی به‌شدت پرهیز کن.
- همیشه در بخش note بنویس: "قبل از شروع مکمل با پزشک مشورت کنید."

قوانین نکات هفته (notes):
- نکات هفته باید انگیزشی، علمی و کاربردی باشند.
- شامل ۳-۴ نکته کوتاه و جذاب درباره پیشرفت، تغذیه، استراحت و انگیزه باشد.
- از ایموجی‌های مرتبط استفاده کن (🔥💪🎯⚡).
- لحن مثبت و تشویق‌کننده داشته باش.`;

export const DEFAULT_CHAT_PROMPT = `تو مربی هوشمند فیتاپ هستی — یک مربی متخصص و حرفه‌ای ورزشی، تغذیه و مکمل‌ها. به زبان فارسی و با لحن علمی، جدی و انگیزشی پاسخ می‌دهی. تو به تمام داده‌های آنبوردینگ ورزشکار (سن، قد، وزن، هدف، سطح فعالیت، آسیب‌دیدگی‌ها، رژیم غذایی، آلرژی‌ها) دسترسی کامل داری. قابلیت‌های تو: ارائه برنامه تمرینی هفتگی، تجویز دقیق کالری و درشت‌مغذی‌ها، معرفی مکمل‌ها با دوز مصرف، پاسخ به سوالات فنی تمرینات، راهنمایی در حالت باشگاه (Gym Mode). همیشه نکات ایمنی را رعایت کن. شعار ما: هر بدنی فیتاپ میخواد!`;

export const DEFAULT_NUTRITION_PROMPT = `تو متخصص تغذیه و مربی هوشمند فیتاپ هستی. برنامه غذایی کاملاً شخصی‌سازی‌شده به زبان فارسی ارائه بده و درشت‌مغذی‌ها را دقیق محاسبه کن.

قوانین علمی مکمل‌ها (بسیار مهم):
- مکمل‌ها باید بر اساس آخرین تحقیقات علمی و ایمن باشند.
- دوز مکمل‌ها باید در محدوده ایمن و توصیه‌شده باشد. هرگز دوز بالا تجویز نکن.
- ویتامین D: حداکثر ۱۰۰۰-۲۰۰۰ واحد بین‌المللی در روز. دوز بالای ویتامین D سم‌زا است.
- کراتین مونوهیدرات: ۳-۵ گرم در روز.
- پروتئین وی: ۲۵-۳۰ گرم در وعده.
- امگا ۳: ۱-۲ گرم در روز.
- مولتی‌ویتامین: ۱ قرص در روز.
- از تجویز مکمل‌های خطرناک یا هورمونی به‌شدت پرهیز کن.
- همیشه در بخش note بنویس: "قبل از شروع مکمل با پزشک مشورت کنید."`;

/** پرامپت نیکا — کارشناس فروش فوق‌حرفه‌ای و راهنمای کامل پلتفرم فیتاپ */
export const DEFAULT_NIKA_PROMPT = `تو «نیکا» هستی — کارشناس تخصصی فروش و راهنمای کامل پلتفرم فیتاپ. نام پلتفرم همیشه و فقط «فیتاپ» به فارسی نوشته می‌شود. هرگز کلمه FitUp یا fitup به انگلیسی ننویس.

شخصیت تو:
- صمیمی، دوستانه، خوش‌برخورد و مشکل‌گشا
- حرفه‌ای و تخصصی — به تمام امکانات فیتاپ کاملاً مسلطی و دانش دقیق داری
- همیشه مشتاق کمک و انگیزه‌بخش
- از ایموجی‌های مناسب استفاده کن (🌟💡✨💪🔥)
- پاسخ‌هایت را کوتاه، دقیق و مفید نگه دار — حداکثر ۳-۴ پاراگراف، مستقیم به نقطه برس

قوانین طلایی:
۱. تو به هیچ عنوان برنامه تمرینی یا رژیم غذایی شخصی تجویز نمی‌کنی. این کار مخصوص «فیتاپ هوشمند» (مربی هوشمند داخل پنل کاربر) است. اگر کاربر برنامه اختصاصی خواست، او را به خرید پلن پیشرفته یا حرفه‌ای راهنمایی کن.
۲. هرگز هیچ کد تخفیفی به کاربر ارائه نده. اگر کاربر درباره تخفیف پرسید، بگو: «تخفیف‌های ویژه به صورت خودکار در حساب کاربری شما اعمال می‌شوند، نیازی به کد ندارید.»
۳. هرگز قابلیت یا امکانی که در فیتاپ وجود ندارد را نساز. فقط درباره امکانات واقعی زیر صحبت کن.
۴. درباره هر پلن، قیمت و امکانات دقیق را بگو — از کلی‌گویی و حرف بازاریابی خالی پرهیز کن. تفاوت‌ها را مشخص کن.
۵. هرگز URL یا آدرس اینترنتی به کاربر نده — به جای آن از فرمت لینک درون‌برنامه‌ای زیر استفاده کن.

📌 لینک‌دهی درون‌برنامه‌ای (بسیار مهم — همیشه این کار را بکن):
وقتی می‌خواهی کاربر را به بخشی از فیتاپ راهنمایی کنی، حتماً و فقط از این فرمت استفاده کن:
[متن لینک](action:screen_name)
screen_name فقط و فقط یکی از این مقادیر مجاز است:
- landing → صفحه اصلی فیتاپ
- auth → ثبت‌نام یا ورود کاربر
- tool-tdee → محاسبه‌گر کالری و TDEE
- tool-exercises → بانک حرکات ورزشی
- tool-foods → جدول کالری غذاها
- articles → مقالات ورزشی فیتاپ
- plans → مشاهده و خرید پلن‌ها (Overlay اشتراک)

مثال درست: «می‌تونی [محاسبه کالری روزانه](action:tool-tdee) رو امتحان کنی.»
مثال درست: «برای دیدن پلن‌ها روی [مشاهده پلن‌ها](action:plans) کلیک کن.»
مثال غلط: «برو به آدرس fitap.ir/plans» (هیچ URL خارجی نده!)
مثال غلط: «برو به صفحه محاسبه کالری» (بدون فرمت لینک، کلیک نمی‌شود!)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
دانش کامل تو درباره پلتفرم فیتاپ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔹 ۴ پلن اشتراک (همه ۴۵ روزه، شامل ۱ فاز تمرینی کامل):

۱) پلن اقتصادی — ۳۵۰,۰۰۰ تومان
   ✓ آنالیز پروفایل ورزشکار
   ✓ برنامه تمرینی هفتگی شخصی‌سازی‌شده
   ✓ برنامه تغذیه روزانه با ترکیب وعده و جایگزین‌ها
   ✓ پیگیری وزن
   ✗ بدون چت با مربی هوشمند
   ✗ بدون برنامه مکمل
   مناسب: کسی که برنامه پایه می‌خواهد و خودش مدیریت می‌کند.

۲) پلن استاندارد — ۸۰۰,۰۰۰ تومان
   ✓ همه امکانات پلن اقتصادی
   ✓ برنامه مکمل ورزشی با دوز ایمن و علمی
   ✓ ۳ چکاپ دوره‌ای (هر ۱۵ روز)
   ✓ داشبورد پیشرفته با نمودار
   ✗ بدون چت با مربی هوشمند
   مناسب: ورزشکار جدی که مکمل و چکاپ دوره‌ای هم می‌خواهد.

۳) پلن پیشرفته — ۱,۲۰۰,۰۰۰ تومان (پیشنهاد ویژه 🔥)
   ✓ همه امکانات پلن استاندارد
   ✓ چت بی‌نهایت با «فیتاپ هوشمند» (مربی AI ۲۴/۷)
   ✓ آنالیز عکس غذا (عکس بگیر، کالری و درشت‌مغذی‌ها را بگو)
   ✓ آنالیز عکس بدن (پیگیری پیشرفت ظاهری)
   ✓ حالت باشگاه (Gym Mode) با تایمر استراحت و ثبت ست
   ✓ دستیار تغذیه با ترکیب وعده و غذاهای جایگزین
   ✓ کتابخانه ویدیو حرکات
   مناسب: کسی که مربی همیشه در دسترس می‌خواهد.

۴) پلن حرفه‌ای — ۱,۸۰۰,۰۰۰ تومان (کامل‌ترین 🏆)
   ✓ همه امکانات پلن پیشرفته
   ✓ ارسال ویدیو تمرین + آنالیز ویدیویی بدن توسط AI
   ✓ اصلاح تکنیک حرکات
   ✓ تحلیل آزمایش خون (عکس آزمایش بگیر، تحلیل کن)
   ✓ نظارت مربی انسانی
   مناسب: ورزشکار حرفه‌ای که کامل‌ترین همراهی می‌خواهد.

→ برای مشاهده و خرید پلن‌ها همیشه از: [مشاهده پلن‌ها](action:plans)
→ برای ثبت‌نام کاربر جدید: [ورود/ثبت‌نام](action:auth)

🔹 ابزارهای رایگان فیتاپ (بدون نیاز به اشتراک):
• [محاسبه‌گر کالری و TDEE](action:tool-tdee) — محاسبه دقیق BMR، TDEE و کالری هدف بر اساس سن، جنسیت، وزن، قد و سطح فعالیت.
• [بانک حرکات ورزشی](action:tool-exercises) — لیست کامل حرکات با توضیح نحوه انجام، نکات ایمنی، عضله هدف و سطح دشواری.
• [جدول کالری غذاها](action:tool-foods) — شاخص کالری، پروتئین، کربوهیدرات و چربی صدها غذا ایرانی و بین‌المللی.

🔹 بخش مقالات ورزشی:
کاربران می‌توانند [مقالات تخصصی فیتاپ](action:articles) را بخوانند — راهنماهای جامع درباره برنامه بدنسازی، برنامه تغذیه، مکمل‌های ورزشی، کاهش وزن و عضله‌سازی. کاملاً رایگان و بدون نیاز به ثبت‌نام.

🔹 قابلیت‌های پیشرفته داخل پنل کاربر (نیازمند پلن پیشرفته یا حرفه‌ای):
• مربی هوشمند: چت ۲۴/۷ با AI که به داده‌های آنبوردینگ شما دسترسی دارد و به سوالات تخصصی تمرین و تغذیه پاسخ می‌دهد.
• حالت باشگاه (Gym Mode): تایمر استراحت بین ست‌ها، ثبت وزنه و تکرار، و موسیقی انگیزشی.
• تحلیل عکس غذا: عکس غذای خود را بگیرید، هوش مصنوعی کالری و درشت‌مغذی‌ها را محاسبه می‌کند.
• تحلیل عکس بدن: عکس پیشرفت بگیرید و تغییرات ظاهری را پیگیری کنید.
• تحلیل ویدیویی بدن (مخصوص پلن حرفه‌ای): ویدیو تمرین بفرستید، فرم حرکت اصلاح می‌شود.
• تحلیل آزمایش خون (مخصوص پلن حرفه‌ای): عکس آزمایش خون بگیرید، تحلیل تخصصی دریافت کنید.

وقتی کاربر سوال تخصصی تمرین یا تغذیه می‌پرسد، تو فقط اطلاعات کلی و علمی می‌دهی و او را به [مشاهده پلن‌ها](action:plans) دعوت می‌کنی تا از مربی هوشمند استفاده کند.

شعار ما: هر بدنی فیتاپ میخواد! 🌟`;


// Build user context string from onboarding + plan tier
export function buildUserContext(data: OnboardingData, planName?: Plan | null): string {
  const bmr =
    data.gender === "male"
      ? 10 * data.weight + 6.25 * data.height - 5 * data.age + 5
      : 10 * data.weight + 6.25 * data.height - 5 * data.age - 161;
  const caps = getCapabilities(planName ?? null);
  const planLabel = planName ? PLAN_LABELS[planName] : "بدون پلن (Basic)";
  return `اطلاعات کاربر:
- جنسیت: ${GENDER_LABELS[data.gender]}
- سن: ${data.age} سال
- قد: ${data.height} سانتی‌متر
- وزن: ${data.weight} کیلوگرم
- وزن هدف: ${data.targetWeight ?? "نامشخص"} کیلوگرم
- هدف اصلی: ${GOAL_LABELS[data.goal]}
- سطح فعالیت: ${ACTIVITY_LABELS[data.activityLevel]}
- روزهای تمرین در هفته: ${data.workoutDays} روز${data.workoutDaysList && data.workoutDaysList.length > 0 ? ` (${data.workoutDaysList.join("، ")})` : ""}
- مکان تمرین: ${WORKOUT_PLACE_LABELS[data.workoutPlace]}
- تجهیزات: ${data.equipment.length ? data.equipment.join("، ") : "بدون تجهیزات خاص"}
- سوابق بیماری: ${data.diseases || "ندارد"}
- آسیب‌دیدگی مفصلی/عضلانی: ${data.injuries || "ندارد"}
- حساسیت غذایی: ${data.allergies || "ندارد"}
- نوع رژیم غذایی: ${DIET_LABELS[data.dietType]}
${data.trainingExperience ? `- سابقه ورزشی: ${TRAINING_EXPERIENCE_LABELS[data.trainingExperience]}` : ""}
${data.previousTrainingType ? `- نوع تمرین قبلی: ${data.previousTrainingType}` : ""}
${data.drugAllergies ? `- آلرژی‌های دارویی: ${data.drugAllergies}` : ""}
${data.currentMedications ? `- داروهای مصرفی: ${data.currentMedications}` : ""}
${data.maxLifts ? `- حداکثر وزنه‌ها: ${data.maxLifts}` : ""}
- BMR تخمینی: ${Math.round(bmr)} کالری
- پلن اشتراک کاربر: ${planLabel}
- قابلیت‌های فعال: ${[
    caps.workoutAndNutritionPlan ? "برنامه تمرین+تغذیه" : null,
    caps.supplementsPlan ? "برنامه مکمل" : null,
    caps.periodicCheckups ? "چکاپ دوره‌ای" : null,
    caps.aiChatQuestions !== 0 ? "چت هوشمند" : null,
    caps.mealPhotoAnalysis ? "آنالیز عکس غذا" : null,
    caps.bodyPhotoAnalysis ? "آنالیز عکس بدن" : null,
    caps.videoBodyAnalysis ? "آنالیز ویدیویی بدن" : null,
    caps.techniqueCorrection ? "اصلاح تکنیک" : null,
    caps.bloodTestAnalysis ? "تحلیل آزمایش خون" : null,
  ].filter(Boolean).join("، ")}`;
}

/**
 * ساخت بلوک پرامپت مخصوص پلن کاربر.
 * بر اساس سطح پلن، سطح جزئیات و دامنه برنامه را تعیین می‌کند.
 * - Basic: فقط برنامه تمرین + تغذیه
 * - Standard+: اضافه‌کردن برنامه مکمل‌ها
 * - Ultimate: تزریق متغیرهای آزمایش خون و آنالیز ویدیویی
 */
export function buildPlanAwareInstructions(planName?: Plan | null, extras?: { bloodTestReport?: string; videoAnalysisResult?: string }): string {
  const caps = getCapabilities(planName ?? null);
  const instructions: string[] = [];

  if (caps.supplementsPlan) {
    instructions.push(
      "برنامه مکمل‌های ورزشی: یک بخش «supplements» در JSON اضافه کن شامل مکمل‌های پیشنهادی با دوز ایمن و علمی. فقط مکمل‌های زیر مجاز هستند:\n" +
      "• کراتین مونوهیدرات: ۳-۵ گرم در روز (هر روز)\n" +
      "• پروتئین وی: ۲۵-۳۰ گرم در وعده (بعد تمرین)\n" +
      "• امگا ۳ (روغن ماهی): ۱-۲ گرم در روز\n" +
      "• مولتی‌ویتامین: ۱ قرص در روز\n" +
      "• ویتامین D3: ۱۰۰۰-۲۰۰۰ واحد در روز (نه بیشتر!)\n" +
      "• ال-گلوتامین: ۵ گرم در روز\n" +
      "هرگز دوز بالاتر از این مقادیر تجویز نکن. در بخش note هر مکمل بنویس: «قبل از شروع با پزشک مشورت کنید.»"
    );
  }

  if (caps.videoBodyAnalysis && extras?.videoAnalysisResult) {
    instructions.push(
      `آنالیز ویدیویی بدن کاربر (توسط هوش مصنوعی بررسی شده):\n${extras.videoAnalysisResult}\nاین اطلاعات را در طراحی برنامه لحاظ کن — نقاط ضعف فرم بدن، عدم تقارن، و حرکات اصلاحی پیشنهاد بده.`
    );
  }

  if (caps.bloodTestAnalysis && extras?.bloodTestReport) {
    instructions.push(
      `گزارش آزمایش خون کاربر:\n${extras.bloodTestReport}\nبرنامه تغذیه را بر اساس کمبودهای ویتامینی، سطح قند، چربی خون و هورمون‌ها بهینه‌سازی کن. در صورت کمبود، غذاهای غنی از آن ویتامین/ماده معدنی را اولویت بده. هشدارهای پزشکی لازم را در بخش notes بیاور.`
    );
  }

  return instructions.length
    ? `\n\nدستورالعمل‌های ویژه پلن ${planName ? PLAN_LABELS[planName] : ""}:\n${instructions.map((i, idx) => `${idx + 1}. ${i}`).join("\n")}`
    : "";
}

// Generate a weekly workout plan via AI
export async function generateWorkoutPlan(
  data: OnboardingData,
  planName?: Plan | null,
  extras?: { bloodTestReport?: string; videoAnalysisResult?: string }
): Promise<WorkoutPlanContent> {
  const systemPrompt = await getAiConfig("coach_system_prompt", DEFAULT_COACH_PROMPT);
  const context = buildUserContext(data, planName);
  const planInstructions = buildPlanAwareInstructions(planName, extras);

  // Use user-selected specific weekdays if provided; otherwise fallback to first N days
  const chosenDays =
    data.workoutDaysList && data.workoutDaysList.length > 0
      ? data.workoutDaysList
      : PERSIAN_WEEKDAYS.slice(0, data.workoutDays);

  // --- Fetch exercise names from the library so AI only uses real exercises ---
  let libraryNames: string[] = [];
  try {
    const all = await db.exerciseLibrary.findMany({ select: { name: true, muscle: true } });
    libraryNames = all.map((e: any) => e.name);
  } catch (e) {
    console.error("[generateWorkoutPlan] failed to load exercise library:", e);
  }
  const libraryList = libraryNames.length > 0
    ? `\n\nکتابخانه حرکات موجود (فقط از بین این حرکات انتخاب کن):\n${libraryNames.map((n, i) => `${i + 1}. ${n}`).join("\n")}\n`
    : "";

  const userPrompt = `بر اساس اطلاعات زیر، یک برنامه تمرینی هفتگی کامل و شخصی‌سازی‌شده بساز.

${context}
${planInstructions}
${libraryList}

روزهای تمرین کاربر: ${chosenDays.join("، ")}

فقط و فقط با ساختار JSON زیر پاسخ بده و هیچ متن اضافه‌ای قبل یا بعد از JSON ننویس:
{
  "days": [
    {
      "day": "شنبه",
      "title": "عنوان روز تمرین",
      "focus": "عضله هدف",
      "estimatedMinutes": 60,
      "exercises": [
        {
          "name": "نام حرکت (حتماً از کتابخانه حرکات بالا)",
          "muscle": "عضله هدف",
          "category": "push|pull|legs|core|cardio|fullbody",
          "description": "توضیح نحوه انجام (۲-۳ جمله کامل و واضح)",
          "tips": "نکته ایمنی و تکنیک",
          "difficulty": "beginner|intermediate|advanced",
          "sets": [
            {"setNumber": 1, "reps": "10-12", "restSec": 90},
            {"setNumber": 2, "reps": "10-12", "restSec": 90}
          ],
          "supersetGroup": "A",
          "supersetType": "superset"
        }
      ]
    }
  ],
  "weeklyGoal": "هدف هفته",
  "notes": "نکات کلی هفته"
}

قوانین مهم:
- دقیقاً ${data.workoutDays} روز تمرین در روزهای ذکر شده (${chosenDays.join("، ")}) ایجاد کن.
- هر روز ۴ تا ۶ حرکت داشته باشد.
- **حتماً فقط از حرکات کتابخانه حرکات بالا استفاده کن** — نام حرکات را دقیقاً همان‌طور بنویس.
- اگر آسیب‌دیدگی وجود دارد، حرکات جایگزین ایمن پیشنهاد بده.
- برای تمرین در خانه، از حرکات با وزن بدن یا تجهیزات موجود استفاده کن.
- تعداد ست‌ها بین ۳ تا ۵ باشد.
- **سوپرست و تری‌ست**: برای افزایش شدت تمرین، در حداقل ۲ روز از هفته از سوپرست (۲ حرکت پشت سر هم بدون استراحت) یا تری‌ست (۳ حرکت) استفاده کن. برای حرکات سوپرست، فیلد "supersetGroup" را با یک حرف یکسان (مثل "A" یا "B") پر کن و "supersetType" را "superset" یا "triset" بگذار. حرکتی که سوپرست نیست، این فیلدها را خالی بگذار.
- برای هر حرکت، توضیح کامل و واضح بنویس که کاربر بتواند حرکت را درست انجام دهد.
- **نکات هفته (notes)**: این بخش را انگیزشی و جذاب بنویس. شامل ۳-۴ نکته کوتاه با ایموجی باشد. مثال: "🔥 این هفته روی فرم حرکات تمرکز کن — کیفیت مهم‌تر از کمیت است!\n💪 پروتئین کافی بخور تا ریکاوری بهتر شود.\n🎯 هدف هفته: افزایش وزنه در اسکوات!\n⚡ استراحت بین ست‌ها را رعایت کن — عضله در استراحت رشد می‌کند."`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[generateWorkoutPlan] AvalAI error:", err);
    throw new Error("خطا در ارتباط با سرویس هوش مصنوعی. لطفاً کمی بعد دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);

  // Enrich exercises with IDs + superset fields
  const enriched: WorkoutPlanContent = {
    days: (parsed.days || []).map((day: any) => ({
      ...day,
      exercises: (day.exercises || []).map((ex: any, i: number) => ({
        ...ex,
        id: `ex_${Math.random().toString(36).slice(2, 9)}`,
        mediaUrl: "",
        sets: (ex.sets || []).map((s: any, j: number) => ({
          ...s,
          setNumber: j + 1,
          done: false,
          weight: undefined,
        })),
        supersetGroup: ex.supersetGroup || undefined,
        supersetType: ex.supersetType || undefined,
      })),
    })),
    weeklyGoal: parsed.weeklyGoal || "بهبود تدریجی قدرت و استقامت",
    notes: parsed.notes || "قبل از شروع حتماً ۵ تا ۱۰ دقیقه گرم کردن انجام دهید.",
    supplements: parsed.supplements || undefined,
  };

  return enriched;
}

// Generate a daily meal plan via AI
export async function generateMealPlan(
  data: OnboardingData,
  planName?: Plan | null,
  extras?: { bloodTestReport?: string }
): Promise<MealPlanContent> {
  const systemPrompt = await getAiConfig(
    "nutrition_system_prompt",
    DEFAULT_NUTRITION_PROMPT
  );
  const context = buildUserContext(data, planName);
  const planInstructions = buildPlanAwareInstructions(planName, extras);
  const caps = getCapabilities(planName ?? null);

  // Calculate target calories based on goal
  const bmr =
    data.gender === "male"
      ? 10 * data.weight + 6.25 * data.height - 5 * data.age + 5
      : 10 * data.weight + 6.25 * data.height - 5 * data.age - 161;
  const tdee = bmr * 1.4;
  let targetCal = tdee;
  if (data.goal === "fat_loss") targetCal = tdee - 400;
  if (data.goal === "muscle_gain") targetCal = tdee + 300;

  const userPrompt = `بر اساس اطلاعات زیر، یک برنامه غذایی یک روزه کامل و شخصی‌سازی‌شده بساز.

${context}
${planInstructions}

کالری هدف روزانه: حدود ${Math.round(targetCal)} کالری
نوع رژیم: ${DIET_LABELS[data.dietType]}
حساسیت غذایی: ${data.allergies || "ندارد"}

فقط و فقط با ساختار JSON زیر پاسخ بده و هیچ متن اضافه‌ای ننویس:
{
  "meals": [
    {
      "type": "breakfast",
      "label": "صبحانه",
      "combination": "تخم‌مرغ + نان سنگک + پنیر کم‌چرب",
      "items": [
        {"name": "تخم‌مرغ آب‌پز (۳ عدد)", "category": "breakfast", "calories": 210, "protein": 18, "carbs": 1, "fat": 15, "servingSize": "۳ عدد"},
        {"name": "نان سنگک", "category": "breakfast", "calories": 160, "protein": 5, "carbs": 32, "fat": 1, "servingSize": "۱ کف دست"}
      ],
      "alternatives": [
        {
          "combination": "جو دوسر + شیر + موز",
          "items": [
            {"name": "جو دوسر (۶۰ گرم)", "category": "breakfast", "calories": 230, "protein": 8, "carbs": 40, "fat": 4, "servingSize": "۶۰ گرم"},
            {"name": "شیر کم‌چرب", "category": "breakfast", "calories": 120, "protein": 8, "carbs": 12, "fat": 2, "servingSize": "۱ لیوان"},
            {"name": "موز", "category": "breakfast", "calories": 105, "protein": 1, "carbs": 27, "fat": 0, "servingSize": "۱ عدد متوسط"}
          ]
        },
        {
          "combination": "ماست یونانی + عسل + گردو",
          "items": [
            {"name": "ماست یونانی", "category": "breakfast", "calories": 150, "protein": 17, "carbs": 8, "fat": 4, "servingSize": "۲۰۰ گرم"},
            {"name": "عسل", "category": "breakfast", "calories": 65, "protein": 0, "carbs": 17, "fat": 0, "servingSize": "۱ قاشق"},
            {"name": "گردو", "category": "breakfast", "calories": 130, "protein": 3, "carbs": 3, "fat": 13, "servingSize": "۱۵ گرم"}
          ]
        }
      ]
    }
  ],
  "waterLiters": 2.5,
  "notes": "نکات تغذیه‌ای"${caps.supplementsPlan ? `,
  "supplements": [
    {"name": "نام مکمل (مثلاً کراتین مونوهیدرات)", "dose": "۵ گرم", "timing": "بعد از تمرین", "note": "نکته اختیاری"}
  ]` : ""}
}

قوانین:
- وعده‌ها: صبحانه، ناهار، شام و یک میان‌وعده.
- درشت‌مغذی‌ها را دقیق محاسبه کن تا جمع کل به کالری هدف نزدیک شود.
- از غذاهای ایرانی و در دسترس استفاده کن.
- اگر حساسیت غذایی وجود دارد، آن را حذف کن.
- **فیلد "combination" برای هر وعده**: دقیقاً بنویس چه غذاهایی را با هم بخورد، مثلاً "تخم‌مرغ + نان سنگک + پنیر" یا "سینه مرغ گریل + برنج + سالاد".
- **فیلد "alternatives" برای هر وعده**: حداقل ۲ گزینه جایگزین بده. هر گزینه یک آبجکت با "combination" (توضیح ترکیب) و "items" (لیست غذاها با مقادیر دقیق) است. این به کاربر کمک می‌کند تنوع داشته باشد و راحت‌تر رژیم بگیرد.
- ${data.dietType === "vegetarian" ? "فقط غذاهای گیاه‌خواری." : ""}
- ${data.dietType === "vegan" ? "فقط غذاهای وگن." : ""}
- ${data.dietType === "keto" ? "رژیم کتوژنیک با کربوهیدرات پایین." : ""}${caps.supplementsPlan ? `
- بخش supplements را پر کن: حداقل ۳-۵ مکمل علمی و ضروری برای هدف کاربر (مثل پروتئین وی، کراتین، امگا۳، مولتی‌ویتامین) با دوز دقیق و زمان مصرف.` : ""}`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[generateMealPlan] AvalAI error:", err);
    throw new Error("خطا در ارتباط با سرویس هوش مصنوعی. لطفاً کمی بعد دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);

  // Calculate totals & enrich — handle main items + alternatives
  const meals = (parsed.meals || []).map((m: any) => {
    const items = (m.items || []).map((it: any, i: number) => ({
      ...it,
      id: `food_${Math.random().toString(36).slice(2, 9)}`,
      imageUrl: "",
      done: false,
    }));
    // Enrich alternatives
    const alternatives = Array.isArray(m.alternatives) ? m.alternatives.map((alt: any, ai: number) => {
      const altItems = (alt.items || []).map((it: any, i: number) => ({
        ...it,
        id: `food_alt_${ai}_${Math.random().toString(36).slice(2, 9)}`,
        imageUrl: "",
        done: false,
      }));
      return {
        combination: alt.combination || "",
        items: altItems,
        totalCalories: altItems.reduce((s: number, x: any) => s + (x.calories || 0), 0),
      };
    }) : undefined;

    return {
      ...m,
      items,
      combination: m.combination || items.map((it: any) => it.name).join(" + "),
      alternatives,
      totalCalories: items.reduce((s: number, x: any) => s + (x.calories || 0), 0),
      totalProtein: items.reduce((s: number, x: any) => s + (x.protein || 0), 0),
      totalCarbs: items.reduce((s: number, x: any) => s + (x.carbs || 0), 0),
      totalFat: items.reduce((s: number, x: any) => s + (x.fat || 0), 0),
    };
  });

  return {
    meals,
    totalCalories: meals.reduce((s, m) => s + m.totalCalories, 0),
    totalProtein: meals.reduce((s, m) => s + m.totalProtein, 0),
    totalCarbs: meals.reduce((s, m) => s + m.totalCarbs, 0),
    totalFat: meals.reduce((s, m) => s + m.totalFat, 0),
    waterLiters: parsed.waterLiters || 2.5,
    notes: parsed.notes || "در طول روز منظم آب بنوشید.",
    supplements: Array.isArray(parsed.supplements) && parsed.supplements.length > 0
      ? parsed.supplements.map((s: any, i: number) => ({
          name: String(s.name || `مکمل ${i + 1}`),
          dose: String(s.dose || ""),
          timing: String(s.timing || ""),
          note: s.note ? String(s.note) : undefined,
        }))
      : undefined,
  };
}

// AI chat - streaming not needed, return full message
export async function aiChat(
  data: OnboardingData | null,
  history: { role: string; content: string }[],
  userMessage: string,
  planName?: Plan | null
): Promise<string> {
  const systemPrompt = await getAiConfig("chat_system_prompt", DEFAULT_CHAT_PROMPT);

  const contextPart = data
    ? `\n\nاطلاعات کاربر فعلی:\n${buildUserContext(data, planName)}\n\nپاسخ‌هایت را بر اساس این اطلاعات شخصی‌سازی کن.`
    : "";

  // محدودیت بر اساس پلن: اگر Basic/Standard، فقط پاسخ محدود به برنامه تمرین/تغذیه
  const caps = getCapabilities(planName ?? null);
  const planNote = !caps.aiChatQuestions
    ? "\n\nتوجه: این کاربر به چت کامل دسترسی ندارد و فقط پاسخ محدود درباره برنامه موجود می‌بیند. اگر سوال خارج از برنامه پرسید، به خرید پلن Advanced دعوت کن."
    : "";

  const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt + contextPart + planNote },
    ...history.slice(-10).map((m) => ({
      role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
      content: m.content,
    })),
    { role: "user", content: userMessage },
  ];

  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages,
    });
    return completion.choices[0]?.message?.content || "متأسفم، پاسخی دریافت نشد. دوباره تلاش کنید.";
  } catch (err) {
    console.error("[aiChat] AvalAI error:", err);
    throw new Error("خطا در ارتباط با مربی هوشمند. لطفاً کمی بعد دوباره تلاش کنید.");
  }
}

/** چت نیکا — دستیار فروش و راهنما (هیچ برنامه‌ای تجویز نمی‌کند) */
export async function nikaChat(
  history: { role: string; content: string }[],
  userMessage: string,
  userPlan: Plan | null
): Promise<string> {
  const systemPrompt = await getAiConfig("nika_system_prompt", DEFAULT_NIKA_PROMPT);

  // اضافه کردن اطلاعات پلن کاربر برای راهنمایی هدفمند
  const planInfo = userPlan
    ? `\n\nوضعیت پلن کاربر: ${userPlan === "basic" ? "اقتصادی (بدون چت مربی)" : userPlan === "standard" ? "استاندارد (بدون چت مربی)" : userPlan === "advanced" ? "پیشرفته (چت مربی فعال)" : "حرفه‌ای (چت مربی فعال + آنالیز ویدیو/آزمایش خون + نظارت مربی فدراسیون)"}`
    : "\n\nوضعیت پلن کاربر: مهمان (بدون ثبت‌نام)";

  const upsellHint =
    !userPlan || userPlan === "basic" || userPlan === "standard"
      ? "\n\nیادآوری: این کاربر هنوز به چت مربی هوشمند دسترسی ندارد. او را به خرید پلن پیشرفته یا حرفه‌ای ترغیب کن."
      : "";

  const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt + planInfo + upsellHint },
    ...history.slice(-10).map((m) => ({
      role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
      content: m.content,
    })),
    { role: "user", content: userMessage },
  ];

  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages,
    });
    return completion.choices[0]?.message?.content || "متأسفم، پاسخی دریافت نشد. دوباره تلاش کنید.";
  } catch (err) {
    console.error("[nikaChat] AvalAI error:", err);
    throw new Error("خطا در ارتباط با نیکا. لطفاً کمی بعد دوباره تلاش کنید.");
  }
}

/** چت دستیار هوشمند پنل مدیریت — تحلیل آمار، پیشنهاد استراتژی، کمک در تولید محتوا */
export async function adminCopilotChat(
  history: { role: string; content: string }[],
  userMessage: string,
  context: { totalUsers: number; totalRevenue: number; activeSubs: number; pendingPrograms: number }
): Promise<string> {
  const systemPrompt = `تو دستیار هوش مصنوعی پنل مدیریت فیتاپ هستی. یک مشاور حرفه‌ای برای مدیران سایت که در تمام مراحل مدیریت کمک می‌کنی: تحلیل آمار، پیشنهاد استراتژی، کمک در نوشتن مقالات، بهینه‌سازی محتوا، پاسخ به سوالات فنی. به زبان فارسی پاسخ بده. اطلاعات فعلی سایت: ${context.totalUsers} کاربر، ${context.activeSubs} اشتراک فعال، ${context.pendingPrograms} برنامه در انتظار، درآمد کل: ${context.totalRevenue} تومان.`;

  const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...history.slice(-10).map((m) => ({ role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user", content: m.content })),
    { role: "user", content: userMessage },
  ];

  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages,
    });
    return completion.choices[0]?.message?.content || "متأسفم، پاسخی دریافت نشد.";
  } catch (err) {
    console.error("[adminCopilotChat] AvalAI error:", err);
    throw new Error("خطا در ارتباط با دستیار هوشمند مدیریت. لطفاً کمی بعد دوباره تلاش کنید.");
  }
}

// Swap a food with an AI-suggested equivalent
export async function swapFood(
  foodName: string,
  calories: number,
  dietType: string,
  allergies: string
): Promise<{ name: string; calories: number; protein: number; carbs: number; fat: number; servingSize: string; reason: string }> {
  const userPrompt = `یک غذای جایگزین هم‌کالری برای "${foodName}" (حدود ${calories} کالری) پیشنهاد بده.
نوع رژیم: ${dietType}
حساسیت غذایی: ${allergies || "ندارد"}

فقط JSON:
{"name":"نام غذا","calories":250,"protein":15,"carbs":30,"fat":8,"servingSize":"۱ وعده","reason":"دلیل پیشنهاد"}`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: "تو متخصص تغذیه هستی. فقط JSON معتبر برگردان." },
        { role: "user", content: userPrompt },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[swapFood] AvalAI error:", err);
    throw new Error("خطا در دریافت پیشنهاد جایگزین غذا. لطفاً دوباره تلاش کنید.");
  }

  return parseJsonFromContent(content);
}

// ============== Vision functions (Gemini 3.5 Flash via AvalAI) ==============

/**
 * آنالیز عکس غذا — تخمین کالری و درشت‌مغذی‌ها
 * از VISION_MODEL (gemini-3.5-flash) استفاده می‌کند.
 */
export async function analyzeMealPhoto(
  base64Image: string,
  mimeType: string,
  userContext: string
): Promise<{ calories: number; protein: number; carbs: number; fat: number; description: string }> {
  const systemPrompt = "تو متخصص تغذیه هستی. عکس غذا را تحلیل کن و کالری و درشت‌مغذی‌ها را تخمین بزن. فقط JSON معتبر برگردان و هیچ متن اضافه‌ای ننویس.";

  const userText = `این عکس غذا را تحلیل کن. ${userContext ? userContext + "\n\n" : ""}فقط با ساختار JSON زیر پاسخ بده:
{"calories": 350, "protein": 25, "carbs": 40, "fat": 12, "description": "توضیح کوتاه فارسی درباره غذا و ارزش غذایی آن"}`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: VISION_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: userText },
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64Image}` } },
          ],
        },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[analyzeMealPhoto] AvalAI error:", err);
    throw new Error("خطا در آنالیز عکس غذا. لطفاً دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);
  return {
    calories: Number(parsed.calories) || 0,
    protein: Number(parsed.protein) || 0,
    carbs: Number(parsed.carbs) || 0,
    fat: Number(parsed.fat) || 0,
    description: parsed.description || "توضیحی دریافت نشد.",
  };
}

/**
 * آنالیز عکس بدن — ارزیابی فرم بدن و توصیه‌ها
 * از VISION_MODEL (gemini-3.5-flash) استفاده می‌کند.
 */
export async function analyzeBodyPhoto(
  base64Image: string,
  mimeType: string,
  userContext: string
): Promise<{ bodyScore: number; analysis: string; recommendations: string[] }> {
  const systemPrompt = "تو متخصص فیزیولوژی ورزشی و آنالیز فرم بدن هستی. عکس بدن ورزشکار را تحلیل کن و امتیاز فرم بدن، تحلیل و توصیه‌های تمرینی بده. فقط JSON معتبر برگردان.";

  const userText = `این عکس بدن ورزشکار را تحلیل کن. ${userContext ? userContext + "\n\n" : ""}فقط با ساختار JSON زیر پاسخ بده:
{"bodyScore": 75, "analysis": "تحلیل فارسی درباره فرم بدن، تقارن، عضلات و نقاط ضعف/قوت", "recommendations": ["توصیه ۱", "توصیه ۲", "توصیه ۳"]}
امتیاز bodyScore بین ۰ تا ۱۰۰ باشد.`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: VISION_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: userText },
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64Image}` } },
          ],
        },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[analyzeBodyPhoto] AvalAI error:", err);
    throw new Error("خطا در آنالیز عکس بدن. لطفاً دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);
  return {
    bodyScore: Number(parsed.bodyScore) || 0,
    analysis: parsed.analysis || "تحلیلی دریافت نشد.",
    recommendations: Array.isArray(parsed.recommendations)
      ? parsed.recommendations.map((r: any) => String(r))
      : [],
  };
}

/**
 * آنالیز ویدیویی بدن — ارزیابی پوسچر، تقارن و فرم حرکات
 * از VISION_MODEL (gemini-3.5-flash) استفاده می‌کند.
 * نکته: اگر AvalAI از ویدیو base64 پشتیبانی نکرد، فریم اول به‌عنوان عکس تحلیل می‌شود.
 */
export async function analyzeVideoBody(
  base64Video: string,
  mimeType: string,
  userContext: string
): Promise<{ posture: string; symmetry: number; issues: string[]; recommendations: string[]; score: number }> {
  const systemPrompt = "تو متخصص بیومکانیک ورزشی و آنالیز ویدیویی حرکات هستی. ویدیوی ورزشکار را تحلیل کن و پوسچر، تقارن، مشکلات فرم و توصیه‌های اصلاحی بده. فقط JSON معتبر برگردان.";

  const userText = `این ویدیوی ورزشکار را تحلیل کن. ${userContext ? userContext + "\n\n" : ""}فقط با ساختار JSON زیر پاسخ بده:
{"posture": "توصیف فارسی پوسچر کلی", "symmetry": 85, "issues": ["مشکل ۱", "مشکل ۲"], "recommendations": ["توصیه اصلاحی ۱", "توصیه اصلاحی ۲"], "score": 78}
symmetry و score بین ۰ تا ۱۰۰ باشند.`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: VISION_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: userText },
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64Video}` } },
          ],
        },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[analyzeVideoBody] AvalAI error:", err);
    throw new Error("خطا در آنالیز ویدیوی بدن. لطفاً دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);
  return {
    posture: parsed.posture || "توصیفی دریافت نشد.",
    symmetry: Number(parsed.symmetry) || 0,
    issues: Array.isArray(parsed.issues) ? parsed.issues.map((i: any) => String(i)) : [],
    recommendations: Array.isArray(parsed.recommendations)
      ? parsed.recommendations.map((r: any) => String(r))
      : [],
    score: Number(parsed.score) || 0,
  };
}

/**
 * تحلیل آزمایش خون — استخراج نشانگرها، کمبودها و توصیه‌ها
 * از VISION_MODEL (gemini-3.5-flash) استفاده می‌کند.
 *
 * پنل آزمایش شامل ۱۰ دسته کامل: CBC، چربی، کبد، کلیه، تیروئید،
 * هورمون‌ها (تستوسترون/کورتیزول/انسولین/HGH/...)، ویتامین‌ها و مواد معدنی،
 * قند خون و نشانگرهای التهاب.
 */
export async function analyzeBloodTest(
  base64Image: string,
  mimeType: string
): Promise<{
  overall: string;
  score: number;
  markers: Array<{
    key?: string;
    category?: string;
    categoryName?: string;
    name: string;
    value: string;
    unit?: string;
    status: "normal" | "low" | "high" | "borderline" | "unknown";
    reference?: string;
    explanation?: string;
  }>;
  deficiencies: string[];
  recommendations: string[];
  supplements: string[];
  warnings: string[];
}> {
  const systemPrompt =
    "تو متخصص پزشکی، تغذیه ورزشی و تحلیل آزمایش خون هستی. عکس آزمایش خون را با دقت بررسی کن، مقادیر هر نشانگر را استخراج کن، با محدوده نرمال مقایسه کن و برای ورزشکاران و بدنسازان تحلیل کن. فقط JSON معتبر برگردان.";

  const userText = `این عکس آزمایش خون را به دقت بررسی کن. مقادیر هر تست را از روی برگه آزمایش استخراج کن و تحلیل کن.

پنل کامل آزمایش‌های مورد انتظار (۱۰ دسته):
${bloodTestPromptSummary()}

برای هر نشانگری که در عکس وجود دارد، یک آبجکت به markers اضافه کن. اگر تستی در عکس نبود، آن را درج نکن.

فقط با ساختار JSON زیر پاسخ بده:
{
  "overall": "ارزیابی کلی فارسی از وضعیت سلامت ورزشکار (۲-۳ جمله)",
  "score": 75,
  "markers": [
    {
      "key": "hemoglobin",
      "category": "cbc",
      "categoryName": "آزمایش خون کامل (CBC)",
      "name": "هموگلوبین",
      "value": "۱۴.۲",
      "unit": "g/dL",
      "status": "normal",
      "reference": "۱۳-۱۷",
      "explanation": "توضیح فارسی کوتاه درباره وضعیت و معنای آن برای ورزشکار"
    }
  ],
  "deficiencies": ["کمبود ویتامین D", "کمبود آهن"],
  "recommendations": [
    "توصیه غذایی ۱ (مثلاً مصرف بیشتر گوشت قرمز)",
    "توصیه غذایی ۲"
  ],
  "supplements": [
    "مکمل توصیه‌شده ۱ (مثلاً ویتامین D3 2000 IU روزانه)",
    "مکمل توصیه‌شده ۲"
  ],
  "warnings": ["هشدار پزشکی حیاتی در صورت وجود"]
}

قوانین:
- score عددی بین ۰ تا ۱۰۰ بر اساس سلامت کلی.
- status فقط یکی از: normal | low | high | borderline | unknown
- key باید یکی از کلیدهای تعریف‌شده در پنل بالا باشد (hemoglobin, testosterone_total, vitamin_d, ...).
- category همان id دسته است (cbc, lipid, liver, kidney, thyroid, hormones, vitamins_minerals, blood_sugar, inflammation).
- explanation حتماً فارسی و کوتاه (۱-۲ جمله) باشد و به تأثیر آن روی عملکرد ورزشکار اشاره کند.
- deficiencies شامل کمبودها و مقادیر خارج محدوده باشد.
- recommendations شامل توصیه‌های غذایی و سبک زندگی باشد.
- supplements شامل مکمل‌های پیشنهادی با دوز و زمان مصرف باشد.
- warnings شامل مواردی که نیاز به مراجعه فوری به پزشک دارند.
- اگر تستی در عکس نبود، آن را در markers درج نکن.

هشدار مهم: این تحلیل جایگزین مشورت پزشک نیست و صرفاً جنبه راهنمایی دارد.`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: VISION_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: userText },
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64Image}` } },
          ],
        },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[analyzeBloodTest] AvalAI error:", err);
    throw new Error("خطا در تحلیل آزمایش خون. لطفاً دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);
  return {
    overall: parsed.overall || "ارزیابی‌ای دریافت نشد.",
    score: Number(parsed.score) || 0,
    markers: Array.isArray(parsed.markers) ? parsed.markers : [],
    deficiencies: Array.isArray(parsed.deficiencies) ? parsed.deficiencies.map((d: any) => String(d)) : [],
    recommendations: Array.isArray(parsed.recommendations)
      ? parsed.recommendations.map((r: any) => String(r))
      : [],
    supplements: Array.isArray(parsed.supplements)
      ? parsed.supplements.map((s: any) => String(s))
      : [],
    warnings: Array.isArray(parsed.warnings) ? parsed.warnings.map((w: any) => String(w)) : [],
  };
}

/**
 * تحلیل چکاپ دوره‌ای بر اساس داده‌های متنی (وزن، اندازه‌ها، بازخورد).
 * این تابع بدون نیاز به عکس، با استفاده از مدل متنی، امتیاز بدن (bodyScore 0-100)،
 * تحلیل فارسی و توصیه‌های پیشرفت تولید می‌کند.
 */
export interface CheckupAnalysisInput {
  weight: number;
  bodyFatPercent?: number | null;
  leanBodyMass?: number | null;
  chestMeasurement?: number | null;
  armMeasurement?: number | null;
  waistMeasurement?: number | null;
  hipMeasurement?: number | null;
  thighMeasurement?: number | null;
  fatigueLevel: number; // 1-5
  sleepQuality: number; // 1-5
  dietAdherence: number; // 1-5
  workoutAdherence: number; // 1-5
  notes?: string;
  phaseNumber: number;
  userContext?: string; // اطلاعات آنبوردینگ و پلن کاربر
}

export async function analyzeCheckup(
  input: CheckupAnalysisInput
): Promise<{
  bodyScore: number;
  bodyFatStatus: string;
  analysis: string;
  recommendations: string[];
  nextPhaseFocus: string;
}> {
  const systemPrompt =
    "تو مربی هوشمند و متخصص فیزیولوژی ورزشی و تغذیه فیتاپ هستی. داده‌های چکاپ دوره‌ای ورزشکار را تحلیل کن و امتیاز بدن (bodyScore 0-100)، وضعیت چربی بدن، تحلیل کلی، توصیه‌های پیشرفت و تمرکز فاز بعدی را ارائه بده. فقط JSON معتبر برگردان و هیچ متن اضافه‌ای ننویس.";

  const parts: string[] = [
    `فاز تمرینی: ${input.phaseNumber}`,
    `وزن: ${input.weight} کیلوگرم`,
  ];
  if (input.bodyFatPercent != null) parts.push(`درصد چربی بدن (تخمینی): ${input.bodyFatPercent.toFixed(1)}٪`);
  if (input.leanBodyMass != null) parts.push(`جرم خالص بدن: ${input.leanBodyMass.toFixed(1)} کیلوگرم`);
  if (input.chestMeasurement != null) parts.push(`دور سینه: ${input.chestMeasurement} cm`);
  if (input.armMeasurement != null) parts.push(`دور بازو: ${input.armMeasurement} cm`);
  if (input.waistMeasurement != null) parts.push(`دور کمر: ${input.waistMeasurement} cm`);
  if (input.hipMeasurement != null) parts.push(`دور باسن: ${input.hipMeasurement} cm`);
  if (input.thighMeasurement != null) parts.push(`دور ران: ${input.thighMeasurement} cm`);
  parts.push(
    `خستگی (1-5): ${input.fatigueLevel}`,
    `کیفیت خواب (1-5): ${input.sleepQuality}`,
    `پیروی از رژیم (1-5): ${input.dietAdherence}`,
    `پیروی از تمرین (1-5): ${input.workoutAdherence}`
  );
  if (input.notes && input.notes.trim()) parts.push(`یادداشت ورزشکار: ${input.notes}`);
  if (input.userContext) parts.push(`\nاطلاعات ورزشکار:\n${input.userContext}`);

  const userText = `داده‌های چکاپ دوره‌ای ورزشکار را تحلیل کن:

${parts.join("\n")}

فقط با ساختار JSON زیر پاسخ بده:
{
  "bodyScore": 75,
  "bodyFatStatus": "ارزیابی کوتاه فارسی درباره وضعیت چربی بدن",
  "analysis": "تحلیل کامل فارسی (۲-۳ پاراگراف): پیشرفت از فاز قبل، نقاط قوت، نقاط ضعف، وضعیت کلی بدن",
  "recommendations": ["توصیه تمرینی ۱", "توصیه تغذیه‌ای ۲", "توصیه ریکاوری ۳"],
  "nextPhaseFocus": "تمرکز اصلی فاز بعدی (یک جمله فارسی)"
}

bodyScore بین ۰ تا ۱۰۰ بر اساس پیروی از برنامه، خستگی، خواب و پیشرفت اندازه‌ها باشد.
توصیه‌ها عملی و مشخص باشند.`;

  let content: string;
  try {
    const completion = await avalaiClient.chat.completions.create({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userText },
      ],
    });
    content = completion.choices[0]?.message?.content || "";
  } catch (err) {
    console.error("[analyzeCheckup] AvalAI error:", err);
    throw new Error("خطا در تحلیل چکاپ. لطفاً دوباره تلاش کنید.");
  }

  const parsed = parseJsonFromContent(content);
  return {
    bodyScore: Math.max(0, Math.min(100, Number(parsed.bodyScore) || 0)),
    bodyFatStatus: parsed.bodyFatStatus || "ارزیابی‌ای دریافت نشد.",
    analysis: parsed.analysis || "تحلیلی دریافت نشد.",
    recommendations: Array.isArray(parsed.recommendations)
      ? parsed.recommendations.map((r: any) => String(r))
      : [],
    nextPhaseFocus: parsed.nextPhaseFocus || "ادامه مسیر با تمرکز بر پیشرفت تدریجی.",
  };
}

// Parse JSON from LLM content (handles markdown code fences + HTML error pages gracefully)
function parseJsonFromContent(content: string): any {
  if (!content || typeof content !== "string") {
    return { days: [], meals: [], notes: "پاسخ هوش مصنوعی خالی بود." };
  }

  let cleaned = content.trim();

  // Detect HTML error pages (gateway error, 502/504, AvalAI returning HTML)
  // If the content looks like HTML and contains no JSON braces, bail out gracefully.
  const looksLikeHtml = /^\s*<(?:html|!doctype|head|body|h1|div|p)\b/i.test(cleaned) ||
    (cleaned.startsWith("<") && cleaned.includes("</") && !cleaned.includes("{"));
  if (looksLikeHtml) {
    console.error("[parseJsonFromContent] AI returned HTML (likely an error page):", cleaned.slice(0, 200));
    return { days: [], meals: [], notes: "خطا در پاسخ هوش مصنوعی. لطفاً دوباره تلاش کنید." };
  }

  // Extract JSON from ```json ... ``` or ``` ... ```
  const fenceMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    cleaned = fenceMatch[1].trim();
  }

  // Find first { and last }
  const first = cleaned.indexOf("{");
  const last = cleaned.lastIndexOf("}");
  if (first !== -1 && last !== -1 && last > first) {
    cleaned = cleaned.slice(first, last + 1);
  }

  try {
    return JSON.parse(cleaned);
  } catch (err) {
    console.error("[parseJsonFromContent] JSON parse failed. Raw content:", content.slice(0, 300), err);
    return { days: [], meals: [], notes: "خطا در پردازش پاسخ هوش مصنوعی." };
  }
}
