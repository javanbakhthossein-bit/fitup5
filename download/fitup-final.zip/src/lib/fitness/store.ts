"use client";

import { create } from "zustand";
import type {
  OnboardingData,
  WorkoutPlanContent,
  MealPlanContent,
  ChatMessageDto,
  NotificationDto,
  Plan,
} from "./types";

export interface LoggedFood {
  id: string;
  name: string;
  meal: "breakfast" | "lunch" | "dinner" | "snack";
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  loggedAt: string;
}

export interface BodyMeasurements {
  waist?: number; // دور کمر
  arm?: number; // دور بازو
  chest?: number; // دور سینه
  hip?: number; // دور باسن
  updatedAt?: string;
}

export interface ActiveSession {
  dayId: string;
  startedAt: string;
  currentExerciseIdx: number;
  loggedSets: Record<string, { weight: number; reps: number; done: boolean }[]>;
}

export interface GymTrack {
  id: string;
  name: string;
  url: string; // object URL from File API
  duration?: number;
  artist?: string;
  blob?: Blob; // raw audio blob for IndexedDB persistence
}

export type AppScreen =
  | "loading"
  | "landing"
  | "auth"
  | "onboarding"
  | "analysis"
  | "main"
  | "admin"
  | "tool-tdee"
  | "tool-exercises"
  | "tool-foods"
  | "articles"
  | "article"
  | "terms";

export type MainTab =
  | "dashboard"
  | "programs"
  | "workouts"
  | "nutrition"
  | "progress"
  | "chat"
  | "plans"
  | "referral"
  | "support";

interface UserDto {
  id: string;
  mobile: string;
  name: string | null;
  role: string;
  onboardingDone: boolean;
  hasActiveSubscription: boolean;
  subscriptionEnd: string | null;
  planName: Plan | null;
  planExpiresAt: string | null;
  walletBalance: number;
  acceptedTermsVersion: number | null;
}

interface AppState {
  // Auth
  screen: AppScreen;
  user: UserDto | null;
  setUser: (u: UserDto | null) => void;
  setScreen: (s: AppScreen) => void;
  // Article slug for article detail screen
  articleSlug: string | null;
  setArticleSlug: (s: string | null) => void;

  // Main tab
  mainTab: MainTab;
  setMainTab: (t: MainTab) => void;

  // Chat mode: nika (sales/support) vs coach (smart coach, plan-gated)
  chatMode: "nika" | "coach";
  setChatMode: (m: "nika" | "coach") => void;
  nikaMessages: ChatMessageDto[];
  setNikaMessages: (m: ChatMessageDto[]) => void;
  addNikaMessage: (m: ChatMessageDto) => void;

  // Daily tracking (persisted in-memory across tab switches)
  waterMl: number; // آب مصرفی امروز به سی‌سی
  addWater: (ml: number) => void;
  caloriesConsumed: number;
  caloriesBurned: number;
  setCaloriesConsumed: (n: number) => void;
  setCaloriesBurned: (n: number) => void;
  loggedFoods: LoggedFood[];
  addLoggedFood: (f: LoggedFood) => void;
  removeLoggedFood: (id: string) => void;
  bodyMeasurements: BodyMeasurements;
  setBodyMeasurements: (m: BodyMeasurements) => void;

  // Active workout session
  activeSession: ActiveSession | null;
  startSession: (dayId: string) => void;
  endSession: () => void;
  logSet: (exerciseId: string, setNumber: number, weight: number, reps: number) => void;

  // Overlay views (rendered on top of main)
  overlay:
    | null
    | "notifications"
    | "profile"
    | "subscription"
    | "nutrition"
    | "admin"
    | "workoutDetail"
    | "exerciseDetail"
    | "gymMode"
    | "videoAnalysis"
    | "bloodTest";
  setOverlay: (o: AppState["overlay"]) => void;
  exerciseDetailId: string | null;
  setExerciseDetailId: (id: string | null) => void;

  // Gym Mode music playlist (in-memory)
  gymPlaylist: GymTrack[];
  setGymPlaylist: (tracks: GymTrack[]) => void;

  // Data
  workoutPlan: WorkoutPlanContent | null;
  setWorkoutPlan: (p: WorkoutPlanContent | null) => void;

  mealPlan: MealPlanContent | null;
  setMealPlan: (p: MealPlanContent | null) => void;

  chatMessages: ChatMessageDto[];
  setChatMessages: (m: ChatMessageDto[]) => void;
  addChatMessage: (m: ChatMessageDto) => void;

  notifications: NotificationDto[];
  setNotifications: (n: NotificationDto[]) => void;
  unreadCount: number;

  // Plan generation loading
  generatingPlan: boolean;
  setGeneratingPlan: (v: boolean) => void;

  // Onboarding draft
  onboardingDraft: Partial<OnboardingData>;
  setOnboardingDraft: (d: Partial<OnboardingData>) => void;

  // Reset
  reset: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  screen: "loading",
  user: null,
  setUser: (u) => set({ user: u }),

  setScreen: (s) => set({ screen: s }),
  articleSlug: null,
  setArticleSlug: (s) => set({ articleSlug: s }),

  mainTab: "dashboard",
  setMainTab: (t) => set({ mainTab: t }),

  chatMode: "nika",
  setChatMode: (m) => set({ chatMode: m }),
  nikaMessages: [],
  setNikaMessages: (m) => set({ nikaMessages: m }),
  addNikaMessage: (m) => set((s) => ({ nikaMessages: [...s.nikaMessages, m] })),

  // Daily tracking defaults
  waterMl: 0,
  addWater: (ml) => set((s) => ({ waterMl: Math.max(0, Math.min(5000, s.waterMl + ml)) })),
  caloriesConsumed: 0,
  caloriesBurned: 0,
  setCaloriesConsumed: (n) => set({ caloriesConsumed: Math.max(0, n) }),
  setCaloriesBurned: (n) => set({ caloriesBurned: Math.max(0, n) }),
  loggedFoods: [],
  addLoggedFood: (f) => set((s) => ({
    loggedFoods: [...s.loggedFoods, f],
    caloriesConsumed: s.caloriesConsumed + f.calories,
  })),
  removeLoggedFood: (id) => set((s) => {
    const food = s.loggedFoods.find((x) => x.id === id);
    return {
      loggedFoods: s.loggedFoods.filter((x) => x.id !== id),
      caloriesConsumed: Math.max(0, s.caloriesConsumed - (food?.calories ?? 0)),
    };
  }),
  bodyMeasurements: {},
  setBodyMeasurements: (m) => set({ bodyMeasurements: { ...m, updatedAt: new Date().toISOString() } }),

  // Active workout session
  activeSession: null,
  startSession: (dayId) => set({
    activeSession: {
      dayId,
      startedAt: new Date().toISOString(),
      currentExerciseIdx: 0,
      loggedSets: {},
    },
  }),
  endSession: () => set({ activeSession: null }),
  logSet: (exerciseId, setNumber, weight, reps) => set((s) => {
    if (!s.activeSession) return {};
    const existing = s.activeSession.loggedSets[exerciseId] || [];
    const updated = existing.map((entry, i) =>
      i === setNumber - 1 ? { weight, reps, done: true } : entry
    );
    // ensure array length covers setNumber
    while (updated.length < setNumber) updated.push({ weight: 0, reps: 0, done: false });
    updated[setNumber - 1] = { weight, reps, done: true };
    return {
      activeSession: {
        ...s.activeSession,
        loggedSets: { ...s.activeSession.loggedSets, [exerciseId]: updated },
      },
    };
  }),

  overlay: null,
  setOverlay: (o) => set({ overlay: o }),
  exerciseDetailId: null,
  setExerciseDetailId: (id) => set({ exerciseDetailId: id }),

  gymPlaylist: [],
  setGymPlaylist: (tracks) => set({ gymPlaylist: tracks }),

  workoutPlan: null,
  setWorkoutPlan: (p) => set({ workoutPlan: p }),

  mealPlan: null,
  setMealPlan: (p) => set({ mealPlan: p }),

  chatMessages: [],
  setChatMessages: (m) => set({ chatMessages: m }),
  addChatMessage: (m) => set((s) => ({ chatMessages: [...s.chatMessages, m] })),

  notifications: [],
  setNotifications: (n) =>
    set({ notifications: n, unreadCount: n.filter((x) => !x.read).length }),

  generatingPlan: false,
  setGeneratingPlan: (v) => set({ generatingPlan: v }),

  onboardingDraft: {},
  setOnboardingDraft: (d) =>
    set((s) => ({ onboardingDraft: { ...s.onboardingDraft, ...d } })),

  reset: () =>
    set({
      screen: "landing",
      user: null,
      mainTab: "dashboard",
      overlay: null,
      workoutPlan: null,
      mealPlan: null,
      chatMessages: [],
      nikaMessages: [],
      chatMode: "nika",
      notifications: [],
      waterMl: 0,
      caloriesConsumed: 0,
      caloriesBurned: 0,
      loggedFoods: [],
      activeSession: null,
      articleSlug: null,
    }),
}));

// Persian number formatting helper for components
export { toPersianDigits } from "./types";
