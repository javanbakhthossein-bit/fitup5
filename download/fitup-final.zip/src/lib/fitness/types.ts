// Shared types for Fitap Fitness App

export type Gender = "male" | "female";
export type Goal =
  | "fat_loss"
  | "muscle_gain"
  | "endurance"
  | "fitness"
  | "strength";
export type ActivityLevel =
  | "sedentary"
  | "light"
  | "moderate"
  | "active"
  | "very_active";
export type WorkoutPlace = "gym" | "home" | "both";
export type DietType = "standard" | "vegetarian" | "vegan" | "keto";

export type TrainingExperience = "beginner" | "intermediate" | "advanced" | "pro";

export interface OnboardingData {
  // Identity (collected at the start of onboarding)
  firstName?: string;
  lastName?: string;

  gender: Gender;
  age: number;
  height: number; // cm
  weight: number; // kg
  targetWeight?: number;
  goal: Goal;
  activityLevel: ActivityLevel;
  workoutDays: number;
  workoutDaysList?: string[]; // روزهای انتخاب‌شده هفته (شنبه، یکشنبه، ...)
  workoutPlace: WorkoutPlace;
  equipment: string[];
  diseases: string;
  injuries: string;
  allergies: string;
  dietType: DietType;
  mealCount?: number; // تعداد وعده‌های غذایی رغبتی

  // Professional advanced fields (optional, for pro athletes)
  trainingExperience?: TrainingExperience; // سابقه ورزشی
  previousTrainingType?: string; // نوع تمرین قبلی
  drugAllergies?: string; // آلرژی‌های دارویی
  currentMedications?: string; // داروهای مصرفی
  maxLifts?: string; // حداکثر وزنه‌ها (اسکوات/پرس سینه/ددلیفت)

  bloodTestUploaded?: boolean;
  bodyImagesCount?: number;

  // Optional baseline body measurements (cm) — collected during onboarding
  // for a more accurate baseline checkup. All optional.
  chestMeasurement?: number;  // دور قفسه سینه
  armMeasurement?: number;    // دور بازو
  waistMeasurement?: number;  // دور کمر
  hipMeasurement?: number;    // دور باسن
  thighMeasurement?: number;  // دور ران
}

// Workout plan structure (stored as JSON)
export interface ExerciseSet {
  setNumber: number;
  reps: string; // "10-12" or "30s"
  restSec: number;
  weight?: number; // kg logged by user
  done?: boolean;
}

export interface PlanExercise {
  id: string;
  name: string;
  muscle: string;
  category: string;
  description: string;
  tips: string;
  mediaUrl: string;
  difficulty: string;
  sets: ExerciseSet[];
  /** سوپرست/تری‌ست — اگر این حرکت با حرکت دیگری سوپرست است، نام گروه را اینجا بگذار.
   *  مثال: "A" یعنی عضو گروه سوپرست A. گروه‌های هم‌نام با هم سوپرست/تری‌ست می‌شوند. */
  supersetGroup?: string;
  /** نوع گروه: "superset" (۲ حرکت) یا "triset" (۳ حرکت) */
  supersetType?: "superset" | "triset";
}

export interface WorkoutDay {
  day: string; // "شنبه", "یکشنبه", ...
  title: string; // "روز سینه و سه‌سر"
  focus: string;
  exercises: PlanExercise[];
  estimatedMinutes: number;
  isToday?: boolean;
}

export interface WorkoutPlanContent {
  days: WorkoutDay[];
  weeklyGoal: string;
  notes: string;
  supplements?: { name: string; dose: string; timing: string; note?: string }[];
}

// Meal plan structure (stored as JSON)
export interface MealItem {
  id: string;
  name: string;
  category: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  servingSize: string;
  imageUrl: string;
  done?: boolean;
}

export interface Meal {
  type: string; // صبحانه | ناهار | شام | میان‌وعده
  label: string;
  items: MealItem[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  /** ترکیب غذاها — مثلاً "تخم‌مرغ + نان سنگک + پنیر" — به کاربر می‌گوید چه چیزهایی را با هم بخورد */
  combination?: string;
  /** غذاهای جایگزین — ۲-۳ گزینه جایگزین برای این وعده تا کاربر تنوع داشته باشد.
   *  هر گزینه یک آبجکت با items (لیست غذاها) و combination (توضیح ترکیب) است. */
  alternatives?: {
    combination: string;
    items: MealItem[];
    totalCalories: number;
  }[];
}

export interface MealPlanContent {
  meals: Meal[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  waterLiters: number;
  notes: string;
  /** برنامه مکمل‌ها (Standard+) — در صورت وجود، از همینجا نمایش داده می‌شود */
  supplements?: { name: string; dose: string; timing: string; note?: string }[];
}

// Chat
export interface ChatMessageDto {
  id: string;
  role: "user" | "assistant";
  content: string;
  mediaUrl?: string | null; // URL فایل مدیا (عکس/ویدیو) ارسال‌شده در پیام کاربر
  mediaType?: "image" | "video" | null; // نوع مدیا
  createdAt: string;
}

// Notifications
export type NotificationType =
  | "welcome"
  | "workout_reminder"
  | "water_reminder"
  | "subscription"
  | "achievement"
  | "system"
  | "upgrade"
  | "renewal"
  | "re_engagement"
  | "checkup"
  | "coach";

export interface NotificationDto {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  link?: string | null;
  meta?: any;
  read: boolean;
  createdAt: string;
}

// ============================================================
//  SUBSCRIPTION PLANS — 4 tiers (Basic / Standard / Advanced / Ultimate)
//  هر بدنی فیتاپ میخواد — ۴ سطح دسترسی متناسب با هر هدف و بودجه
// ============================================================
export type Plan = "basic" | "standard" | "advanced" | "ultimate";

export type PlanTier = Plan;

export type BillingPeriod = "monthly" | "yearly";

/** قابلیت‌هایی که بر اساس پلن فعال/غیرفعال می‌شوند (Feature Gating) */
export interface PlanCapabilities {
  workoutAndNutritionPlan: boolean;
  supplementsPlan: boolean;
  periodicCheckups: boolean;
  aiChatQuestions: number; // 0 = قفل، -1 = بی‌نهایت
  chatImageUpload: boolean;
  chatVideoUpload: boolean;
  mealPhotoAnalysis: boolean;
  bodyPhotoAnalysis: boolean;
  gymMode: boolean;
  nutritionCompanion: boolean;
  fullExerciseLibrary: boolean;
  videoBodyAnalysis: boolean;
  videoAnalysisLimit: number;
  techniqueCorrection: boolean;
  bloodTestAnalysis: boolean;
  bloodTestLimit: number;
  humanCoachOversight: boolean;
}

export interface SubscriptionPlan {
  id: Plan;
  tier: number;
  label: string;
  tagline: string;
  price: number;
  durationDays: number;
  phases: number;
  features: string[];
  capabilities: PlanCapabilities;
  badge?: string;
  popular?: boolean;
  accentColor: string;
  icon: string;
}

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: "basic",
    tier: 1,
    label: "اقتصادی",
    tagline: "شروع مسیر تناسب اندام",
    price: 350000,
    durationDays: 45,
    phases: 1,
    icon: "🌱",
    accentColor: "from-slate-500 to-gray-600",
    features: [
      "آنالیز کامل پروفایل ورزشی",
      "برنامه تمرینی اختصاصی (۴۵ روزه / ۱ فاز)",
      "برنامه تغذیه اختصاصی",
      "پیگیری پیشرفت وزن",
    ],
    capabilities: {
      workoutAndNutritionPlan: true,
      supplementsPlan: false,
      periodicCheckups: false,
      aiChatQuestions: 0,
      chatImageUpload: false,
      chatVideoUpload: false,
      mealPhotoAnalysis: false,
      bodyPhotoAnalysis: false,
      gymMode: false,
      nutritionCompanion: false,
      fullExerciseLibrary: false,
      videoBodyAnalysis: false,
      videoAnalysisLimit: 0,
      techniqueCorrection: false,
      bloodTestAnalysis: false,
      bloodTestLimit: 0,
      humanCoachOversight: false,
    },
  },
  {
    id: "standard",
    tier: 2,
    label: "استاندارد",
    tagline: "برنامه کامل‌تر با مکمل و چکاپ",
    price: 800000,
    durationDays: 45,
    phases: 1,
    icon: "⚡",
    accentColor: "from-cyan-500 to-teal-600",
    features: [
      "تمام امکانات پلن اقتصادی",
      "برنامه مکمل‌های ورزشی اختصاصی",
      "۳ چکاپ دوره‌ای برای رصد پیشرفت",
      "داشبورد پیشرفته با تاریخچه و سوابق ورزشی",
      "برنامه تمرین و تغذیه اختصاصی (۴۵ روزه / ۱ فاز)",
    ],
    capabilities: {
      workoutAndNutritionPlan: true,
      supplementsPlan: true,
      periodicCheckups: true,
      aiChatQuestions: 0,
      chatImageUpload: false,
      chatVideoUpload: false,
      mealPhotoAnalysis: false,
      bodyPhotoAnalysis: false,
      gymMode: false,
      nutritionCompanion: false,
      fullExerciseLibrary: false,
      videoBodyAnalysis: false,
      videoAnalysisLimit: 0,
      techniqueCorrection: false,
      bloodTestAnalysis: false,
      bloodTestLimit: 0,
      humanCoachOversight: false,
    },
  },
  {
    id: "advanced",
    tier: 3,
    label: "پیشرفته",
    tagline: "چت هوشمند + حالت باشگاه + آنالیز عکس",
    price: 1200000,
    durationDays: 45,
    phases: 1,
    icon: "🔥",
    accentColor: "from-amber-500 to-orange-600",
    badge: "پیشنهاد ویژه",
    popular: true,
    features: [
      "تمام امکانات پلن استاندارد",
      "پشتیبانی ۲۴ ساعته با چت فیتاپ هوشمند (متن + عکس)",
      "آنالیز هوشمند وعده‌های غذایی با ارسال عکس",
      "آنالیز هوشمند بدن با ارسال عکس",
      "دسترسی به حالت باشگاه (Gym Mode)",
      "کامپنیون تغذیه (دستیار تغذیه)",
      "دسترسی کامل به کتابخانه متحرک حرکات",
      "سوالات چت هوشمند = بی‌نهایت",
    ],
    capabilities: {
      workoutAndNutritionPlan: true,
      supplementsPlan: true,
      periodicCheckups: true,
      aiChatQuestions: -1,
      chatImageUpload: true,
      chatVideoUpload: false,
      mealPhotoAnalysis: true,
      bodyPhotoAnalysis: true,
      gymMode: true,
      nutritionCompanion: true,
      fullExerciseLibrary: true,
      videoBodyAnalysis: false,
      videoAnalysisLimit: 0,
      techniqueCorrection: false,
      bloodTestAnalysis: false,
      bloodTestLimit: 0,
      humanCoachOversight: false,
    },
  },
  {
    id: "ultimate",
    tier: 4,
    label: "حرفه‌ای",
    tagline: "آنالیز ویدیویی + آزمایش خون — کامل‌ترین",
    price: 1800000,
    durationDays: 45,
    phases: 1,
    icon: "👑",
    accentColor: "from-violet-500 to-purple-600",
    badge: "کامل‌ترین",
    features: [
      "تمام امکانات پلن پیشرفته",
      "پشتیبانی ۲۴ ساعته با هوش مصنوعی (متن + عکس + ویدیو)",
      "آنالیز ویدیویی بدن قبل از طراحی برنامه",
      "اصلاح تکنیک حرکات با ارسال ویدیو (۱۰ بار مجاز)",
      "آنالیز تخصصی آزمایش خون و تطبیق با برنامه (۱ بار مجاز)",
      "سوالات چت هوشمند = بی‌نهایت",
    ],
    capabilities: {
      workoutAndNutritionPlan: true,
      supplementsPlan: true,
      periodicCheckups: true,
      aiChatQuestions: -1,
      chatImageUpload: true,
      chatVideoUpload: true,
      mealPhotoAnalysis: true,
      bodyPhotoAnalysis: true,
      gymMode: true,
      nutritionCompanion: true,
      fullExerciseLibrary: true,
      videoBodyAnalysis: true,
      videoAnalysisLimit: 10,
      techniqueCorrection: true,
      bloodTestAnalysis: true,
      bloodTestLimit: 1,
      humanCoachOversight: true,
    },
  },
];

/** Helper: گرفتن آبجکت پلن با ID */
export function getPlan(id: Plan): SubscriptionPlan | undefined {
  return SUBSCRIPTION_PLANS.find((p) => p.id === id);
}

/** Helper: گرفتن قابلیت‌های یک پلن */
export function getCapabilities(planId: Plan | null | undefined): PlanCapabilities {
  if (!planId) return SUBSCRIPTION_PLANS[0].capabilities;
  return getPlan(planId)?.capabilities ?? SUBSCRIPTION_PLANS[0].capabilities;
}

/** Helper: آیا پلن فعلی به قابلیت خاصی دسترسی دارد؟ */
export function canAccess(
  planId: Plan | null | undefined,
  capability: keyof PlanCapabilities
): boolean {
  const caps = getCapabilities(planId);
  const val = caps[capability];
  if (typeof val === "number") return val !== 0;
  return Boolean(val);
}

/** رتبه‌بندی پلن برای مقایسه (کمک‌کننده برای gating) */
export function planTierRank(planId: Plan | null | undefined): number {
  if (!planId) return 0;
  return getPlan(planId)?.tier ?? 0;
}

/** برچسب فارسی پلن */
export const PLAN_LABELS: Record<Plan, string> = {
  basic: "اقتصادی",
  standard: "استاندارد",
  advanced: "پیشرفته",
  ultimate: "حرفه‌ای",
};

/** حداقل پلن لازم برای هر قابلیت قفل‌شده */
export const FEATURE_MIN_PLAN: Record<string, { plan: Plan; label: string }> = {
  aiChat: { plan: "advanced", label: "چت هوشمند فیتاپ" },
  chatVideo: { plan: "ultimate", label: "ارسال ویدیو در چت" },
  gymMode: { plan: "advanced", label: "حالت باشگاه" },
  nutritionCompanion: { plan: "advanced", label: "دستیار تغذیه" },
  videoAnalysis: { plan: "ultimate", label: "آنالیز ویدیویی بدن" },
  bloodTest: { plan: "ultimate", label: "آنالیز آزمایش خون" },
  techniqueCorrection: { plan: "ultimate", label: "اصلاح تکنیک حرکات" },
  supplements: { plan: "standard", label: "برنامه مکمل‌ها" },
  humanCoach: { plan: "ultimate", label: "نظارت مربی فدراسیون" },
};

/** فرمت مبلغ به تومان با جداکننده سه‌رقمی */
export function formatToman(amount: number): string {
  return amount.toLocaleString("en-US");
}

// Persian digit helper
export const toPersianDigits = (input: string | number): string => {
  const persian = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return String(input).replace(/[0-9]/g, (d) => persian[Number(d)]);
};

// Persian labels
export const GOAL_LABELS: Record<Goal, string> = {
  fat_loss: "کاهش چربی",
  muscle_gain: "عضله‌سازی",
  endurance: "افزایش استقامت",
  fitness: "تناسب اندام عمومی",
  strength: "افزایش قدرت",
};

export const ACTIVITY_LABELS: Record<ActivityLevel, string> = {
  sedentary: "بی‌تحرک",
  light: "کم‌تحرک",
  moderate: "متوسط",
  active: "فعال",
  very_active: "خیلی فعال",
};

export const WORKOUT_PLACE_LABELS: Record<WorkoutPlace, string> = {
  gym: "باشگاه",
  home: "خانه",
  both: "هردو (باشگاه و خانه)",
};

export const DIET_LABELS: Record<DietType, string> = {
  standard: "عادی",
  vegetarian: "گیاه‌خواری",
  vegan: "وگن",
  keto: "کتوژنیک",
};

export const GENDER_LABELS: Record<Gender, string> = {
  male: "آقا",
  female: "خانم",
};

// Persian week days
export const PERSIAN_WEEKDAYS = [
  "شنبه",
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه",
];

// Training experience labels (Persian)
export const TRAINING_EXPERIENCE_LABELS: Record<TrainingExperience, string> = {
  beginner: "مبتدی",
  intermediate: "متوسط",
  advanced: "پیشرفته",
  pro: "حرفه‌ای",
};
