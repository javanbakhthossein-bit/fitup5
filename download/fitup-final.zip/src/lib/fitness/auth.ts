import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { scryptSync, randomBytes, timingSafeEqual } from "crypto";
import type { Plan } from "@/lib/fitness/types";

/**
 * ساخت DTO امن کاربر برای ارسال به کلاینت.
 * شامل اطلاعات پلن فعلی و موجودی کیف پول.
 */
export async function buildUserDto(userId: string) {
  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) return null;

  const now = new Date();
  const activeSub = await db.subscription.findFirst({
    where: {
      userId: user.id,
      status: "active",
      endDate: { gt: now },
    },
    orderBy: { endDate: "desc" },
  });

  // اگر اشتراک فعالی هست، فیلدهای پلن را از آن می‌گیریم
  // اگر اشتراک منقضی شده، پلن null می‌شود (دسترسی قطع)
  const planName = activeSub?.plan ?? null;
  const planExpiresAt = activeSub?.endDate ?? null;
  const hasActive = !!activeSub;

  return {
    id: user.id,
    mobile: user.mobile,
    name: user.name,
    role: user.role,
    onboardingDone: user.onboardingDone,
    hasActiveSubscription: hasActive,
    subscriptionEnd: planExpiresAt?.toISOString() ?? null,
    planName: (planName as Plan | null) ?? null,
    planExpiresAt: planExpiresAt?.toISOString() ?? null,
    walletBalance: user.walletBalance,
    acceptedTermsVersion: user.acceptedTermsVersion ?? null,
  };
}

/**
 * اعتبارسنجی دسترسی کاربر به یک قابلیت خاص بر اساس پلن فعال.
 * در سمت سرور استفاده می‌شود. اگر دسترسی نباشد، خطا می‌اندازد.
 */
export async function requirePlanCapability(capability: string): Promise<{ userId: string; planName: Plan | null }> {
  const user = await requireAuth();
  const dto = await buildUserDto(user.id);
  const planName = dto?.planName ?? null;

  // نگاشت قابلیت‌ها به حداقل پلن لازم (سیستم ۴ پلنی: basic=1, standard=2, advanced=3, ultimate=4)
  const minTierMap: Record<string, number> = {
    exerciseLibrary: 1, // Basic
    supplements: 2, // Standard
    periodicCheckups: 2, // Standard
    aiChat: 3, // Advanced
    chatImage: 3,
    chatImageUpload: 3, // Advanced (آلیاس برای ارسال عکس در چت)
    mealPhotoAnalysis: 3,
    bodyPhotoAnalysis: 3,
    gymMode: 3,
    nutritionCompanion: 3,
    fullExerciseLibrary: 3,
    chatVideo: 4, // Ultimate
    chatVideoUpload: 4, // Ultimate (آلیاس برای ارسال ویدیو در چت)
    videoAnalysis: 4,
    techniqueCorrection: 4,
    bloodTest: 4,
    humanCoach: 4,
    hybridProgram: 4,
  };

  const minTier = minTierMap[capability] ?? 0;
  if (minTier === 0) {
    return { userId: user.id, planName };
  }

  const planTiers: Record<string, number> = {
    basic: 1,
    standard: 2,
    advanced: 3,
    ultimate: 4,
  };
  const currentTier = planName ? planTiers[planName] ?? 0 : 0;

  if (currentTier < minTier) {
    throw new Error("PLAN_UPGRADE_REQUIRED");
  }

  return { userId: user.id, planName };
}

const SESSION_COOKIE = "sc_session";
const SESSION_SECRET = process.env.SESSION_SECRET || "smart-coach-secret-key-change-in-prod";

// Hash a password using scrypt
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

// Verify a password against stored hash
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const hashBuf = Buffer.from(hash, "hex");
  const testBuf = scryptSync(password, salt, 64);
  if (hashBuf.length !== testBuf.length) return false;
  return timingSafeEqual(hashBuf, testBuf);
}

// Validate Iranian mobile number
export function validateMobile(mobile: string): boolean {
  return /^09\d{9}$/.test(mobile.replace(/\s/g, ""));
}

// Validate password strength (min 6 chars)
export function validatePassword(password: string): boolean {
  return password.length >= 6;
}

// Create a signed session token (base64 of userId + signature)
export function createSessionToken(userId: string): string {
  const payload = Buffer.from(JSON.stringify({ uid: userId, t: Date.now() })).toString("base64url");
  const sig = scryptSync(payload, SESSION_SECRET, 32).toString("hex");
  return `${payload}.${sig}`;
}

// Verify and decode session token
export function verifySessionToken(token: string): { uid: string; t: number } | null {
  try {
    const [payload, sig] = token.split(".");
    if (!payload || !sig) return null;
    const expectedSig = scryptSync(payload, SESSION_SECRET, 32).toString("hex");
    if (sig !== expectedSig) return null;
    const decoded = JSON.parse(Buffer.from(payload, "base64url").toString());
    return decoded;
  } catch {
    return null;
  }
}

// Set session cookie
export async function setSession(userId: string) {
  const token = createSessionToken(userId);
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
}

// Clear session cookie
export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

// Get current logged-in user (or null)
export async function getCurrentUser() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const decoded = verifySessionToken(token);
    if (!decoded) return null;
    const user = await db.user.findUnique({
      where: { id: decoded.uid },
    });
    if (!user || user.isBlocked) return null;
    return user;
  } catch {
    return null;
  }
}

// Require authentication - throws if not logged in
export async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("UNAUTHORIZED");
  }
  return user;
}

// Require admin role
export async function requireAdmin() {
  const user = await requireAuth();
  if (user.role !== "ADMIN") {
    throw new Error("FORBIDDEN");
  }
  return user;
}

// Standard API error handler
export function apiError(error: unknown) {
  const msg = error instanceof Error ? error.message : "خطای ناشناخته";
  if (msg === "UNAUTHORIZED") {
    return Response.json({ error: "ابتدا وارد حساب کاربری شوید." }, { status: 401 });
  }
  if (msg === "FORBIDDEN") {
    return Response.json({ error: "دسترسی غیرمجاز." }, { status: 403 });
  }
  if (msg === "PLAN_UPGRADE_REQUIRED") {
    return Response.json(
      {
        error: "این قابلیت در پلن شما فعال نیست. لطفاً پلن خود را ارتقا دهید.",
        code: "PLAN_UPGRADE_REQUIRED",
      },
      { status: 403 }
    );
  }
  console.error("[API Error]", msg);
  return Response.json({ error: msg }, { status: 500 });
}
