import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";
import {
  SUBSCRIPTION_PLANS,
  toPersianDigits,
  type Plan,
} from "@/lib/fitness/types";
import {
  zarinpalRequest,
  buildCallbackUrl,
  isZarinpalConfigured,
} from "@/lib/fitness/zarinpal";

export async function GET() {
  return Response.json({ plans: SUBSCRIPTION_PLANS });
}

interface CheckoutBody {
  planId: Plan;
  paymentMethod: "gateway" | "wallet";
  discountCode?: string;
  /** Per-user renewal discount code (validated against UserDiscountCode table) */
  userDiscountCode?: string;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const body = (await req.json()) as CheckoutBody;
    const plan = SUBSCRIPTION_PLANS.find((p) => p.id === body.planId);
    if (!plan) {
      return Response.json({ error: "پلن نامعتبر است." }, { status: 400 });
    }

    if (!["gateway", "wallet"].includes(body.paymentMethod)) {
      return Response.json({ error: "روش پرداخت نامعتبر است." }, { status: 400 });
    }

    let originalAmount = plan.price;
    let discountValue = 0;
    let discountCodeRecord: { id: string; code: string; type: string; value: number } | null = null;
    let userDiscountRecord: { id: string; code: string; type: string; value: number } | null = null;
    let appliedCode: string | null = null;

    // اعتبارسنجی و اعمال کد تخفیف عمومی
    if (body.discountCode) {
      const code = body.discountCode.trim().toUpperCase();
      const dc = await db.discountCode.findUnique({ where: { code } });
      if (!dc || !dc.active) {
        return Response.json({ error: "کد تخفیف نامعتبر است." }, { status: 400 });
      }
      if (dc.validUntil && dc.validUntil < new Date()) {
        return Response.json({ error: "کد تخفیف منقضی شده است." }, { status: 400 });
      }
      if (dc.maxUses !== -1 && dc.usedCount >= dc.maxUses) {
        return Response.json({ error: "سقف استفاده از این کد تخفیف تکمیل شده است." }, { status: 400 });
      }
      if (dc.applicablePlans !== "all") {
        const allowed = dc.applicablePlans.split(",");
        if (!allowed.includes(plan.id)) {
          return Response.json({ error: "این کد تخفیف برای پلن انتخاب‌شده قابل استفاده نیست." }, { status: 400 });
        }
      }
      discountCodeRecord = dc;
      appliedCode = dc.code;
      if (dc.type === "percent") {
        discountValue = Math.round((originalAmount * dc.value) / 100);
      } else {
        discountValue = Math.min(dc.value, originalAmount);
      }
    }

    // اعتبارسنجی و اعمال کد تخفیف اختصاصی کاربر (renewal loyalty)
    // اولویت: اگر هم کد عمومی هم کد اختصاصی داده شده، کد اختصاصی بر کد عمومی ارجحیت دارد.
    if (body.userDiscountCode) {
      const code = body.userDiscountCode.trim().toUpperCase();
      const udc = await db.userDiscountCode.findUnique({ where: { code } });
      if (!udc) {
        return Response.json({ error: "کد تخفیف اختصاصی یافت نشد." }, { status: 400 });
      }
      if (udc.userId !== user.id) {
        return Response.json({ error: "این کد تخفیف متعلق به حساب شما نیست." }, { status: 403 });
      }
      if (udc.isUsed) {
        return Response.json({ error: "این کد تخفیف قبلاً استفاده شده است." }, { status: 400 });
      }
      if (udc.validUntil && udc.validUntil < new Date()) {
        return Response.json({ error: "کد تخفیف اختصاصی منقضی شده است." }, { status: 400 });
      }
      // اگر کد عمومی هم داده شده، آن را نادیده می‌گیریم و کد اختصاصی را اعمال می‌کنیم
      if (discountCodeRecord) {
        discountValue = 0;
        discountCodeRecord = null;
      }
      userDiscountRecord = udc;
      appliedCode = udc.code;
      if (udc.type === "percent") {
        discountValue = Math.round((originalAmount * udc.value) / 100);
      } else {
        discountValue = Math.min(udc.value, originalAmount);
      }
    }

    const finalAmount = Math.max(0, originalAmount - discountValue);

    // اگر پرداخت از کیف پول، بررسی موجودی
    if (body.paymentMethod === "wallet") {
      const freshUser = await db.user.findUnique({ where: { id: user.id } });
      const balance = freshUser?.walletBalance ?? 0;
      if (balance < finalAmount) {
        return Response.json(
          {
            error: `موجودی کیف پول کافی نیست. موجودی: ${toPersianDigits(balance.toLocaleString("en-US"))} تومان، مبلغ لازم: ${toPersianDigits(finalAmount.toLocaleString("en-US"))} تومان.`,
            code: "INSUFFICIENT_WALLET",
            walletBalance: balance,
            required: finalAmount,
          },
          { status: 400 }
        );
      }
    }

    // مقداردهی اولیه authority — در صورت اتصال موفق به زرین‌پال، با authority واقعی جایگزین می‌شود
    let authority = `A000${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
    let gatewayUrl: string | null = null;
    let simulated = true;

    if (body.paymentMethod === "gateway") {
      const origin = req.nextUrl.origin ?? `${req.nextUrl.protocol}//${req.nextUrl.host}`;
      const callbackUrl = buildCallbackUrl(origin);

      // اگر کلید واقعی زرین‌پال پیکربندی شده باشد، به API واقعی زرین‌پال متصل می‌شویم
      if (isZarinpalConfigured()) {
        const zarinRes = await zarinpalRequest({
          amount: finalAmount, // Tomans
          description: `خرید پلن ${plan.label} فیتاپ — ${toPersianDigits(plan.durationDays)} روزه`,
          callbackUrl,
          mobile: user.mobile,
        });

        if (zarinRes.ok && zarinRes.authority && zarinRes.gatewayUrl) {
          authority = zarinRes.authority;
          gatewayUrl = zarinRes.gatewayUrl;
          simulated = false;
        }
        // اگر ok=false (مثلاً کلید تست معتبر نیست یا خطای شبکه)، به جریان شبیه‌سازی fallback می‌کنیم
      }

      if (!gatewayUrl) {
        // حالت شبیه‌سازی — ساخت authority محلی + URL شبیه‌سازی‌شده
        gatewayUrl = `https://www.zarinpal.com/pg/StartPay/${authority}`;
        simulated = true;
      }
    }

    const payment = await db.payment.create({
      data: {
        userId: user.id,
        amount: finalAmount,
        originalAmount,
        plan: plan.id,
        paymentMethod: body.paymentMethod,
        authority,
        status: "pending",
        discountCode: appliedCode,
        description: `خرید پلن ${plan.label} فیتاپ — ${toPersianDigits(plan.durationDays)} روزه`,
      },
    });

    return Response.json({
      paymentId: payment.id,
      authority,
      originalAmount,
      discountValue,
      finalAmount,
      plan,
      paymentMethod: body.paymentMethod,
      gatewayUrl,
      simulated,
      userDiscountCode: userDiscountRecord?.code ?? null,
      callbackUrl: body.paymentMethod === "gateway" ? buildCallbackUrl(req.nextUrl.origin ?? "") : null,
    });
  } catch (e) {
    return apiError(e);
  }
}
