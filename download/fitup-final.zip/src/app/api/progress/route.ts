import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";

export async function GET() {
  try {
    const user = await requireAuth();
    const [weights, photos, profile] = await Promise.all([
      db.weightLog.findMany({
        where: { userId: user.id },
        orderBy: { loggedAt: "asc" },
      }),
      db.progressPhoto.findMany({
        where: { userId: user.id },
        orderBy: { takenAt: "desc" },
      }),
      db.onboardingProfile.findUnique({ where: { userId: user.id } }),
    ]);
    return Response.json({
      weights: weights.map((w) => ({
        id: w.id,
        weight: w.weight,
        note: w.note,
        loggedAt: w.loggedAt.toISOString(),
      })),
      photos: photos.map((p) => ({
        id: p.id,
        imageUrl: p.imageUrl,
        type: p.type,
        note: p.note,
        takenAt: p.takenAt.toISOString(),
      })),
      startWeight: profile?.weight ?? null,
      targetWeight: profile?.targetWeight ?? null,
    });
  } catch (e) {
    return apiError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const { weight, note } = await req.json();
    if (!weight || weight < 30 || weight > 250) {
      return Response.json({ error: "وزن نامعتبر است." }, { status: 400 });
    }
    const log = await db.weightLog.create({
      data: { userId: user.id, weight: Number(weight), note: String(note || "") },
    });

    // Check achievement
    const profile = await db.onboardingProfile.findUnique({
      where: { userId: user.id },
    });
    if (profile?.targetWeight && Number(weight) <= profile.targetWeight) {
      await db.notification.create({
        data: {
          userId: user.id,
          type: "achievement",
          title: "تبریک! به وزن هدف رسیدید! 🏆",
          body: `شما به وزن هدف خود (${profile.targetWeight} کیلوگرم) رسیدید. عالی بود!`,
          link: "?tab=progress",
          read: false,
        },
      });
    }

    return Response.json({
      id: log.id,
      weight: log.weight,
      note: log.note,
      loggedAt: log.loggedAt.toISOString(),
    });
  } catch (e) {
    return apiError(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "ID نیاز است." }, { status: 400 });
    await db.weightLog.deleteMany({ where: { id, userId: user.id } });
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}
