import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { aiChat, avalaiClient, VISION_MODEL } from "@/lib/fitness/ai";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import type { OnboardingData } from "@/lib/fitness/types";

/**
 * پارس data URL به mime و base64.
 * پشتیبانی از هر دو فرمت:
 *  - "data:image/jpeg;base64,...."
 *  - raw base64 با mime جداگانه
 */
function parseDataUrl(value: string, fallbackMime = "image/jpeg"): { mime: string; base64: string } {
  const match = value.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return { mime: match[1], base64: match[2] };
  }
  return { mime: fallbackMime, base64: value };
}

/** ذخیره فایل base64 در public/uploads/chat/ و بازگرداندن URL نسبی */
async function saveBase64File(
  base64: string,
  mime: string,
  kind: "image" | "video"
): Promise<{ url: string; mime: string; size: number }> {
  const buffer = Buffer.from(base64, "base64");
  const extMap: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/avif": "avif",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
    "video/x-matroska": "mkv",
  };
  const ext = extMap[mime] || (kind === "image" ? "jpg" : "mp4");
  const fileName = `chat-${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const uploadDir = path.join(process.cwd(), "public", "uploads", "chat");
  await mkdir(uploadDir, { recursive: true });
  const filePath = path.join(uploadDir, fileName);
  await writeFile(filePath, buffer);
  return { url: `/uploads/chat/${fileName}`, mime, size: buffer.length };
}

export async function GET() {
  try {
    const user = await requireAuth();
    const messages = await db.chatMessage.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "asc" },
      take: 100,
    });
    return Response.json({
      messages: messages.map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        mediaUrl: m.mediaUrl ?? null,
        mediaType: m.mediaType ?? null,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  } catch (e) {
    return apiError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    // گیت پلن: چت با مربی هوشمند فقط برای پلن پیشرفته و حرفه‌ای
    const { userId } = await requirePlanCapability("aiChat");
    const user = await requireAuth();
    const body = await req.json();
    const message: string = typeof body.message === "string" ? body.message : "";
    const imageBase64: string | undefined = typeof body.imageBase64 === "string" ? body.imageBase64 : undefined;
    const videoBase64: string | undefined = typeof body.videoBase64 === "string" ? body.videoBase64 : undefined;

    if (!message && !imageBase64 && !videoBase64) {
      return Response.json({ error: "پیام خالی است." }, { status: 400 });
    }

    // متغیرهای مدیا
    let imageUrl: string | null = null;
    let videoUrl: string | null = null;
    let imageAnalysisNote = ""; // توضیح کوتاه VLM از عکس برای درج در پرامپت مربی

    // پردازش عکس (نیازمند قابلیت chatImageUpload)
    if (imageBase64) {
      // گیت پلن برای ارسال عکس در چت
      await requirePlanCapability("chatImageUpload");
      // اعتبارسنجی حجم (حداکثر ۵ مگابایت قبل از base64 ≈ ۶.۶ مگابایت base64)
      const MAX_IMG = 7 * 1024 * 1024;
      if (imageBase64.length > MAX_IMG) {
        return Response.json({ error: "حجم عکس بیش از حد مجاز (۵ مگابایت) است." }, { status: 400 });
      }
      const parsed = parseDataUrl(imageBase64, "image/jpeg");
      if (!parsed.mime.startsWith("image/")) {
        return Response.json({ error: "فقط فایل تصویری مجاز است." }, { status: 400 });
      }
      const saved = await saveBase64File(parsed.base64, parsed.mime, "image");
      imageUrl = saved.url;

      // تحلیل عکس با VLM برای افزودن به کانتکست مربی
      try {
        const vlmPrompt = "این عکس را به اختصار به فارسی توصیف کن. اگر غذا است، مواد و کالری تخمینی را بگو. اگر بدن/فرم ورزشی است، توصیف کوتاه بده. اگر سوال فنی است (مثل دستگاه باشگاه)، توضیح بده. حداکثر ۳ جمله.";
        const response = await avalaiClient.chat.completions.create({
          model: VISION_MODEL,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: vlmPrompt },
                { type: "image_url", image_url: { url: `data:${parsed.mime};base64,${parsed.base64}` } },
              ],
            },
          ],
        } as any);
        const vlmText = response.choices[0]?.message?.content || "";
        if (vlmText) {
          imageAnalysisNote = `\n\n[کاربر عکس ارسال کرده است. توصیف عکس توسط VLM: ${vlmText}]`;
        }
      } catch (err) {
        console.error("[chat] image VLM analysis failed:", err);
        imageAnalysisNote = `\n\n[کاربر عکس ارسال کرده است اما تحلیل خودکار آن ناموفق بود. لطفاً از کاربر بخواه توضیح بدهد.]`;
      }
    }

    // پردازش ویدیو (نیازمند قابلیت chatVideoUpload)
    if (videoBase64) {
      // گیت پلن برای ارسال ویدیو در چت
      await requirePlanCapability("chatVideoUpload");
      // اعتبارسنجی حجم (حداکثر ۲۰ مگابایت قبل از base64 ≈ ۲۶ مگابایت base64)
      const MAX_VID = 27 * 1024 * 1024;
      if (videoBase64.length > MAX_VID) {
        return Response.json({ error: "حجم ویدیو بیش از حد مجاز (۲۰ مگابایت) است." }, { status: 400 });
      }
      const parsed = parseDataUrl(videoBase64, "video/mp4");
      if (!parsed.mime.startsWith("video/")) {
        return Response.json({ error: "فقط فایل ویدیویی مجاز است." }, { status: 400 });
      }
      const saved = await saveBase64File(parsed.base64, parsed.mime, "video");
      videoUrl = saved.url;
      // تحلیل ویدیو جداگانه انجام می‌شود؛ در اینجا فقط یک یادآوری به مربی اضافه می‌کنیم
    }

    // ساخت محتوای نهایی پیام کاربر (شامل یادآوری مدیا برای مربی)
    let finalMessage = message;
    if (imageAnalysisNote) {
      finalMessage = `${message || "(بدون متن)"}${imageAnalysisNote}`;
    }
    if (videoUrl) {
      finalMessage = `${finalMessage}${message ? "\n\n" : ""}[کاربر ویدیو ارسال کرده است. تحلیل ویدیو به‌صورت جداگانه انجام می‌شود. اگر کاربر درباره محتوای ویدیو سوال پرسید، راهنمایی‌اش کن که از بخش آنالیز ویدیو استفاده کند.]`;
    }

    // ذخیره پیام کاربر (با URL مدیا)
    const userMsg = await db.chatMessage.create({
      data: {
        userId: user.id,
        role: "user",
        content: message || (imageUrl ? "📷 عکس" : videoUrl ? "🎬 ویدیو" : ""),
        mediaUrl: imageUrl ?? videoUrl,
        mediaType: imageUrl ? "image" : videoUrl ? "video" : null,
      },
    });

    // Load onboarding profile for context
    const profile = await db.onboardingProfile.findUnique({
      where: { userId: user.id },
    });
    let onboarding: OnboardingData | null = null;
    if (profile) {
      onboarding = {
        gender: profile.gender as OnboardingData["gender"],
        age: profile.age,
        height: profile.height,
        weight: profile.weight,
        targetWeight: profile.targetWeight ?? undefined,
        goal: profile.goal as OnboardingData["goal"],
        activityLevel: profile.activityLevel as OnboardingData["activityLevel"],
        workoutDays: profile.workoutDays,
        workoutPlace: profile.workoutPlace as OnboardingData["workoutPlace"],
        equipment: JSON.parse(profile.equipment || "[]"),
        diseases: profile.diseases,
        injuries: profile.injuries,
        allergies: profile.allergies,
        dietType: profile.dietType as OnboardingData["dietType"],
      };
    }

    // ─── Build comprehensive athletic profile for long-term memory ───
    // فیتاپ هوشمند به تمام پرونده ورزشی کاربر دسترسی دارد:
    const [workoutPlan, mealPlan, recentWeights, latestCheckup, programRequests] = await Promise.all([
      db.workoutPlan.findFirst({ where: { userId: user.id, active: true }, orderBy: { createdAt: "desc" } }),
      db.mealPlan.findFirst({ where: { userId: user.id, active: true }, orderBy: { createdAt: "desc" } }),
      db.weightLog.findMany({ where: { userId: user.id }, orderBy: { loggedAt: "desc" }, take: 5 }),
      db.checkup.findFirst({ where: { userId: user.id }, orderBy: { createdAt: "desc" } }),
      db.programRequest.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 3 }),
    ]);

    // Build athletic profile context string
    const athleticProfile: string[] = [];
    if (workoutPlan) {
      const wc = JSON.parse(workoutPlan.content);
      athleticProfile.push(`\n📋 برنامه تمرینی فعلی:\n- هدف هفته: ${wc.weeklyGoal || "نامشخص"}\n- تعداد روزهای تمرین: ${wc.days?.length || 0}\n- نکات هفته: ${wc.notes?.slice(0, 100) || "ندارد"}`);
    }
    if (mealPlan) {
      const mc = JSON.parse(mealPlan.content);
      athleticProfile.push(`\n🍽 برنامه غذایی فعلی:\n- کالری هدف: ${mc.totalCalories || "نامشخص"} کالری\n- تعداد وعده‌ها: ${mc.meals?.length || 0}\n- پروتئین: ${mc.totalProtein || 0}g، کربو: ${mc.totalCarbs || 0}g، چربی: ${mc.totalFat || 0}g\n- آب روزانه: ${mc.waterLiters || 2.5} لیتر`);
      if (mc.supplements?.length) {
        athleticProfile.push(`\n💊 مکمل‌های فعلی: ${mc.supplements.map((s: any) => `${s.name} (${s.dose})`).join("، ")}`);
      }
    }
    if (recentWeights.length > 0) {
      const latest = recentWeights[0];
      const first = recentWeights[recentWeights.length - 1];
      const change = (latest.weight - first.weight).toFixed(1);
      athleticProfile.push(`\n⚖️ پیشرفت وزن:\n- وزن فعلی: ${latest.weight} کیلوگرم\n- تغییر اخیر: ${Number(change) > 0 ? "+" : ""}${change} کیلوگرم\n- تاریخ آخرین ثبت: ${latest.loggedAt.toLocaleDateString("fa-IR")}`);
    }
    if (latestCheckup) {
      athleticProfile.push(`\n📊 آخرین چکاپ:\n- وزن: ${latestCheckup.weight} کیلوگرم${latestCheckup.bodyFatPercent ? `\n- چربی بدن: ${latestCheckup.bodyFatPercent}٪` : ""}${latestCheckup.waistMeasurement ? `\n- دور کمر: ${latestCheckup.waistMeasurement} سانتی‌متر` : ""}${latestCheckup.armMeasurement ? `\n- دور بازو: ${latestCheckup.armMeasurement} سانتی‌متر` : ""}\n- خستگی: ${latestCheckup.fatigueLevel}/5\n- کیفیت خواب: ${latestCheckup.sleepQuality}/5\n- رعایت رژیم: ${latestCheckup.dietAdherence}/5\n- رعایت تمرین: ${latestCheckup.workoutAdherence}/5`);
    }
    if (programRequests.length > 0) {
      athleticProfile.push(`\n📝 تاریخچه برنامه‌ها: ${programRequests.length} دوره تمرینی (${programRequests[0].status === "ready" ? "آماده" : programRequests[0].status === "pending" ? "در انتظار" : "نامشخص"})`);
    }

    // Load recent history (last 30 messages for better memory)
    const history = await db.chatMessage.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "asc" },
      take: 30,
    });

    // Get AI response — pass user's plan tier + full athletic profile for comprehensive guidance
    const userPlan = (user.planName as any) ?? null;
    const fullContext = athleticProfile.join("\n");
    const aiResponse = await aiChat(
      onboarding,
      history.map((h) => ({ role: h.role, content: h.content })),
      finalMessage + (fullContext ? `\n\n[سیستم - پرونده ورزشی کاربر]:${fullContext}` : ""),
      userPlan
    );

    // Save AI response
    const aiMsg = await db.chatMessage.create({
      data: { userId: user.id, role: "assistant", content: aiResponse },
    });

    return Response.json({
      userMessage: {
        id: userMsg.id,
        role: userMsg.role,
        content: userMsg.content,
        mediaUrl: userMsg.mediaUrl ?? null,
        mediaType: userMsg.mediaType ?? null,
        createdAt: userMsg.createdAt.toISOString(),
      },
      aiMessage: {
        id: aiMsg.id,
        role: aiMsg.role,
        content: aiMsg.content,
        mediaUrl: null,
        mediaType: null,
        createdAt: aiMsg.createdAt.toISOString(),
      },
    });
  } catch (e) {
    return apiError(e);
  }
}
