import { NextRequest } from "next/server";
import { requireAuth, requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { analyzeVideoBody } from "@/lib/fitness/ai";

export async function POST(req: NextRequest) {
  try {
    await requirePlanCapability("videoBodyAnalysis");
    const { base64Video, mimeType, userContext } = await req.json();
    if (!base64Video) return Response.json({ error: "ویدیو ارسال نشده." }, { status: 400 });
    const result = await analyzeVideoBody(base64Video, mimeType || "video/mp4", userContext || "");
    return Response.json(result);
  } catch (e) {
    return apiError(e);
  }
}
