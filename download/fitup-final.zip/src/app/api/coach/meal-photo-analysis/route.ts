import { NextRequest } from "next/server";
import { requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { avalaiClient, VISION_MODEL } from "@/lib/fitness/ai";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

/**
 * POST /api/coach/meal-photo-analysis
 * آنالیز هوشمند عکس غذا با VLM (gemini-3.5-flash).
 * - نیازمند پلن پیشرفته یا حرفه‌ای (قابلیت mealPhotoAnalysis)
 * - multipart/form-data با فیلد "image"
 * - حداکثر حجم: ۵ مگابایت
 * - فقط image/*
 * - خروجی: { analysis: string, imageUrl: string }
 */
export async function POST(req: NextRequest) {
  try {
    // گیت پلن: آنالیز عکس غذا فقط برای Advanced+
    await requirePlanCapability("mealPhotoAnalysis");

    const formData = await req.formData();
    const file = formData.get("image");
    if (!file || !(file instanceof File)) {
      return Response.json({ error: "تصویری ارسال نشده است." }, { status: 400 });
    }

    // اعتبارسنجی نوع فایل
    if (!file.type.startsWith("image/")) {
      return Response.json({ error: "فقط فایل تصویری مجاز است." }, { status: 400 });
    }

    // اعتبارسنجی حجم فایل (حداکثر ۵ مگابایت)
    const MAX_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      return Response.json({ error: "حداکثر حجم فایل ۵ مگابایت است." }, { status: 400 });
    }

    // تولید نام فایل یکتا
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const allowedExts = ["jpg", "jpeg", "png", "webp", "gif", "avif"];
    const finalExt = allowedExts.includes(ext) ? ext : "jpg";
    const fileName = `meal-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${finalExt}`;

    // ذخیره فایل در public/uploads/meal-analysis/
    const uploadDir = path.join(process.cwd(), "public", "uploads", "meal-analysis");
    await mkdir(uploadDir, { recursive: true });
    const filePath = path.join(uploadDir, fileName);
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(filePath, buffer);

    const imageUrl = `/uploads/meal-analysis/${fileName}`;

    // تبدیل به base64 برای ارسال به VLM
    const mimeType = file.type || "image/jpeg";
    const base64Image = buffer.toString("base64");

    // پرامپت فارسی برای VLM
    const prompt = `این عکس غذا را تحلیل کن. مواد تشکیل‌دهنده، کالری تخمینی، پروتئین، کربوهیدرات و چربی را به فارسی بگو. اگر عکس غذا نیست، بگو 'عکس واضح نیست'. فرمت:

🍽 غذاهای شناسایی‌شده:
🔥 کالری تخمینی: X کالری
💪 پروتئین: Xg
🍞 کربو: Xg
🥑 چربی: Xg
💡 تحلیل: ...`;

    let analysis = "";
    try {
      const response = await avalaiClient.chat.completions.create({
        model: VISION_MODEL,
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64Image}` } },
            ],
          },
        ],
      } as any);
      analysis = response.choices[0]?.message?.content || "تحلیلی دریافت نشد. لطفاً دوباره تلاش کنید.";
    } catch (err) {
      console.error("[meal-photo-analysis] VLM error:", err);
      throw new Error("خطا در آنالیز عکس غذا. لطفاً دوباره تلاش کنید.");
    }

    return Response.json({ analysis, imageUrl });
  } catch (e) {
    return apiError(e);
  }
}
