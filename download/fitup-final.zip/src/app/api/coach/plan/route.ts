import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";
import { generateWorkoutPlan, generateMealPlan } from "@/lib/fitness/ai";
import type { OnboardingData } from "@/lib/fitness/types";

/**
 * Robustly parse the equipment field which may be stored as:
 * - JSON array string: '["dumbbell","barbell"]'
 * - CSV string: "dumbbell,barbell" (legacy data)
 * - Empty string or null
 */
function safeParseEquipment(raw: string | null | undefined): string[] {
  if (!raw) return [];
  const trimmed = raw.trim();
  if (!trimmed) return [];
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) return parsed.map((x) => String(x));
    if (typeof parsed === "string") {
      return parsed.split(",").map((s) => s.trim()).filter(Boolean);
    }
    return [];
  } catch {
    return trimmed.split(",").map((s) => s.trim()).filter(Boolean);
  }
}

// Get active workout + meal plan
export async function GET() {
  try {
    const user = await requireAuth();
    const [workout, meal, profile] = await Promise.all([
      db.workoutPlan.findFirst({
        where: { userId: user.id, active: true },
        orderBy: { createdAt: "desc" },
      }),
      db.mealPlan.findFirst({
        where: { userId: user.id, active: true },
        orderBy: { createdAt: "desc" },
      }),
      db.onboardingProfile.findUnique({ where: { userId: user.id } }),
    ]);

    return Response.json({
      workout: workout ? JSON.parse(workout.content) : null,
      meal: meal ? JSON.parse(meal.content) : null,
      hasProfile: !!profile,
    });
  } catch (e) {
    return apiError(e);
  }
}

// Regenerate plans
export async function PUT() {
  try {
    const user = await requireAuth();
    const profile = await db.onboardingProfile.findUnique({
      where: { userId: user.id },
    });
    if (!profile) {
      return Response.json({ error: "ابتدا آنبوردینگ را تکمیل کنید." }, { status: 400 });
    }

    const data: OnboardingData = {
      gender: profile.gender as OnboardingData["gender"],
      age: profile.age,
      height: profile.height,
      weight: profile.weight,
      targetWeight: profile.targetWeight ?? undefined,
      goal: profile.goal as OnboardingData["goal"],
      activityLevel: profile.activityLevel as OnboardingData["activityLevel"],
      workoutDays: profile.workoutDays,
      workoutPlace: profile.workoutPlace as OnboardingData["workoutPlace"],
      equipment: safeParseEquipment(profile.equipment),
      diseases: profile.diseases,
      injuries: profile.injuries,
      allergies: profile.allergies,
      dietType: profile.dietType as OnboardingData["dietType"],
    };

    await db.workoutPlan.updateMany({
      where: { userId: user.id },
      data: { active: false },
    });
    await db.mealPlan.updateMany({
      where: { userId: user.id },
      data: { active: false },
    });

    const userPlan = (user.planName as any) ?? null;
    const [workout, meal] = await Promise.all([
      generateWorkoutPlan(data, userPlan),
      generateMealPlan(data, userPlan),
    ]);

    await db.workoutPlan.create({
      data: { userId: user.id, content: JSON.stringify(workout), active: true },
    });
    await db.mealPlan.create({
      data: { userId: user.id, content: JSON.stringify(meal), totalCal: meal.totalCalories, active: true },
    });

    return Response.json({ workout, meal });
  } catch (e) {
    return apiError(e);
  }
}
