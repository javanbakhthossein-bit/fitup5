import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { generateWorkoutPlan, generateMealPlan } from "@/lib/fitness/ai";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import type { OnboardingData } from "@/lib/fitness/types";

/**
 * GET /api/coach/submit-body-analysis
 * بررسی وضعیت ارسال مدیای بدن برای کاربر فعلی.
 * پاسخ شامل:
 *  - needsBodyPhoto: آیا عکس بدن لازم است؟ (Advanced / Ultimate)
 *  - needsBodyVideo: آیا ویدیو لازم است؟ (Ultimate)
 *  - pendingStatus: وضعیت فعلی ProgramRequest (pending_body_photo / pending_body_media / ready / ...)
 *  - hasWorkoutPlan: آیا برنامه تمرینی فعال دارد؟
 */
export async function GET() {
  try {
    const { userId, planName } = await requirePlanCapability("bodyPhotoAnalysis");

    const needsBodyPhoto = planName === "advanced" || planName === "ultimate";
    const needsBodyVideo = planName === "ultimate";

    const [latestReq, workout] = await Promise.all([
      db.programRequest.findFirst({
        where: { userId },
        orderBy: { createdAt: "desc" },
      }),
      db.workoutPlan.findFirst({
        where: { userId, active: true },
        orderBy: { createdAt: "desc" },
      }),
    ]);

    const pendingStatus = latestReq?.status ?? null;
    const hasWorkoutPlan = !!workout;

    // اگر کاربر پلن Advanced/Ultimate دارد ولی برنامه‌اش آماده نشده و وضعیتش pending است
    const awaitingMedia =
      needsBodyPhoto &&
      !hasWorkoutPlan &&
      (pendingStatus === "pending_body_photo" ||
        pendingStatus === "pending_body_media" ||
        pendingStatus === "generating");

    return Response.json({
      needsBodyPhoto,
      needsBodyVideo,
      pendingStatus,
      hasWorkoutPlan,
      awaitingMedia,
    });
  } catch (e) {
    return apiError(e);
  }
}

/**
 * POST /api/coach/submit-body-analysis
 * multipart/form-data:
 *   - bodyPhotos: File[] (۱ تا ۴ تصویر)
 *   - bodyVideo: File (اختیاری — برای Ultimate الزامی است)
 *
 * ۱. عکس‌ها و ویدیو را در public/uploads/body-analysis ذخیره می‌کند.
 * ۲. در ProgressPhoto ثبت می‌کند (type=front/side/back/custom).
 * ۳. اگر همه‌ی مدیاهای لازم ارسال شده باشد، برنامه تمرینی و غذایی را تولید می‌کند.
 * ۴. وضعیت ProgramRequest را روی "ready" می‌گذارد.
 * ۵. نوتیفیکیشن «برنامه شما آماده شد! 🎯» می‌سازد.
 */
export async function POST(req: NextRequest) {
  try {
    const { userId, planName } = await requirePlanCapability("bodyPhotoAnalysis");

    const needsBodyVideo = planName === "ultimate";

    const formData = await req.formData();
    const photoFiles = formData.getAll("bodyPhotos").filter(
      (f): f is File => f instanceof File && f.size > 0 && f.type.startsWith("image/")
    );
    const videoFile = formData.get("bodyVideo");
    const video = videoFile instanceof File && videoFile.size > 0 ? videoFile : null;

    // اعتبارسنجی حداقل‌ها
    if (photoFiles.length === 0) {
      return Response.json(
        { error: "حداقل یک عکس از بدن ارسال کنید." },
        { status: 400 }
      );
    }
    if (photoFiles.length > 4) {
      return Response.json(
        { error: "حداکثر ۴ عکس مجاز است." },
        { status: 400 }
      );
    }
    if (needsBodyVideo && !video) {
      return Response.json(
        { error: "برای پلن حرفه‌ای، ارسال ویدیو الزامی است." },
        { status: 400 }
      );
    }
    // اعتبارسنجی حجم — عکس‌ها ۵MB، ویدیو ۲۰MB
    for (const f of photoFiles) {
      if (f.size > 5 * 1024 * 1024) {
        return Response.json({ error: "حجم هر عکس نباید بیشتر از ۵ مگابایت باشد." }, { status: 400 });
      }
    }
    if (video && video.size > 20 * 1024 * 1024) {
      return Response.json({ error: "حجم ویدیو نباید بیشتر از ۲۰ مگابایت باشد." }, { status: 400 });
    }

    // ذخیره فایل‌ها
    const uploadDir = path.join(process.cwd(), "public", "uploads", "body-analysis");
    await mkdir(uploadDir, { recursive: true });

    const allowedImgExts = ["jpg", "jpeg", "png", "webp", "avif", "gif"];
    const savedPhotoUrls: string[] = [];
    const photoTypes = ["front", "side", "back", "custom"];

    for (let i = 0; i < photoFiles.length; i++) {
      const file = photoFiles[i];
      const ext = (file.name.split(".").pop() || "").toLowerCase();
      const finalExt = allowedImgExts.includes(ext) ? ext : "jpg";
      const fileName = `body-${userId}-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}.${finalExt}`;
      const filePath = path.join(uploadDir, fileName);
      const buffer = Buffer.from(await file.arrayBuffer());
      await writeFile(filePath, buffer);
      const url = `/uploads/body-analysis/${fileName}`;
      savedPhotoUrls.push(url);

      // ثبت در ProgressPhoto
      await db.progressPhoto.create({
        data: {
          userId,
          imageUrl: url,
          type: photoTypes[i] ?? "custom",
          note: "آپلود برای طراحی برنامه (Body Analysis)",
        },
      });
    }

    let savedVideoUrl: string | null = null;
    if (video) {
      const allowedVidExts = ["mp4", "webm", "mov", "m4v", "mkv"];
      const vext = (video.name.split(".").pop() || "").toLowerCase();
      const finalVext = allowedVidExts.includes(vext) ? vext : "mp4";
      const vFileName = `body-video-${userId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.${finalVext}`;
      const vFilePath = path.join(uploadDir, vFileName);
      const vBuffer = Buffer.from(await video.arrayBuffer());
      await writeFile(vFilePath, vBuffer);
      savedVideoUrl = `/uploads/body-analysis/${vFileName}`;
    }

    // --- تولید برنامه تمرینی + غذایی ---
    // همان منطق /api/coach/plan PUT با اضافه‌ی ثبت لینک مدیا در notification
    const profile = await db.onboardingProfile.findUnique({ where: { userId } });
    if (!profile) {
      return Response.json({ error: "ابتدا آنبوردینگ را تکمیل کنید." }, { status: 400 });
    }

    // Helpers برای پارس کردن فیلدهای ذخیره‌شده
    const safeParseList = (raw: string | null | undefined): string[] => {
      if (!raw) return [];
      const t = raw.trim();
      if (!t) return [];
      try {
        const p = JSON.parse(t);
        if (Array.isArray(p)) return p.map((x) => String(x));
        if (typeof p === "string") return p.split(",").map((s) => s.trim()).filter(Boolean);
        return [];
      } catch {
        return t.split(",").map((s) => s.trim()).filter(Boolean);
      }
    };

    const planData: OnboardingData = {
      gender: profile.gender as OnboardingData["gender"],
      age: profile.age,
      height: profile.height,
      weight: profile.weight,
      targetWeight: profile.targetWeight ?? undefined,
      goal: profile.goal as OnboardingData["goal"],
      activityLevel: profile.activityLevel as OnboardingData["activityLevel"],
      workoutDays: profile.workoutDays,
      workoutDaysList: safeParseList(profile.workoutDaysList),
      workoutPlace: profile.workoutPlace as OnboardingData["workoutPlace"],
      equipment: safeParseList(profile.equipment),
      diseases: profile.diseases,
      injuries: profile.injuries,
      allergies: profile.allergies,
      dietType: profile.dietType as OnboardingData["dietType"],
      trainingExperience: (profile.trainingExperience ?? undefined) as OnboardingData["trainingExperience"],
      previousTrainingType: profile.previousTrainingType ?? undefined,
      drugAllergies: profile.drugAllergies ?? undefined,
      currentMedications: profile.currentMedications ?? undefined,
      maxLifts: profile.maxLifts ?? undefined,
    };

    // غیرفعال‌سازی برنامه‌های قبلی
    await db.workoutPlan.updateMany({ where: { userId }, data: { active: false } });
    await db.mealPlan.updateMany({ where: { userId }, data: { active: false } });

    const [workout, meal] = await Promise.all([
      generateWorkoutPlan(planData, planName),
      generateMealPlan(planData, planName),
    ]);

    await db.workoutPlan.create({
      data: { userId, content: JSON.stringify(workout), active: true },
    });
    await db.mealPlan.create({
      data: { userId, content: JSON.stringify(meal), totalCal: meal.totalCalories, active: true },
    });

    // به‌روزرسانی وضعیت ProgramRequest به "ready"
    const latestReq = await db.programRequest.findFirst({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });
    if (latestReq) {
      await db.programRequest.update({
        where: { id: latestReq.id },
        data: { status: "ready" },
      });
    }

    // نوتیفیکیشن «برنامه شما آماده شد»
    await db.notification.create({
      data: {
        userId,
        type: "achievement",
        title: "برنامه شما آماده شد! 🎯",
        body: "بر اساس عکس‌های بدن شما، فیتاپ هوشمند برنامه تمرینی و غذایی شخصی‌سازی‌شده طراحی کرد. از بخش «تمرینات» و «تغذیه» مشاهده کنید.",
        link: "?tab=workouts",
        read: false,
      },
    });

    return Response.json({
      ok: true,
      photos: savedPhotoUrls,
      video: savedVideoUrl,
      hasWorkoutPlan: true,
      pendingStatus: "ready",
      awaitingMedia: false,
      message: "عکس‌های بدن ثبت شد و برنامه شما ساخته شد.",
    });
  } catch (e) {
    return apiError(e);
  }
}
