import { NextRequest } from "next/server";
import { requireAuth, requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { analyzeBloodTest } from "@/lib/fitness/ai";

export async function POST(req: NextRequest) {
  try {
    await requirePlanCapability("bloodTestAnalysis");
    const { base64Image, mimeType } = await req.json();
    if (!base64Image) return Response.json({ error: "تصویر ارسال نشده." }, { status: 400 });
    const result = await analyzeBloodTest(base64Image, mimeType || "image/jpeg");
    return Response.json(result);
  } catch (e) {
    return apiError(e);
  }
}
