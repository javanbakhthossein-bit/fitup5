import { NextRequest } from "next/server";
import { requireAuth, requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { analyzeMealPhoto } from "@/lib/fitness/ai";

export async function POST(req: NextRequest) {
  try {
    await requirePlanCapability("mealPhotoAnalysis");
    const { base64Image, mimeType, userContext } = await req.json();
    if (!base64Image) return Response.json({ error: "تصویر ارسال نشده." }, { status: 400 });
    const result = await analyzeMealPhoto(base64Image, mimeType || "image/jpeg", userContext || "");
    return Response.json(result);
  } catch (e) {
    return apiError(e);
  }
}
