import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, apiError } from "@/lib/fitness/auth";

const VALID_CATEGORIES = ["general", "nutrition", "training", "motivation", "news"];

function slugify(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/[^\u0600-\u06FF\u0030-\u0039a-zA-Z\s-]/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 80) || `article-${Date.now()}`;
}

// GET /api/articles — public list of published articles with pagination, category filter, search
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const page = Math.max(1, Number(searchParams.get("page") || 1));
    const pageSize = Math.min(50, Math.max(1, Number(searchParams.get("pageSize") || 12)));
    const category = searchParams.get("category") || "";
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";

    // Public endpoint: only published. Admin endpoint: allow status filter
    const where: any = {};
    if (status && ["draft", "published"].includes(status)) {
      where.status = status;
    } else {
      where.status = "published";
    }
    if (category && VALID_CATEGORIES.includes(category)) {
      where.category = category;
    }
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { excerpt: { contains: search } },
        { tags: { contains: search } },
      ];
    }

    const [total, articles] = await Promise.all([
      db.article.count({ where }),
      db.article.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          author: {
            select: { id: true, name: true },
          },
        },
      }),
    ]);

    return Response.json({
      articles: articles.map((a) => ({
        id: a.id,
        title: a.title,
        slug: a.slug,
        excerpt: a.excerpt,
        category: a.category,
        tags: a.tags,
        status: a.status,
        authorName: a.author?.name || "تیم فیتاپ",
        coverImage: a.coverImage,
        views: a.views,
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
      })),
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize),
    });
  } catch (e) {
    return apiError(e);
  }
}

// POST /api/articles — create article (admin only)
export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const body = await req.json();
    const {
      title, slug, excerpt, content, category, tags, status, coverImage,
      seoTitle, seoDescription, metaKeywords, canonicalUrl, ogImage, robots, readingMinutes,
    } = body || {};

    if (!title || typeof title !== "string" || title.trim().length < 3) {
      return Response.json({ error: "عنوان مقاله حداقل ۳ کاراکتر باید باشد." }, { status: 400 });
    }
    if (!content || typeof content !== "string" || content.trim().length < 10) {
      return Response.json({ error: "محتوای مقاله بسیار کوتاه است." }, { status: 400 });
    }

    const finalSlug = (typeof slug === "string" && slug.trim() ? slugify(slug) : slugify(title));
    // Ensure slug uniqueness
    const existing = await db.article.findUnique({ where: { slug: finalSlug } });
    if (existing) {
      return Response.json({ error: "این شناسه (slug) قبلاً استفاده شده است." }, { status: 400 });
    }

    const finalCategory = VALID_CATEGORIES.includes(category) ? category : "general";
    const finalStatus = status === "published" ? "published" : "draft";

    // Estimate reading time if not provided (200 wpm for Persian)
    let readingMins = 3;
    try {
      const wordCount = content.trim().split(/\s+/).length;
      readingMins = Math.max(1, Math.ceil(wordCount / 200));
    } catch {}
    if (Number.isFinite(readingMinutes) && readingMinutes > 0) {
      readingMins = readingMinutes;
    }

    const article = await db.article.create({
      data: {
        title: title.trim(),
        slug: finalSlug,
        excerpt: typeof excerpt === "string" ? excerpt.trim() : "",
        content,
        category: finalCategory,
        tags: typeof tags === "string" ? tags.trim() : "",
        status: finalStatus,
        coverImage: typeof coverImage === "string" ? coverImage.trim() : "",
        seoTitle: typeof seoTitle === "string" ? seoTitle.trim() : "",
        seoDescription: typeof seoDescription === "string" ? seoDescription.trim() : "",
        metaKeywords: typeof metaKeywords === "string" ? metaKeywords.trim() : "",
        canonicalUrl: typeof canonicalUrl === "string" ? canonicalUrl.trim() : "",
        ogImage: typeof ogImage === "string" ? ogImage.trim() : "",
        robots: typeof robots === "string" && robots.trim() ? robots.trim() : "index,follow",
        readingMinutes: readingMins,
        authorId: admin.id,
      },
    });

    return Response.json({
      article: {
        ...article,
        createdAt: article.createdAt.toISOString(),
        updatedAt: article.updatedAt.toISOString(),
      },
    });
  } catch (e) {
    return apiError(e);
  }
}
