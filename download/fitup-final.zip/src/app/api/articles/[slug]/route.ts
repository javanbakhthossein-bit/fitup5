import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, apiError } from "@/lib/fitness/auth";

const VALID_CATEGORIES = ["general", "nutrition", "training", "motivation", "news"];

function slugify(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/[^\u0600-\u06FF\u0030-\u0039a-zA-Z\s-]/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 80) || `article-${Date.now()}`;
}

// GET /api/articles/[slug] — public single article (increments views)
export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const article = await db.article.findUnique({
      where: { slug },
      include: { author: { select: { id: true, name: true } } },
    });
    if (!article) {
      return Response.json({ error: "مقاله یافت نشد." }, { status: 404 });
    }
    // Only published articles are publicly viewable (allow preview of drafts via admin only)
    if (article.status !== "published") {
      try {
        await requireAdmin();
      } catch {
        return Response.json({ error: "مقاله یافت نشد." }, { status: 404 });
      }
    }

    // Increment views (best-effort, non-blocking)
    db.article.update({ where: { id: article.id }, data: { views: { increment: 1 } } }).catch(() => {});

    return Response.json({
      article: {
        id: article.id,
        title: article.title,
        slug: article.slug,
        excerpt: article.excerpt,
        content: article.content,
        category: article.category,
        tags: article.tags,
        status: article.status,
        authorName: article.author?.name || "تیم فیتاپ",
        coverImage: article.coverImage,
        // SEO fields
        seoTitle: article.seoTitle,
        seoDescription: article.seoDescription,
        metaKeywords: article.metaKeywords,
        canonicalUrl: article.canonicalUrl,
        ogImage: article.ogImage,
        robots: article.robots,
        readingMinutes: article.readingMinutes,
        views: article.views + 1,
        createdAt: article.createdAt.toISOString(),
        updatedAt: article.updatedAt.toISOString(),
      },
    });
  } catch (e) {
    return apiError(e);
  }
}

// PUT /api/articles/[slug] — update article (admin only)
export async function PUT(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    await requireAdmin();
    const { slug } = await params;
    const existing = await db.article.findUnique({ where: { slug } });
    if (!existing) {
      return Response.json({ error: "مقاله یافت نشد." }, { status: 404 });
    }

    const body = await req.json();
    const {
      title, slug: newSlug, excerpt, content, category, tags, status, coverImage,
      seoTitle, seoDescription, metaKeywords, canonicalUrl, ogImage, robots, readingMinutes,
    } = body || {};

    const data: any = {};
    if (typeof title === "string" && title.trim().length >= 3) data.title = title.trim();
    if (typeof excerpt === "string") data.excerpt = excerpt.trim();
    if (typeof content === "string" && content.trim().length >= 10) data.content = content;
    if (typeof category === "string" && VALID_CATEGORIES.includes(category)) data.category = category;
    if (typeof tags === "string") data.tags = tags.trim();
    if (typeof coverImage === "string") data.coverImage = coverImage.trim();
    if (status === "published" || status === "draft") data.status = status;

    // SEO fields
    if (typeof seoTitle === "string") data.seoTitle = seoTitle.trim();
    if (typeof seoDescription === "string") data.seoDescription = seoDescription.trim();
    if (typeof metaKeywords === "string") data.metaKeywords = metaKeywords.trim();
    if (typeof canonicalUrl === "string") data.canonicalUrl = canonicalUrl.trim();
    if (typeof ogImage === "string") data.ogImage = ogImage.trim();
    if (typeof robots === "string" && robots.trim()) data.robots = robots.trim();
    if (Number.isFinite(readingMinutes) && readingMinutes > 0) data.readingMinutes = readingMinutes;
    else if (typeof content === "string") {
      // auto recompute reading time
      try {
        const wc = content.trim().split(/\s+/).length;
        data.readingMinutes = Math.max(1, Math.ceil(wc / 200));
      } catch {}
    }

    if (typeof newSlug === "string" && newSlug.trim() && newSlug !== slug) {
      const finalSlug = slugify(newSlug);
      if (finalSlug !== slug) {
        const conflict = await db.article.findUnique({ where: { slug: finalSlug } });
        if (conflict && conflict.id !== existing.id) {
          return Response.json({ error: "این شناسه (slug) قبلاً استفاده شده است." }, { status: 400 });
        }
        data.slug = finalSlug;
      }
    }

    const updated = await db.article.update({ where: { id: existing.id }, data });
    return Response.json({
      article: {
        ...updated,
        createdAt: updated.createdAt.toISOString(),
        updatedAt: updated.updatedAt.toISOString(),
      },
    });
  } catch (e) {
    return apiError(e);
  }
}

// DELETE /api/articles/[slug] — delete article (admin only)
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    await requireAdmin();
    const { slug } = await params;
    const existing = await db.article.findUnique({ where: { slug } });
    if (!existing) {
      return Response.json({ error: "مقاله یافت نشد." }, { status: 404 });
    }
    await db.article.delete({ where: { id: existing.id } });
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}
