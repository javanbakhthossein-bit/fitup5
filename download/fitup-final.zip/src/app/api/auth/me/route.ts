import { db } from "@/lib/db";
import { getCurrentUser, apiError, buildUserDto } from "@/lib/fitness/auth";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return Response.json({ user: null }, { status: 200 });
    }
    const dto = await buildUserDto(user.id);
    return Response.json({ user: dto });
  } catch (e) {
    return apiError(e);
  }
}
