import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import {
  verifyPassword,
  validateMobile,
  setSession,
  apiError,
  buildUserDto,
} from "@/lib/fitness/auth";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const mobile = String(body.mobile || "").replace(/\s/g, "");
    const password = String(body.password || "");

    if (!validateMobile(mobile)) {
      return Response.json(
        { error: "شماره موبایل نامعتبر است." },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({ where: { mobile } });
    if (!user) {
      return Response.json(
        { error: "کاربری با این شماره یافت نشد. ابتدا ثبت‌نام کنید." },
        { status: 404 }
      );
    }
    if (user.isBlocked) {
      return Response.json(
        { error: "حساب کاربری شما مسدود شده است. با پشتیبانی تماس بگیرید." },
        { status: 403 }
      );
    }
    if (!verifyPassword(password, user.passwordHash)) {
      return Response.json(
        { error: "رمز عبور اشتباه است." },
        { status: 401 }
      );
    }

    await setSession(user.id);
    const dto = await buildUserDto(user.id);
    return Response.json(dto);
  } catch (e) {
    return apiError(e);
  }
}
