import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";
import { ensureRenewalDiscountCode } from "@/lib/fitness/notifications";

/**
 * GET /api/user-discount-code
 * Returns the current active (non-used, non-expired) renewal discount code for the logged-in user.
 * If the user's plan is expiring soon (within 5 days) and no code exists yet, one is auto-generated.
 *
 * Response: { code: string | null, value: number, type: "percent", validUntil: string | null, expiresSoon: boolean, daysLeft: number }
 */
export async function GET() {
  try {
    const user = await requireAuth();

    const now = new Date();
    const subEnd = user.planExpiresAt ?? null;
    const daysLeft = subEnd ? Math.ceil((subEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) : null;
    const expiresSoon = daysLeft != null && daysLeft >= 0 && daysLeft <= 5;

    // Look for an existing active renewal code
    let code = await db.userDiscountCode.findFirst({
      where: {
        userId: user.id,
        isUsed: false,
        reason: "renewal_loyalty",
        OR: [{ validUntil: null }, { validUntil: { gt: now } }],
      },
      orderBy: { createdAt: "desc" },
    });

    // Auto-generate if the user's plan is expiring soon and no code exists yet
    if (!code && expiresSoon) {
      const generated = await ensureRenewalDiscountCode(user.id, 15, 14);
      if (generated) {
        code = await db.userDiscountCode.findFirst({
          where: { userId: user.id, code: generated.code },
        });
      }
    }

    return Response.json({
      code: code?.code ?? null,
      value: code?.value ?? 0,
      type: code?.type ?? "percent",
      validUntil: code?.validUntil?.toISOString() ?? null,
      isUsed: code?.isUsed ?? false,
      expiresSoon,
      daysLeft: daysLeft ?? 0,
      subEndDate: subEnd?.toISOString() ?? null,
    });
  } catch (e) {
    return apiError(e);
  }
}

/**
 * POST /api/user-discount-code
 * Manually trigger creation of a renewal discount code (admin/debug tool).
 * Body: { percent?: number, validForDays?: number }
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await req.json().catch(() => ({}));
    const percent = Math.max(5, Math.min(50, Number(body?.percent ?? 15)));
    const validForDays = Math.max(1, Math.min(60, Number(body?.validForDays ?? 14)));

    const generated = await ensureRenewalDiscountCode(user.id, percent, validForDays);
    if (!generated) {
      return Response.json({ error: "ساخت کد تخفیف ناموفق بود." }, { status: 500 });
    }
    return Response.json({ ok: true, ...generated });
  } catch (e) {
    return apiError(e);
  }
}
