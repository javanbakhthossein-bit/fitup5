import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";
import { generateWorkoutPlan, generateMealPlan } from "@/lib/fitness/ai";
import type { OnboardingData } from "@/lib/fitness/types";

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const body = (await req.json()) as Partial<OnboardingData>;

    // Validate required fields
    const required = ["firstName", "lastName", "gender", "age", "height", "weight", "goal", "activityLevel", "workoutDays", "workoutPlace", "dietType"];
    for (const k of required) {
      if (body[k as keyof OnboardingData] === undefined || body[k as keyof OnboardingData] === null || body[k as keyof OnboardingData] === "") {
        return Response.json({ error: `فیلد ${k} الزامی است.` }, { status: 400 });
      }
    }

    const data: OnboardingData = {
      firstName: String(body.firstName || "").trim(),
      lastName: String(body.lastName || "").trim(),
      gender: body.gender!,
      age: Number(body.age),
      height: Number(body.height),
      weight: Number(body.weight),
      targetWeight: body.targetWeight ? Number(body.targetWeight) : undefined,
      goal: body.goal!,
      activityLevel: body.activityLevel!,
      workoutDays: Number(body.workoutDays),
      workoutDaysList: body.workoutDaysList || [],
      workoutPlace: body.workoutPlace!,
      equipment: body.equipment || [],
      diseases: body.diseases || "",
      injuries: body.injuries || "",
      allergies: body.allergies || "",
      dietType: body.dietType!,
      trainingExperience: body.trainingExperience,
      previousTrainingType: body.previousTrainingType,
      drugAllergies: body.drugAllergies,
      currentMedications: body.currentMedications,
      maxLifts: body.maxLifts,
      // Optional baseline measurements (cm) — may be null/undefined
      chestMeasurement: body.chestMeasurement ? Number(body.chestMeasurement) : undefined,
      armMeasurement: body.armMeasurement ? Number(body.armMeasurement) : undefined,
      waistMeasurement: body.waistMeasurement ? Number(body.waistMeasurement) : undefined,
      hipMeasurement: body.hipMeasurement ? Number(body.hipMeasurement) : undefined,
      thighMeasurement: body.thighMeasurement ? Number(body.thighMeasurement) : undefined,
    };

    // Upsert onboarding profile
    await db.onboardingProfile.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        gender: data.gender,
        age: data.age,
        height: data.height,
        weight: data.weight,
        targetWeight: data.targetWeight ?? null,
        goal: data.goal,
        activityLevel: data.activityLevel,
        workoutDays: data.workoutDays,
        workoutDaysList: JSON.stringify(data.workoutDaysList || []),
        workoutPlace: data.workoutPlace,
        equipment: JSON.stringify(data.equipment),
        diseases: data.diseases,
        injuries: data.injuries,
        allergies: data.allergies,
        dietType: data.dietType,
        trainingExperience: data.trainingExperience ?? null,
        previousTrainingType: data.previousTrainingType ?? null,
        drugAllergies: data.drugAllergies ?? null,
        currentMedications: data.currentMedications ?? null,
        maxLifts: data.maxLifts ?? null,
      },
      update: {
        gender: data.gender,
        age: data.age,
        height: data.height,
        weight: data.weight,
        targetWeight: data.targetWeight ?? null,
        goal: data.goal,
        activityLevel: data.activityLevel,
        workoutDays: data.workoutDays,
        workoutDaysList: JSON.stringify(data.workoutDaysList || []),
        workoutPlace: data.workoutPlace,
        equipment: JSON.stringify(data.equipment),
        diseases: data.diseases,
        injuries: data.injuries,
        allergies: data.allergies,
        dietType: data.dietType,
        trainingExperience: data.trainingExperience ?? null,
        previousTrainingType: data.previousTrainingType ?? null,
        drugAllergies: data.drugAllergies ?? null,
        currentMedications: data.currentMedications ?? null,
        maxLifts: data.maxLifts ?? null,
      },
    });

    // Log initial weight
    await db.weightLog.create({
      data: { userId: user.id, weight: data.weight, note: "وزن اولیه (آنبوردینگ)" },
    });

    // Create an initial baseline checkup so we have a "starting point" to compare future checkups against.
    // Body measurements come from the optional onboarding fields (cm); if absent, they stay null
    // and the user can fill them in their first real checkup.
    const existingCheckup = await db.checkup.findFirst({ where: { userId: user.id, phaseNumber: 0 } });
    if (!existingCheckup) {
      await db.checkup.create({
        data: {
          userId: user.id,
          phaseNumber: 0, // 0 = baseline (before any training)
          isFinalCheckup: false,
          status: "approved",
          weight: data.weight,
          chestMeasurement: data.chestMeasurement ?? null,
          armMeasurement: data.armMeasurement ?? null,
          waistMeasurement: data.waistMeasurement ?? null,
          hipMeasurement: data.hipMeasurement ?? null,
          thighMeasurement: data.thighMeasurement ?? null,
          bodyFatPercent: null,
          leanBodyMass: null,
          fatigueLevel: 3,
          sleepQuality: 3,
          dietAdherence: 3,
          workoutAdherence: 3,
          phaseCompleted: true,
          notes: "چکاپ اولیه — وضعیت شروع ورزشکار قبل از تمرین",
          aiAnalysis: null,
          coachNotes: null,
        },
      });
    } else {
      // اگر چکاپ اولیه از قبل وجود دارد و کاربر اندازه‌ها را فراهم کرده، به‌روزرسانی کن
      const hasNewMeasurements =
        data.chestMeasurement != null ||
        data.armMeasurement != null ||
        data.waistMeasurement != null ||
        data.hipMeasurement != null ||
        data.thighMeasurement != null;
      if (hasNewMeasurements) {
        await db.checkup.update({
          where: { id: existingCheckup.id },
          data: {
            chestMeasurement: data.chestMeasurement ?? existingCheckup.chestMeasurement,
            armMeasurement: data.armMeasurement ?? existingCheckup.armMeasurement,
            waistMeasurement: data.waistMeasurement ?? existingCheckup.waistMeasurement,
            hipMeasurement: data.hipMeasurement ?? existingCheckup.hipMeasurement,
            thighMeasurement: data.thighMeasurement ?? existingCheckup.thighMeasurement,
            weight: data.weight,
          },
        });
      }
    }

    // Mark onboarding done + save user's full name (firstName + lastName)
    const fullName = `${data.firstName} ${data.lastName}`.trim();
    await db.user.update({
      where: { id: user.id },
      data: {
        onboardingDone: true,
        name: fullName || user.name,
      },
    });

    return Response.json({ ok: true, message: "اطلاعات با موفقیت ذخیره شد." });
  } catch (e) {
    return apiError(e);
  }
}

// Generate plan (called separately after onboarding to show loading)
export async function PUT() {
  try {
    const user = await requireAuth();
    const profile = await db.onboardingProfile.findUnique({
      where: { userId: user.id },
    });
    if (!profile) {
      return Response.json({ error: "ابتدا آنبوردینگ را تکمیل کنید." }, { status: 400 });
    }

    const data: OnboardingData = {
      gender: profile.gender as OnboardingData["gender"],
      age: profile.age,
      height: profile.height,
      weight: profile.weight,
      targetWeight: profile.targetWeight ?? undefined,
      goal: profile.goal as OnboardingData["goal"],
      activityLevel: profile.activityLevel as OnboardingData["activityLevel"],
      workoutDays: profile.workoutDays,
      workoutDaysList: safeParseStringList(profile.workoutDaysList),
      workoutPlace: profile.workoutPlace as OnboardingData["workoutPlace"],
      equipment: safeParseEquipment(profile.equipment),
      diseases: profile.diseases,
      injuries: profile.injuries,
      allergies: profile.allergies,
      dietType: profile.dietType as OnboardingData["dietType"],
      trainingExperience: (profile.trainingExperience ?? undefined) as OnboardingData["trainingExperience"],
      previousTrainingType: profile.previousTrainingType ?? undefined,
      drugAllergies: profile.drugAllergies ?? undefined,
      currentMedications: profile.currentMedications ?? undefined,
      maxLifts: profile.maxLifts ?? undefined,
    };

    // Deactivate old plans
    await db.workoutPlan.updateMany({
      where: { userId: user.id },
      data: { active: false },
    });
    await db.mealPlan.updateMany({
      where: { userId: user.id },
      data: { active: false },
    });

    // Generate new plans in parallel — pass user's active plan tier to AI
    const userPlan = (user.planName as any) ?? null;
    const [workout, meal] = await Promise.all([
      generateWorkoutPlan(data, userPlan),
      generateMealPlan(data, userPlan),
    ]);

    await db.workoutPlan.create({
      data: {
        userId: user.id,
        content: JSON.stringify(workout),
        active: true,
      },
    });
    await db.mealPlan.create({
      data: {
        userId: user.id,
        content: JSON.stringify(meal),
        totalCal: meal.totalCalories,
        active: true,
      },
    });

    // Achievement notification
    await db.notification.create({
      data: {
        userId: user.id,
        type: "achievement",
        title: "برنامه شما آماده شد! 🎯",
        body: "برنامه تمرینی و غذایی شخصی‌سازی‌شده شما توسط هوش مصنوعی ساخته شد. از بخش «تمرینات» و «تغذیه» مشاهده کنید.",
        read: false,
      },
    });

    return Response.json({ ok: true, workout, meal });
  } catch (e) {
    return apiError(e);
  }
}

/**
 * Robustly parse the equipment field which may be stored as:
 * - JSON array string: '["dumbbell","barbell"]'
 * - CSV string: "dumbbell,barbell" (legacy data)
 * - Empty string or null
 */
function safeParseEquipment(raw: string | null | undefined): string[] {
  if (!raw) return [];
  const trimmed = raw.trim();
  if (!trimmed) return [];
  // Try JSON first
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) return parsed.map((x) => String(x));
    if (typeof parsed === "string") {
      // It was a JSON string like "\"dumbbell,barbell\"" — split on comma
      return parsed.split(",").map((s) => s.trim()).filter(Boolean);
    }
    return [];
  } catch {
    // Not JSON — split on comma (legacy CSV format)
    return trimmed.split(",").map((s) => s.trim()).filter(Boolean);
  }
}

/**
 * Parse workoutDaysList stored as JSON string array.
 */
function safeParseStringList(raw: string | null | undefined): string[] {
  if (!raw) return [];
  const trimmed = raw.trim();
  if (!trimmed) return [];
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) return parsed.map((x) => String(x));
    return [];
  } catch {
    return [];
  }
}
