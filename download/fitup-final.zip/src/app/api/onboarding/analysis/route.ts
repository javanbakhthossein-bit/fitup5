import { db } from "@/lib/db";
import { requireAuth, apiError } from "@/lib/fitness/auth";
import { avalaiClient, TEXT_MODEL } from "@/lib/fitness/ai";
import {
  GOAL_LABELS, ACTIVITY_LABELS, GENDER_LABELS,
  WORKOUT_PLACE_LABELS, DIET_LABELS, TRAINING_EXPERIENCE_LABELS,
  type OnboardingData,
} from "@/lib/fitness/types";

/** Robustly parse a stored JSON-or-CSV string list field. */
function safeParseList(raw: string | null | undefined): string[] {
  if (!raw) return [];
  const t = raw.trim();
  if (!t) return [];
  try {
    const p = JSON.parse(t);
    if (Array.isArray(p)) return p.map((x) => String(x));
    if (typeof p === "string") return p.split(",").map((s) => s.trim()).filter(Boolean);
    return [];
  } catch {
    return t.split(",").map((s) => s.trim()).filter(Boolean);
  }
}

export async function GET() {
  try {
    const user = await requireAuth();
    const profile = await db.onboardingProfile.findUnique({
      where: { userId: user.id },
    });

    if (!profile) {
      return Response.json({ error: "اطلاعات آنبوردینگ یافت نشد." }, { status: 400 });
    }

    const data: OnboardingData = {
      gender: profile.gender as OnboardingData["gender"],
      age: profile.age,
      height: profile.height,
      weight: profile.weight,
      targetWeight: profile.targetWeight ?? undefined,
      goal: profile.goal as OnboardingData["goal"],
      activityLevel: profile.activityLevel as OnboardingData["activityLevel"],
      workoutDays: profile.workoutDays,
      workoutDaysList: safeParseList(profile.workoutDaysList),
      workoutPlace: profile.workoutPlace as OnboardingData["workoutPlace"],
      equipment: safeParseList(profile.equipment),
      diseases: profile.diseases,
      injuries: profile.injuries,
      allergies: profile.allergies,
      dietType: profile.dietType as OnboardingData["dietType"],
      trainingExperience: (profile.trainingExperience ?? undefined) as OnboardingData["trainingExperience"],
      previousTrainingType: profile.previousTrainingType ?? undefined,
      drugAllergies: profile.drugAllergies ?? undefined,
      currentMedications: profile.currentMedications ?? undefined,
      maxLifts: profile.maxLifts ?? undefined,
    };

    // Calculate BMI, BMR, TDEE
    const heightM = data.height / 100;
    const bmi = data.weight / (heightM * heightM);

    const bmr =
      data.gender === "male"
        ? 10 * data.weight + 6.25 * data.height - 5 * data.age + 5
        : 10 * data.weight + 6.25 * data.height - 5 * data.age - 161;

    const activityFactors: Record<string, number> = {
      sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very_active: 1.9,
    };
    const tdee = Math.round(bmr * (activityFactors[data.activityLevel] || 1.55));

    // Generate AI analysis
    const userName = user.name || "ورزشکار";
    const workoutDaysList = data.workoutDaysList ?? [];

    const prompt = `تو فیتاپ هوشمند هستی. یک تحلیل اختصاصی کوتاه (حداکثر ۳ پاراگراف) از وضعیت فیزیکی این ورزشکار بنویس. لحن علمی، دوستانه و انگیزشی. فقط تحلیل بده، برنامه تجویز نکن.

اطلاعات ورزشکار:
- نام: ${userName}
- جنسیت: ${GENDER_LABELS[data.gender]}
- سن: ${data.age} سال
- قد: ${data.height} سانتی‌متر
- وزن: ${data.weight} کیلوگرم
- وزن هدف: ${data.targetWeight || "نامشخص"} کیلوگرم
- هدف: ${GOAL_LABELS[data.goal]}
- سطح فعالیت: ${ACTIVITY_LABELS[data.activityLevel]}
- روزهای تمرین: ${workoutDaysList.length > 0 ? workoutDaysList.join("، ") : data.workoutDays + " روز در هفته"}
- مکان تمرین: ${WORKOUT_PLACE_LABELS[data.workoutPlace]}
- آسیب‌دیدگی: ${data.injuries || "ندارد"}
- بیماری: ${data.diseases || "ندارد"}
- حساسیت غذایی: ${data.allergies || "ندارد"}
- BMI: ${bmi.toFixed(1)}
- BMR: ${Math.round(bmr)} کالری
- TDEE: ${tdee} کالری

تحلیل را با نام کاربر شروع کن. به نکات مهم مثل BMI، فاصله تا وزن هدف، و توصیه‌های کلی اشاره کن. در پایان بگو که برای دریافت برنامه اختصاصی باید پلن تهیه کند.`;

    let analysisText = "";
    try {
      const completion = await avalaiClient.chat.completions.create({
        model: TEXT_MODEL,
        messages: [
          { role: "system", content: "تو فیتاپ هوشمند هستی — مربی متخصص ورزشی و تغذیه. به زبان فارسی پاسخ بده." },
          { role: "user", content: prompt },
        ],
      } as any);
      analysisText = completion.choices[0]?.message?.content || "";
    } catch (err) {
      console.error("[Analysis] AI error:", err);
      analysisText = `${userName} عزیز، بر اساس اطلاعات شما:\n\nشاخص توده بدنی (BMI) شما ${bmi.toFixed(1)} است که در دسته‌بندی ${bmi < 18.5 ? "کم‌وزن" : bmi < 25 ? "وزن نرمال" : bmi < 30 ? "اضافه‌وزن" : "چاق"} قرار می‌گیرد. کالری مورد نیاز روزانه شما حدود ${tdee} کیلوکالری است.\n\nبرای رسیدن به هدف ${GOAL_LABELS[data.goal]}، توصیه می‌شود یک برنامه تمرینی و غذایی اختصاصی تهیه کنید. فیتاپ هوشمند آماده طراحی برنامه متناسب با شرایط شماست.`;
    }

    // Fetch the baseline checkup (phase 0) for body measurements
    const baselineCheckup = await db.checkup.findFirst({
      where: { userId: user.id, phaseNumber: 0 },
      orderBy: { createdAt: "desc" },
    });

    return Response.json({
      analysis: analysisText,
      bmi: Math.round(bmi * 10) / 10,
      bmr: Math.round(bmr),
      tdee,
      // ─── Raw profile data for display in profile overlay ───
      profile: {
        gender: data.gender,
        genderLabel: GENDER_LABELS[data.gender],
        age: data.age,
        height: data.height,
        weight: data.weight,
        targetWeight: data.targetWeight ?? null,
        goal: data.goal,
        goalLabel: GOAL_LABELS[data.goal],
        activityLevel: data.activityLevel,
        activityLabel: ACTIVITY_LABELS[data.activityLevel],
        workoutDays: data.workoutDays,
        workoutDaysList,
        workoutPlace: data.workoutPlace,
        workoutPlaceLabel: WORKOUT_PLACE_LABELS[data.workoutPlace],
        dietType: data.dietType,
        dietLabel: DIET_LABELS[data.dietType],
        allergies: data.allergies,
        injuries: data.injuries,
        diseases: data.diseases,
        equipment: data.equipment,
        trainingExperience: data.trainingExperience ?? null,
        trainingExperienceLabel: data.trainingExperience
          ? TRAINING_EXPERIENCE_LABELS[data.trainingExperience]
          : null,
        previousTrainingType: data.previousTrainingType ?? null,
        drugAllergies: data.drugAllergies ?? null,
        currentMedications: data.currentMedications ?? null,
        maxLifts: data.maxLifts ?? null,
      },
      // اندازه‌های اولیه بدن از چکاپ baseline (phase 0)
      baseline: baselineCheckup
        ? {
            weight: baselineCheckup.weight,
            chestMeasurement: baselineCheckup.chestMeasurement,
            armMeasurement: baselineCheckup.armMeasurement,
            waistMeasurement: baselineCheckup.waistMeasurement,
            hipMeasurement: baselineCheckup.hipMeasurement,
            thighMeasurement: baselineCheckup.thighMeasurement,
            createdAt: baselineCheckup.createdAt,
          }
        : null,
    });
  } catch (e) {
    return apiError(e);
  }
}
