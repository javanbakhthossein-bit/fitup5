import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, apiError } from "@/lib/fitness/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";
    const now = new Date();

    const users = await db.user.findMany({
      where: search
        ? { OR: [{ mobile: { contains: search } }, { name: { contains: search } }] }
        : undefined,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        mobile: true,
        name: true,
        role: true,
        isBlocked: true,
        onboardingDone: true,
        createdAt: true,
      },
    });

    // Attach active subscription info
    const userIds = users.map((u) => u.id);
    const subs = await db.subscription.findMany({
      where: { userId: { in: userIds }, status: "active", endDate: { gt: now } },
    });
    const subMap = new Map(subs.map((s) => [s.userId, s]));

    return Response.json({
      users: users.map((u) => ({
        ...u,
        createdAt: u.createdAt.toISOString(),
        hasActiveSubscription: subMap.has(u.id),
        subscriptionEnd: subMap.get(u.id)?.endDate.toISOString() ?? null,
      })),
    });
  } catch (e) {
    return apiError(e);
  }
}

// Block / unblock / delete user
export async function PATCH(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const { userId, action } = await req.json();
    if (userId === admin.id) {
      return Response.json({ error: "نمی‌توانید حساب خود را تغییر دهید." }, { status: 400 });
    }
    if (action === "block") {
      await db.user.update({ where: { id: userId }, data: { isBlocked: true } });
    } else if (action === "unblock") {
      await db.user.update({ where: { id: userId }, data: { isBlocked: false } });
    } else if (action === "makeAdmin") {
      await db.user.update({ where: { id: userId }, data: { role: "ADMIN" } });
    } else if (action === "makeUser") {
      await db.user.update({ where: { id: userId }, data: { role: "USER" } });
    }
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("id");
    if (!userId) return Response.json({ error: "ID نیاز است." }, { status: 400 });
    if (userId === admin.id) {
      return Response.json({ error: "نمی‌توانید خود را حذف کنید." }, { status: 400 });
    }
    await db.user.delete({ where: { id: userId } });
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}
