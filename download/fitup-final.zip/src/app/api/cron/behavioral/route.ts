import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { createNotification, ensureRenewalDiscountCode } from "@/lib/fitness/notifications";

/**
 * GET /api/cron/behavioral?secret=CRON_SECRET
 *
 * Behavioral marketing cron endpoint. Runs three scenarios:
 *  1) Basic plan users → upgrade notification
 *  2) Plan expires within 3 days → renewal reminder (+ auto per-user discount code)
 *  3) Inactive for 5+ days → re-engagement notification
 *
 * Each scenario creates notifications in the DB (deduped by a per-scenario window).
 * The endpoint is protected by CRON_SECRET — must match the secret in the query string.
 *
 * Returns a JSON summary of how many notifications were created per scenario.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const secret = url.searchParams.get("secret");
  const expected = process.env.CRON_SECRET || "fitup-cron-secret-2025";

  if (secret !== expected) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const summary = {
    upgrade: 0,
    renewal: 0,
    reengagement: 0,
    total: 0,
    runAt: now.toISOString(),
  };

  // -------------------------------------------------------------------
  // Scenario 1: Users on basic plan → upgrade notification
  // Dedupe: don't send if they already got an "upgrade" notification in last 7 days
  // -------------------------------------------------------------------
  try {
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const basicUsers = await db.user.findMany({
      where: {
        planName: "basic",
        isBlocked: false,
      },
      select: { id: true },
    });
    for (const u of basicUsers) {
      const recent = await db.notification.findFirst({
        where: { userId: u.id, type: "upgrade", createdAt: { gt: sevenDaysAgo } },
        select: { id: true },
      });
      if (recent) continue;
      await createNotification(
        u.id,
        "upgrade",
        "ارتقای پلن — مسیر سریع‌تر به هدف! 🚀",
        "با پلن پیشرفته به چت نامحدود با مربی هوشمند، حالت باشگاه و آنالیز عکس غذا/بدن دسترسی پیدا کنید. همین حالا ارتقا دهید.",
        "?tab=plans",
        { scenario: "upgrade", fromPlan: "basic" }
      );
      summary.upgrade++;
    }
  } catch (err) {
    console.error("[cron/behavioral] upgrade scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 2: Plan expires within 3 days → renewal reminder
  // Also auto-generates a per-user 20% renewal discount code (if not exists).
  // Dedupe: don't send if they got a "renewal" notification in last 2 days.
  // -------------------------------------------------------------------
  try {
    const inThreeDays = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
    const twoDaysAgo = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);

    const expiringUsers = await db.user.findMany({
      where: {
        planExpiresAt: { gt: now, lt: inThreeDays },
        isBlocked: false,
      },
      select: { id: true, planName: true, mobile: true },
    });

    for (const u of expiringUsers) {
      const recent = await db.notification.findFirst({
        where: { userId: u.id, type: "renewal", createdAt: { gt: twoDaysAgo } },
        select: { id: true },
      });
      if (recent) continue;

      // Auto-generate per-user renewal discount code (FITAP15 = 15% off)
      const discount = await ensureRenewalDiscountCode(u.id, 15, 14);

      await createNotification(
        u.id,
        "renewal",
        "اشتراک شما به‌زودی منقضی می‌شود ⏰",
        discount
          ? `اشتراک ${u.planName ?? ""} شما در کمتر از ۳ روز منقضی می‌شود. با کد اختصاصی ${discount.code} (۱۵٪ تخفیف تمدید) همین حالا تمدید کنید.`
          : `اشتراک ${u.planName ?? ""} شما در کمتر از ۳ روز منقضی می‌شود. همین حالا تمدید کنید تا برنامه شما متوقف نشود.`,
        "?tab=plans",
        { scenario: "renewal", planName: u.planName, discountCode: discount?.code ?? null }
      );
      summary.renewal++;
    }
  } catch (err) {
    console.error("[cron/behavioral] renewal scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 3: Inactive for 5+ days → re-engagement notification
  // We use the most recent of: weight log, checkup, chat message, workout plan creation
  // to determine last activity. If no activity at all (or >5 days ago), send notification.
  // Dedupe: don't send if they got a "re_engagement" notification in last 7 days.
  // -------------------------------------------------------------------
  try {
    const fiveDaysAgo = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const candidates = await db.user.findMany({
      where: {
        isBlocked: false,
        onboardingDone: true,
        // Has any active or expired plan (engaged users)
        NOT: [{ planName: null }],
      },
      select: { id: true },
    });

    for (const u of candidates) {
      // Check for any recent notification to avoid spamming
      const recentNotif = await db.notification.findFirst({
        where: { userId: u.id, type: "re_engagement", createdAt: { gt: sevenDaysAgo } },
        select: { id: true },
      });
      if (recentNotif) continue;

      // Pull the most recent activity across multiple tables
      const [lastWeight, lastCheckup, lastChat, lastWorkoutPlan] = await Promise.all([
        db.weightLog.findFirst({
          where: { userId: u.id },
          orderBy: { loggedAt: "desc" },
          select: { loggedAt: true },
        }),
        db.checkup.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
        db.chatMessage.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
        db.workoutPlan.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
      ]);

      const timestamps = [
        lastWeight?.loggedAt,
        lastCheckup?.createdAt,
        lastChat?.createdAt,
        lastWorkoutPlan?.createdAt,
      ]
        .filter(Boolean)
        .map((t) => new Date(t as Date).getTime());

      const lastActivity = timestamps.length ? Math.max(...timestamps) : 0;

      // If last activity is older than 5 days (or no activity at all), send re-engagement
      if (lastActivity === 0 || lastActivity < fiveDaysAgo.getTime()) {
        await createNotification(
          u.id,
          "re_engagement",
          "وقتشه برگردی به مسیر! 💪",
          "چند روزی نیستی فعال بودی. یه تمرین کوتاه همین امروز می‌تونه انگیزه‌ت رو برگردونه. مربی هوشمندت منتظره!",
          "?tab=workouts",
          { scenario: "re_engagement", daysSinceLastActivity: lastActivity ? Math.floor((now.getTime() - lastActivity) / (24 * 60 * 60 * 1000)) : null }
        );
        summary.reengagement++;
      }
    }
  } catch (err) {
    console.error("[cron/behavioral] re-engagement scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 4: Checkup reminders — day 15, 30, 40 of the 45-day plan
  // Sends a notification reminding the user to do their periodic checkup.
  // Dedupe: don't send if they already got a "checkup_reminder" in last 5 days.
  // -------------------------------------------------------------------
  try {
    const fiveDaysAgoCheckup = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
    const activeUsers = await db.user.findMany({
      where: {
        planName: { not: null },
        planStartedAt: { not: null },
        isBlocked: false,
      },
      select: { id: true, planStartedAt: true, name: true },
    });

    for (const u of activeUsers) {
      if (!u.planStartedAt) continue;
      const daysSinceStart = Math.floor((now.getTime() - new Date(u.planStartedAt).getTime()) / (24 * 60 * 60 * 1000));

      // Checkup milestones: day 15, 30, 40 (±1 day tolerance)
      const isCheckupDay = [14, 15, 16, 29, 30, 31, 39, 40, 41].includes(daysSinceStart);
      if (!isCheckupDay) continue;

      // Determine which phase
      let phase = 1;
      let phaseLabel = "اول";
      if (daysSinceStart >= 29 && daysSinceStart <= 31) { phase = 2; phaseLabel = "دوم"; }
      else if (daysSinceStart >= 39 && daysSinceStart <= 41) { phase = 3; phaseLabel = "سوم (نهایی)"; }

      // Dedupe
      const recentCheckupNotif = await db.notification.findFirst({
        where: { userId: u.id, type: "checkup_reminder", createdAt: { gt: fiveDaysAgoCheckup } },
        select: { id: true },
      });
      if (recentCheckupNotif) continue;

      await createNotification(
        u.id,
        "checkup_reminder",
        `زمان چکاپ ${phaseLabel} فرا رسید! 📊`,
        `${u.name ?? "ورزشکار"} عزیز، روز ${toPersianDigitsFn(daysSinceStart)} از دوره ۴۵ روزه شماست. اکنون زمان چکاپ ${phaseLabel} است: وزن، اندازه‌های بدن و درصد چربی را ثبت کنید تا فیتاپ هوشمند پیشرفت شما را تحلیل کند. از بخش «پیشرفت» اقدام کنید.`,
        "?tab=progress",
        { scenario: "checkup_reminder", phase, daysSinceStart }
      );
      if (!summary.checkup) summary.checkup = 0;
      summary.checkup++;
    }
  } catch (err) {
    console.error("[cron/behavioral] checkup reminder scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 5: Plan just expired — send expiry notification
  // Checks if plan expired within the last 24 hours (cron runs daily).
  // Dedupe: don't send if they already got an "expired" notification.
  // -------------------------------------------------------------------
  try {
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const recentlyExpired = await db.subscription.findMany({
      where: {
        status: "active",
        endDate: { lt: now, gt: oneDayAgo },
      },
      select: { userId: true, plan: true, endDate: true },
    });

    // Mark subscriptions as expired
    for (const sub of recentlyExpired) {
      await db.subscription.update({
        where: { id: sub.id },
        data: { status: "expired" },
      });

      // Check if already notified
      const alreadyNotified = await db.notification.findFirst({
        where: { userId: sub.userId, type: "expired" },
        select: { id: true },
      });
      if (alreadyNotified) continue;

      await createNotification(
        sub.userId,
        "expired",
        "اشتراک شما منقضی شد ⚠️",
        `اشتراک ${sub.plan ?? ""} شما منقضی شد. برای ادامه تمرینات و دسترسی به مربی هوشمند، لطفاً پلن خود را تمدید کنید. با کد FITAP15 از ۱۵٪ تخفیف تمدید بهره‌مند شوید.`,
        "?tab=plans",
        { scenario: "expired", planName: sub.plan }
      );
      if (!summary.expired) summary.expired = 0;
      summary.expired++;
    }
  } catch (err) {
    console.error("[cron/behavioral] expired scenario failed:", err);
  }

  summary.total = summary.upgrade + summary.renewal + summary.reengagement + (summary.checkup || 0) + (summary.expired || 0);
  return Response.json({ ok: true, ...summary });
}

// Simple Persian digit converter (to avoid importing from types in cron)
function toPersianDigitsFn(n: number | string): string {
  const persianDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return String(n).replace(/[0-9]/g, (d) => persianDigits[parseInt(d)]);
}
