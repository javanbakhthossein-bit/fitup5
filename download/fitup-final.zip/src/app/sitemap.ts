import type { MetadataRoute } from "next";
import { db } from "@/lib/db";

const SITE_URL = "https://fittup.ir";

/**
 * Dynamic Next.js 16 sitemap.
 * - Static landing sections (#features / #pricing / #faq)
 * - Published articles from the database
 * Falls back to a static set if the DB is unreachable (e.g. at build time).
 */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const staticEntries: MetadataRoute.Sitemap = [
    {
      url: SITE_URL,
      lastModified: now,
      changeFrequency: "daily",
      priority: 1.0,
    },
    {
      url: `${SITE_URL}/#features`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: `${SITE_URL}/#pricing`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: `${SITE_URL}/#faq`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.6,
    },
  ];

  // Try to include published articles for richer indexing.
  try {
    const articles = await db.article.findMany({
      where: { status: "published" },
      orderBy: { createdAt: "desc" },
      take: 200,
      select: { slug: true, updatedAt: true },
    });

    for (const a of articles) {
      staticEntries.push({
        url: `${SITE_URL}/?article=${encodeURIComponent(a.slug)}`,
        lastModified: a.updatedAt,
        changeFrequency: "monthly",
        priority: 0.5,
      });
    }
  } catch {
    // DB might not be ready during build — ignore and ship the static entries.
  }

  return staticEntries;
}
