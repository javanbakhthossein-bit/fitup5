import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/fitness/theme-provider";
import { HeadCodeInjector } from "@/components/fitness/head-code-injector";

const vazirmatn = localFont({
  src: [
    { path: "../../public/fonts/Vazirmatn-Regular.woff2", weight: "400", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Medium.woff2", weight: "500", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Bold.woff2", weight: "700", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Black.woff2", weight: "900", style: "normal" },
  ],
  variable: "--font-vazirmatn",
  display: "swap",
});

const SITE_URL = "https://fittup.ir";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "برنامه بدنسازی هوشمند | فیتاپ — برنامه تمرینی و تغذیه با AI",
    template: "%s | فیتاپ",
  },
  description:
    "برنامه بدنسازی هوشمند با فیتاپ — برنامه تمرینی و غذایی شخصی‌سازی‌شده با هوش مصنوعی، برنامه تغذیه و مکمل، چت هوشمند ورزشی، آنالیز ویدیویی و آزمایش خون. ۴ پلن اشتراک متناسب با هر هدف.",
  applicationName: "فیتاپ",
  keywords: [
    "برنامه بدنسازی",
    "برنامه تمرینی",
    "برنامه تغذیه",
    "برنامه غذایی",
    "مکمل ورزشی",
    "عضله‌سازی",
    "کاهش وزن",
    "بدنسازی",
    "مربی هوش مصنوعی ورزشی",
    "برنامه تمرینی شخصی‌سازی",
    "فیتاپ",
    "fittup",
    "AI fitness coach",
    "workout plan",
  ],
  authors: [{ name: "فیتاپ", url: SITE_URL }],
  creator: "فیتاپ",
  publisher: "فیتاپ",
  alternates: {
    canonical: SITE_URL,
  },
  openGraph: {
    title: "برنامه بدنسازی هوشمند | فیتاپ — برنامه تمرینی و تغذیه با AI",
    description:
      "برنامه بدنسازی و تغذیه کاملاً شخصی‌سازی‌شده با هوش مصنوعی. برنامه مکمل، چت هوشمند ورزشی، آنالیز ویدیویی و آزمایش خون — هر بدنی فیتاپ میخواد.",
    url: SITE_URL,
    siteName: "فیتاپ",
    locale: "fa_IR",
    type: "website",
    images: [
      {
        url: "/hero-fitup-v3.png",
        width: 1200,
        height: 630,
        alt: "فیتاپ — اپلیکیشن تناسب اندام با هوش مصنوعی",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "برنامه بدنسازی هوشمند | فیتاپ",
    description:
      "برنامه بدنسازی و تغذیه شخصی‌سازی‌شده با هوش مصنوعی — هر بدنی فیتاپ میخواد.",
    images: ["/hero-fitup-v3.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  manifest: "/manifest.json",
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  category: "health",
};

export const viewport: Viewport = {
  themeColor: "#f59e0b",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

// ---- Structured data (JSON-LD) ----
// سازمان (Organization)
const organizationLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "فیتاپ",
  alternateName: "FitUp",
  url: SITE_URL,
  logo: `${SITE_URL}/logo.svg`,
  description: "اپلیکیشن برنامه بدنسازی و تغذیه هوشمند با هوش مصنوعی",
  slogan: "هر بدنی فیتاپ میخواد — برنامه بدنسازی هوشمند",
  sameAs: [SITE_URL],
};

// وب‌سایت (WebSite) با قابلیت جستجو
const websiteLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "فیتاپ",
  url: SITE_URL,
  inLanguage: "fa-IR",
  description: "برنامه بدنسازی و تغذیه هوشمند با هوش مصنوعی — هر بدنی فیتاپ میخواد",
  publisher: { "@type": "Organization", name: "فیتاپ", url: SITE_URL },
};

// سوالات متداول (FAQPage)
const faqLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: [
    {
      "@type": "Question",
      name: "آیا واقعاً هیچ مربی انسانی وجود ندارد؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "بله! تمامی برنامه‌های تمرینی، غذایی، مشاوره‌ها و آنالیزها منحصراً توسط هوش مصنوعی تولید و مدیریت می‌شوند. این یعنی پاسخ آنی، ۲۴ ساعته و بدون محدودیت زمانی — همه فارسی و شخصی‌سازی‌شده برای شما.",
      },
    },
    {
      "@type": "Question",
      name: "چگونه ثبت‌نام می‌کنم؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "ثبت‌نام با شماره موبایل و تأیید پیامک یک‌بارمصرف (OTP) انجام می‌شود. کد ۴ رقمی به شماره شما پیامک می‌شود و پس از تأیید، حساب شما ایجاد یا وارد می‌شود. ورود OTP یعنی پذیرش قوانین.",
      },
    },
    {
      "@type": "Question",
      name: "آیا برنامه تمرینی برای شرایط من مناسب است؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "برنامه کاملاً بر اساس اطلاعات آنبوردینگ شما (جنسیت، سن، قد، وزن، هدف، آسیب‌دیدگی‌ها، تجهیزات و رژیم غذایی) شخصی‌سازی می‌شود. اگر آسیب‌دیدگی دارید، هوش مصنوعی حرکات ایمن و جایگزین پیشنهاد می‌دهد.",
      },
    },
    {
      "@type": "Question",
      name: "پرداخت اشتراک چگونه انجام می‌شود؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "پرداخت از طریق درگاه امن زرین‌پال انجام می‌شود. پس از انتخاب اشتراک، به درگاه هدایت می‌شوید و پس از پرداخت موفق، اشتراک بلافاصله فعال می‌شود. رسید پرداخت در اپلیکیشن ذخیره می‌شود.",
      },
    },
    {
      "@type": "Question",
      name: "آیا می‌توانم برنامه‌ام را تغییر دهم؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "بله! هر زمان که بخواهید می‌توانید با چت با مربی AI، جایگزین حرکت بخواهید، غذا را تعویض کنید یا درخواست بازسازی کل برنامه کنید. همچنین می‌توانید وزن جدید ثبت کنید و برنامه به‌روز می‌شود.",
      },
    },
    {
      "@type": "Question",
      name: "آیا اطلاعات و تصاویر من محرمانه می‌مانند؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "بله، حریم خصوصی شما برای ما مهم‌ترین اولویت است. تصاویر پیشرفت (Before/After) کاملاً خصوصی هستند و فقط برای خود شما نمایش داده می‌شوند. اطلاعات شما با هیچ شخص ثالثی به اشتراک گذاشته نمی‌شود.",
      },
    },
    {
      "@type": "Question",
      name: "آیا اپلیکیشن روی گوشی من کار می‌کند؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "بله! اپلیکیشن فیتاپ یک وب‌اپلیکیشن واکنش‌گرا (Responsive) است که روی همه گوشی‌های اندروید و iOS از طریق مرورگر کار می‌کند. نیازی به نصب نیست — فقط باز کنید و شروع کنید.",
      },
    },
    {
      "@type": "Question",
      name: "اگر اشتراکم منقضی شود چه می‌شود؟",
      acceptedAnswer: {
        "@type": "Answer",
        text: "پس از انقضای اشتراک، دسترسی به برنامه‌های جدید و چت محدود می‌شود، اما اطلاعات قبلی شما (وزن، پیشرفت، تصاویر) حفظ می‌شود. هر زمان که اشتراک را تمدید کنید، دوباره به همه امکانات دسترسی دارید.",
      },
    },
  ],
};

// محصول و پلن‌ها (Product / Offer)
const productLd = {
  "@context": "https://schema.org",
  "@type": "Product",
  name: "اشتراک فیتاپ — هر بدنی فیتاپ میخواد",
  description:
    "اپلیکیشن جامع تناسب اندام با هوش مصنوعی: برنامه تمرینی و غذایی شخصی‌سازی‌شده، چت هوشمند ورزشی، آنالیز ویدیویی و آزمایش خون.",
  brand: { "@type": "Brand", name: "فیتاپ" },
  url: SITE_URL,
  image: `${SITE_URL}/hero-fitup-v3.png`,
  offers: [
    {
      "@type": "Offer",
      name: "پلن اقتصادی",
      price: "350000",
      priceCurrency: "IRR",
      description: "شروع مسیر تناسب اندام — برنامه تمرین و تغذیه ۴۵ روزه",
      url: `${SITE_URL}/#pricing`,
      availability: "https://schema.org/InStock",
    },
    {
      "@type": "Offer",
      name: "پلن استاندارد",
      price: "800000",
      priceCurrency: "IRR",
      description: "برنامه کامل‌تر با مکمل و چکاپ دوره‌ای — ۴۵ روزه",
      url: `${SITE_URL}/#pricing`,
      availability: "https://schema.org/InStock",
    },
    {
      "@type": "Offer",
      name: "پلن پیشرفته",
      price: "1500000",
      priceCurrency: "IRR",
      description: "چت هوشمند + حالت باشگاه + آنالیز عکس — ۴۵ روزه",
      url: `${SITE_URL}/#pricing`,
      availability: "https://schema.org/InStock",
    },
    {
      "@type": "Offer",
      name: "پلن حرفه‌ای",
      price: "2500000",
      priceCurrency: "IRR",
      description: "آنالیز ویدیویی + آزمایش خون + مربی انسانی — ۴۵ روزه",
      url: `${SITE_URL}/#pricing`,
      availability: "https://schema.org/InStock",
    },
  ],
};

// BreadcrumbList برای صفحه اصلی
const breadcrumbLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "خانه",
      item: SITE_URL,
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "امکانات",
      item: `${SITE_URL}/#features`,
    },
    {
      "@type": "ListItem",
      position: 3,
      name: "پلن‌ها و قیمت‌ها",
      item: `${SITE_URL}/#pricing`,
    },
    {
      "@type": "ListItem",
      position: 4,
      name: "سوالات متداول",
      item: `${SITE_URL}/#faq`,
    },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        {/* PWA manifest link (explicit, for older browsers) */}
        <link rel="manifest" href="/manifest.json" />
        {/* Theme color for mobile browsers */}
        <meta name="theme-color" content="#f59e0b" />
        {/* SEO: canonical */}
        <link rel="canonical" href={SITE_URL} />

        {/* Structured Data: Organization */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd) }}
        />
        {/* Structured Data: WebSite */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteLd) }}
        />
        {/* Structured Data: FAQPage */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqLd) }}
        />
        {/* Structured Data: Product with Offers (pricing plans) */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(productLd) }}
        />
        {/* Structured Data: BreadcrumbList */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbLd) }}
        />

        {/* Server-side injection of analytics/search-console/pixel codes (head placement) */}
        <HeadCodeInjector placement="head" />
      </head>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-background text-foreground`}
      >
        {/* Server-side injection (body_start placement) */}
        <HeadCodeInjector placement="body_start" />
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          forcedTheme="light"
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster position="top-center" dir="rtl" />
        </ThemeProvider>
        {/* Server-side injection (body_end placement) */}
        <HeadCodeInjector placement="body_end" />
      </body>
    </html>
  );
}
