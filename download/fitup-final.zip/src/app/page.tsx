"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/fitness/store";
import { AuthScreen } from "@/components/fitness/auth-screen";
import { OnboardingScreen } from "@/components/fitness/onboarding-screen";
import { MainApp } from "@/components/fitness/main-app";
import { SplashLoader } from "@/components/fitness/splash-loader";
import { LandingPage } from "@/components/fitness/landing/landing-page";
import { NikaWidget } from "@/components/fitness/nika-widget";
import { TdeeCalculator } from "@/components/fitness/tools/tdee-calculator";
import { ExercisesDatabase } from "@/components/fitness/tools/exercises-database";
import { FoodCalorieIndex } from "@/components/fitness/tools/food-calorie-index";
import { ToolsNav } from "@/components/fitness/tools/tools-nav";
import { TermsPage } from "@/components/fitness/terms-page";
import { PaymentVerifyHandler } from "@/components/fitness/payment-verify-handler";
import { AnalysisScreen } from "@/components/fitness/analysis-screen";
import { AdminOverlay } from "@/components/fitness/views/admin-overlay";
import { ArticlesPage } from "@/components/fitness/articles/articles-page";
import { ArticlePage } from "@/components/fitness/articles/article-page";

export default function Home() {
  const { screen, setScreen, setUser, setArticleSlug, setMainTab } = useAppStore();
  // تشخیص بازگشت از درگاه زرین‌پال (?payment_verify=1) — مقدار اولیه را در زمان mount از URL می‌خوانیم
  const [paymentVerify] = useState(() => {
    if (typeof window === "undefined") return false;
    const params = new URLSearchParams(window.location.search);
    return params.get("payment_verify") === "1";
  });
  // تشخیص لینک مستقیم مقاله (?article=slug)
  const [directArticle] = useState(() => {
    if (typeof window === "undefined") return null;
    const params = new URLSearchParams(window.location.search);
    return params.get("article");
  });

  useEffect(() => {
    // --- ذخیره کد معرفی از URL (?ref=CODE) در localStorage ---
    // این کار قبل از هر چیز دیگر انجام می‌شود تا در جریان OTP در دسترس باشد.
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const refCode = params.get("ref");
      if (refCode) {
        const cleaned = refCode.trim().toUpperCase();
        if (cleaned) {
          try {
            window.localStorage.setItem("fitap_referral_code", cleaned);
          } catch {
            // localStorage may be unavailable (private mode) — silently ignore
          }
        }
      }
    }

    // --- تشخیص tab از URL (?tab=xxx) برای لینک‌های اعلان‌ها ---
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const tab = params.get("tab");
      if (tab) {
        // اعتبارسنجی tab های معتبر
        const validTabs = ["dashboard", "programs", "workouts", "nutrition", "progress", "chat", "plans", "referral", "support"];
        if (validTabs.includes(tab)) {
          setMainTab(tab as any);
        }
      }
    }

    // اگر لینک مستقیم مقاله است، آن را باز کن
    if (directArticle) {
      setArticleSlug(directArticle);
      setScreen("article");
      return;
    }
    (async () => {
      try {
        const res = await fetch("/api/auth/me");
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
          // Admin users go directly to the admin panel
          if (data.user.role === "ADMIN") {
            setScreen("admin");
          } else {
            setScreen(data.user.onboardingDone ? "main" : "onboarding");
          }
        } else {
          setScreen("landing");
        }
      } catch {
        setScreen("landing");
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // اگر بازگشت از زرین‌پال است، صفحه تایید پرداخت را نمایش بده
  if (paymentVerify) {
    return <PaymentVerifyHandler />;
  }

  if (screen === "loading") return <SplashLoader />;
  if (screen === "landing") return (
    <>
      <LandingPage />
      <NikaWidget />
    </>
  );
  if (screen === "auth") return (
    <>
      <AuthScreen />
      <NikaWidget />
    </>
  );
  if (screen === "onboarding") return (
    <>
      <OnboardingScreen />
      <NikaWidget />
    </>
  );
  if (screen === "analysis") return <AnalysisScreen />;
  // Admin panel — full-screen standalone mode (admin users skip main app)
  if (screen === "admin") {
    return (
      <div className="fixed inset-0 bg-white">
        <AdminOverlay standalone />
      </div>
    );
  }
  // Public tool pages — show tools nav + Nika widget
  if (screen === "tool-tdee" || screen === "tool-exercises" || screen === "tool-foods") {
    return (
      <>
        <ToolsNav />
        {screen === "tool-tdee" && <TdeeCalculator />}
        {screen === "tool-exercises" && <ExercisesDatabase />}
        {screen === "tool-foods" && <FoodCalorieIndex />}
        <NikaWidget />
      </>
    );
  }
  // Public Terms & Conditions page (no auth required)
  if (screen === "terms") {
    return (
      <>
        <TermsPage />
        <NikaWidget />
      </>
    );
  }
  // Articles listing page (public)
  if (screen === "articles") {
    return <ArticlesPage />;
  }
  // Article detail page (public)
  if (screen === "article") {
    return <ArticlePage />;
  }
  return <MainApp />;
}
