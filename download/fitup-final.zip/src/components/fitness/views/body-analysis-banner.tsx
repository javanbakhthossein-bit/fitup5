"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Video, Upload, X, Loader2, AlertCircle } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/fitness/types";
import { toast } from "sonner";

interface BodyAnalysisState {
  needsBodyPhoto: boolean;
  needsBodyVideo: boolean;
  pendingStatus: string | null;
  hasWorkoutPlan: boolean;
  awaitingMedia: boolean;
}

/**
 * بنر هشدار برای کاربران پلن Advanced / Ultimate که هنوز عکس/ویدیو بدن
 * خود را ارسال نکرده‌اند. کاربر بدون این مدیاها برنامه‌ای دریافت نمی‌کند.
 */
export function BodyAnalysisBanner() {
  const { user, setWorkoutPlan, setMealPlan } = useAppStore();
  const [state, setState] = useState<BodyAnalysisState | null>(null);
  const [open, setOpen] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);
  const [video, setVideo] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // فقط اگر کاربر قابلیت bodyPhotoAnalysis داشت چک کن
    if (!user?.planName || (user.planName !== "advanced" && user.planName !== "ultimate")) {
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/coach/submit-body-analysis");
        if (!res.ok) return;
        const data = await res.json();
        if (!cancelled) setState(data);
      } catch {}
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.planName]);

  if (!state || !state.awaitingMedia) return null;

  function handlePhotos(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []).filter((f) => f.type.startsWith("image/"));
    if (files.length === 0) return;
    if (photos.length + files.length > 4) {
      toast.error("حداکثر ۴ عکس مجاز است");
      e.target.value = "";
      return;
    }
    setPhotos((prev) => [...prev, ...files]);
    e.target.value = "";
  }

  function handleVideo(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("video/")) {
      toast.error("فقط فایل ویدیویی مجاز است");
      e.target.value = "";
      return;
    }
    if (f.size > 20 * 1024 * 1024) {
      toast.error("حجم ویدیو باید کمتر از ۲۰ مگابایت باشد");
      e.target.value = "";
      return;
    }
    setVideo(f);
    e.target.value = "";
  }

  function removePhoto(idx: number) {
    setPhotos((prev) => prev.filter((_, i) => i !== idx));
  }

  async function submit() {
    if (photos.length === 0) {
      toast.error("حداقل یک عکس بدن ارسال کنید");
      return;
    }
    if (state?.needsBodyVideo && !video) {
      toast.error("برای پلن حرفه‌ای ارسال ویدیو الزامی است");
      return;
    }
    setSubmitting(true);
    try {
      const fd = new FormData();
      photos.forEach((p) => fd.append("bodyPhotos", p));
      if (video) fd.append("bodyVideo", video);

      const res = await fetch("/api/coach/submit-body-analysis", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در ارسال مدیا");

      toast.success("برنامه شما ساخته شد! 🎯");
      // پاک کردن فرم
      setPhotos([]);
      setVideo(null);
      setOpen(false);

      // به‌روزرسانی state و دریافت برنامه جدید
      setState({
        needsBodyPhoto: state?.needsBodyPhoto ?? false,
        needsBodyVideo: state?.needsBodyVideo ?? false,
        pendingStatus: "ready",
        hasWorkoutPlan: true,
        awaitingMedia: false,
      });

      // بارگذاری برنامه جدید
      const planRes = await fetch("/api/coach/plan");
      const planData = await planRes.json();
      if (planData.workout) setWorkoutPlan(planData.workout);
      if (planData.meal) setMealPlan(planData.meal);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "خطا در ارسال مدیا";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-orange-50 p-4 shadow-sm"
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center shrink-0">
            <Camera className="w-5 h-5 text-amber-600" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-sm text-amber-900 dark:text-amber-200">
              {state.needsBodyVideo
                ? "برای دریافت برنامه، عکس و ویدیو بدن خود را ارسال کنید"
                : "برای دریافت برنامه، عکس بدن خود را ارسال کنید"}
            </h4>
            <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1 leading-relaxed">
              {state.needsBodyVideo
                ? "پلن حرفه‌ای شما شامل تحلیل فرم بدن با ویدیو است. ۴ عکس از زوایای مختلف + یک ویدیوی کوتاه از حرکت اسکوات یا پرس ارسال کنید تا فیتاپ هوشمند برنامه اختصاصی شما را بسازد."
                : "۴ عکس از زوایای جلو، پهلو، پشت و سه‌چهارم بدن خود ارسال کنید تا فیتاپ هوشمند بر اساس فرم بدن شما برنامه اختصاصی طراحی کند."}
            </p>
            <div className="mt-2.5 flex items-center gap-2 flex-wrap">
              <Button
                size="sm"
                className="rounded-xl text-white"
                style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                onClick={() => setOpen(true)}
              >
                <Upload className="w-4 h-4" />
                {state.needsBodyVideo ? "ارسال عکس و ویدیو" : "ارسال عکس بدن"}
              </Button>
              <span className="text-[10px] text-amber-600 dark:text-amber-400">
                {toPersianDigits(photos.length)}/۴ عکس {state.needsBodyVideo ? `• ${video ? "۱" : "۰"}/۱ ویدیو` : ""}
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Modal upload */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4"
            onClick={() => !submitting && setOpen(false)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ type: "spring", stiffness: 280, damping: 28 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white w-full sm:max-w-md sm:rounded-3xl rounded-t-3xl max-h-[90vh] overflow-y-auto custom-scrollbar"
              dir="rtl"
            >
              {/* Header */}
              <div className="sticky top-0 bg-white border-b border-orange-100 p-4 flex items-center justify-between z-10">
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-orange-500" />
                  <h3 className="font-bold text-slate-900">
                    {state.needsBodyVideo ? "ارسال عکس و ویدیو بدن" : "ارسال عکس بدن"}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => !submitting && setOpen(false)}
                  className="p-1.5 rounded-full hover:bg-orange-50 text-slate-500"
                  aria-label="بستن"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                {/* توضیح */}
                <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    عکس‌ها را با نور کافی، لباس تنگ یا ورزشی و در ۴ زوایای جلو، پهلو، پشت و سه‌چهارم بگیرید.
                    {state.needsBodyVideo && " ویدیوی کوتاه (۲۰ ثانیه) از یک حرکت اساسی مثل اسکوات بدون وزنه ارسال کنید."}
                  </p>
                </div>

                {/* Photos */}
                <div>
                  <label className="text-sm font-bold text-slate-700 mb-2 block">
                    عکس‌های بدن (حداکثر ۴)
                  </label>
                  {photos.length > 0 && (
                    <div className="grid grid-cols-3 gap-2 mb-2">
                      {photos.map((p, i) => (
                        <div key={i} className="relative rounded-xl overflow-hidden border-2 border-orange-200 aspect-square">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={URL.createObjectURL(p)} alt={`عکس ${i + 1}`} className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => removePhoto(i)}
                            className="absolute top-1 left-1 w-6 h-6 rounded-full bg-white/90 backdrop-blur flex items-center justify-center text-red-500 shadow"
                            aria-label="حذف"
                          >
                            <X className="w-3 h-3" />
                          </button>
                          <span className="absolute bottom-1 right-1 text-[9px] bg-black/60 text-white px-1.5 py-0.5 rounded">
                            {toPersianDigits(i + 1)}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                  {photos.length < 4 && (
                    <button
                      type="button"
                      onClick={() => photoInputRef.current?.click()}
                      className="w-full rounded-2xl border-2 border-dashed border-orange-200 bg-orange-50/30 hover:bg-orange-50/60 hover:border-orange-400 transition p-5 text-center"
                    >
                      <Camera className="w-7 h-7 text-orange-500 mx-auto mb-1.5" />
                      <p className="text-sm font-medium text-slate-900">افزودن عکس بدن</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">{toPersianDigits(photos.length)}/۴ عکس — حداکثر ۵ مگابایت</p>
                    </button>
                  )}
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={handlePhotos}
                  />
                </div>

                {/* Video (Ultimate only) */}
                {state.needsBodyVideo && (
                  <div>
                    <label className="text-sm font-bold text-slate-700 mb-2 block flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-orange-500" />
                      ویدیوی فرم بدن (الزامی)
                    </label>
                    {video ? (
                      <div className="rounded-2xl border-2 border-orange-200 p-3 flex items-center gap-3 bg-white">
                        <div className="w-12 h-12 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0">
                          <Video className="w-6 h-6 text-orange-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-900 truncate">{video.name}</p>
                          <p className="text-[11px] text-slate-500 font-stat">{toPersianDigits(Math.round(video.size / 1024))} KB</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setVideo(null)}
                          className="p-2 rounded-lg hover:bg-red-50 text-red-500 transition"
                          aria-label="حذف ویدیو"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => videoInputRef.current?.click()}
                        className="w-full rounded-2xl border-2 border-dashed border-orange-200 bg-orange-50/30 hover:bg-orange-50/60 hover:border-orange-400 transition p-5 text-center"
                      >
                        <Video className="w-7 h-7 text-orange-500 mx-auto mb-1.5" />
                        <p className="text-sm font-medium text-slate-900">افزودن ویدیو</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">حداکثر ۲۰ مگابایت — MP4/WebM/MOV</p>
                      </button>
                    )}
                    <input
                      ref={videoInputRef}
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={handleVideo}
                    />
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="sticky bottom-0 bg-white border-t border-orange-100 p-3 flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 rounded-xl"
                  disabled={submitting}
                  onClick={() => setOpen(false)}
                >
                  انصراف
                </Button>
                <Button
                  className="flex-1 rounded-xl text-white"
                  style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                  disabled={submitting || photos.length === 0 || (state.needsBodyVideo && !video)}
                  onClick={submit}
                >
                  {submitting ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      در حال ساخت برنامه...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      ارسال و ساخت برنامه
                    </span>
                  )}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
