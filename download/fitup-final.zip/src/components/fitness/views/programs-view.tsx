"use client";

import { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import {
  Dumbbell, Salad, Pill, Calendar, CheckCircle2, ChevronLeft,
  Sparkles, Loader2, Utensils, FileText, Image as ImageIcon, X, Repeat, Lightbulb,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { toPersianDigits, PLAN_LABELS, formatToman } from "@/lib/fitness/types";
import { toast } from "sonner";

interface ProgramItem {
  id: string;
  weekIndex: number;
  active: boolean;
  createdAt: string;
  days: number;
  exercises: number;
  weeklyGoal: string;
  notes: string;
  totalCalories: number;
  planName: string;
  status: string;
  startDate: string;
  endDate: string | null;
  supplements?: { name: string; dose: string; timing: string }[];
  meals?: { label: string; totalCalories: number; items?: { name: string; calories: number }[] }[];
  mealNotes?: string;
  waterLiters?: number;
  totalProtein?: number;
  totalCarbs?: number;
  totalFat?: number;
  workoutDays?: any[];
}

export function ProgramsView() {
  const { user, setMainTab } = useAppStore();
  const [history, setHistory] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [viewModal, setViewModal] = useState<{ type: "workout" | "meal" | "supplement"; program: ProgramItem } | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/coach/program-history");
        const data = await res.json();
        setHistory(data);
      } catch {}
      finally { setLoading(false); }
    })();
  }, []);

  async function generateAnalysis() {
    setAnalyzing(true);
    try {
      const res = await fetch("/api/coach/program-history?analyze=1");
      const data = await res.json();
      setHistory(data);
      toast.success("تحلیل فیتاپ هوشمند آماده شد ✨");
    } catch { toast.error("خطا در تحلیل"); }
    finally { setAnalyzing(false); }
  }

  async function regeneratePlan() {
    setRegenerating(true);
    try {
      const res = await fetch("/api/coach/plan", { method: "PUT" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast.success("برنامه تمرینی و غذایی شما با موفقیت ساخته شد! 🎯");
      // reload history
      const hres = await fetch("/api/coach/program-history");
      const hdata = await hres.json();
      setHistory(hdata);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ساخت برنامه");
    } finally {
      setRegenerating(false);
    }
  }

  if (loading) {
    return (
      <div className="px-4 py-4 space-y-3 max-w-3xl mx-auto">
        <Skeleton className="h-8 rounded-xl" />
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
    );
  }

  const programs: ProgramItem[] = history?.programs || [];

  if (programs.length === 0) {
    return (
      <div className="px-4 py-8 text-center max-w-md mx-auto">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
          <Dumbbell className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-xl font-black text-slate-900 mb-2">هنوز برنامه‌ای ندارید</h2>
        <p className="text-sm text-slate-500 mb-6">
          {user?.planName
            ? "برنامه اختصاصی شما ساخته نشده است. همین حالا با فیتاپ هوشمند بسازید."
            : "برای دریافت برنامه اختصاصی، ابتدا یک پلن خریداری کنید."}
        </p>
        {user?.planName ? (
          <Button
            onClick={regeneratePlan}
            disabled={regenerating}
            className="rounded-xl text-white gap-2"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            {regenerating ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> فیتاپ هوشمند در حال ساخت برنامه...</>
            ) : (
              <><Sparkles className="w-4 h-4" /> ساخت برنامه با فیتاپ هوشمند</>
            )}
          </Button>
        ) : (
          <Button onClick={() => setMainTab("plans")} className="rounded-xl text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            خرید پلن
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="px-4 py-4 space-y-4 max-w-3xl mx-auto">
      <div>
        <h2 className="text-2xl font-black text-slate-900">برنامه‌های من</h2>
        <p className="text-sm text-slate-500">{toPersianDigits(programs.length)} برنامه — برنامه جاری و برنامه‌های قبلی</p>
      </div>

      {/* تحلیل فیتاپ هوشمند */}
      {history?.aiAnalysis ? (
        <Card className="p-4 border-2 border-orange-200 bg-orange-50/30">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-orange-500" />
            <p className="text-xs font-bold text-orange-600">تحلیل فیتاپ هوشمند</p>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">{history.aiAnalysis}</p>
        </Card>
      ) : programs.length > 0 && user?.planName ? (
        <Button onClick={generateAnalysis} disabled={analyzing} className="w-full rounded-xl text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
          {analyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> فیتاپ هوشمند در حال تحلیل...</> : <><Sparkles className="w-4 h-4" /> تحلیل پیشرفت توسط فیتاپ هوشمند</>}
        </Button>
      ) : null}

      {/* برنامه‌ها — جاری در بالا، قبلی در پایین */}
      {programs.map((p, i) => (
        <ProgramCard
          key={p.id}
          program={p}
          index={i}
          onOpenWorkouts={() => setMainTab("workouts")}
          onOpenNutrition={() => setMainTab("nutrition")}
          onOpenView={(type, prog) => setViewModal({ type, program: prog })}
        />
      ))}

      {/* Plan View Modal with download */}
      {viewModal && (
        <PlanViewModal
          type={viewModal.type}
          program={viewModal.program}
          onClose={() => setViewModal(null)}
        />
      )}
    </div>
  );
}

function ProgramCard({ program, index, onOpenWorkouts, onOpenNutrition, onOpenView }: {
  program: ProgramItem;
  index: number;
  onOpenWorkouts: () => void;
  onOpenNutrition: () => void;
  onOpenView: (type: "workout" | "meal" | "supplement", program: ProgramItem) => void;
}) {
  const isCurrent = program.active;
  const startDate = new Date(program.startDate);
  const endDate = program.endDate ? new Date(program.endDate) : new Date(startDate.getTime() + 45 * 24 * 60 * 60 * 1000);
  const daysPassed = Math.floor((Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  const daysTotal = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 1000));
  const progressPct = isCurrent ? Math.min(100, Math.max(0, (daysPassed / daysTotal) * 100)) : 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className={`p-5 ${isCurrent ? "border-2 border-orange-300 shadow-lg" : "border-2 border-orange-100"}`}>
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0`} style={{ background: isCurrent ? "linear-gradient(135deg, #f59e0b, #f97316)" : "#d4d4d8" }}>
              {toPersianDigits(index + 1)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm text-slate-900">برنامه {toPersianDigits(index + 1)}</h3>
                {isCurrent && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full text-white font-bold" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                    ● جاری
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500">{PLAN_LABELS[program.planName as any] || program.planName} • {program.weeklyGoal}</p>
            </div>
          </div>
        </div>

        {/* Date range */}
        <div className="flex items-center gap-2 mb-3 p-2 rounded-xl bg-orange-50/50">
          <Calendar className="w-3.5 h-3.5 text-orange-500 shrink-0" />
          <span className="text-[11px] text-slate-600">
            {startDate.toLocaleDateString("fa-IR")} → {endDate.toLocaleDateString("fa-IR")} ({toPersianDigits(daysTotal)} روز)
          </span>
        </div>

        {/* Progress bar for current program */}
        {isCurrent && (
          <div className="mb-3">
            <div className="flex justify-between text-[10px] text-slate-500 mb-1">
              <span>پیشرفت دوره</span>
              <span className="font-bold text-orange-600">{toPersianDigits(Math.round(progressPct))}٪</span>
            </div>
            <div className="h-2 bg-orange-100 rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${progressPct}%`, background: "linear-gradient(90deg, #f59e0b, #f97316)" }} />
            </div>
          </div>
        )}

        {/* Stats grid */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="p-2 rounded-lg bg-slate-50 text-center">
            <Dumbbell className="w-4 h-4 mx-auto mb-1 text-orange-500" />
            <p className="text-xs font-bold text-slate-900">{toPersianDigits(program.exercises)}</p>
            <p className="text-[9px] text-slate-400">حرکت</p>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 text-center">
            <Calendar className="w-4 h-4 mx-auto mb-1 text-orange-500" />
            <p className="text-xs font-bold text-slate-900">{toPersianDigits(program.days)}</p>
            <p className="text-[9px] text-slate-400">روز تمرین</p>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 text-center">
            <Utensils className="w-4 h-4 mx-auto mb-1 text-orange-500" />
            <p className="text-xs font-bold text-slate-900">{toPersianDigits(program.totalCalories)}</p>
            <p className="text-[9px] text-slate-400">کالری/روز</p>
          </div>
        </div>

        {/* Supplements — برنامه مکمل‌ها */}
        {program.supplements && program.supplements.length > 0 && (
          <div className="mb-3 p-3 rounded-xl border border-orange-100 bg-orange-50/30">
            <div className="flex items-center gap-2 mb-2">
              <Pill className="w-3.5 h-3.5 text-orange-500" />
              <p className="text-[11px] font-bold text-slate-700">برنامه مکمل‌ها</p>
            </div>
            <div className="space-y-1">
              {program.supplements.map((s, j) => (
                <div key={j} className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-700 font-medium">{s.name}</span>
                  <span className="text-slate-500">{s.dose} • {s.timing}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Meal Plan — برنامه غذایی */}
        {program.meals && program.meals.length > 0 && (
          <div className="mb-3 p-3 rounded-xl border border-orange-100 bg-white">
            <div className="flex items-center gap-2 mb-2">
              <Salad className="w-3.5 h-3.5 text-orange-500" />
              <p className="text-[11px] font-bold text-slate-700">برنامه غذایی</p>
            </div>
            <div className="space-y-1.5">
              {program.meals.map((m, j) => (
                <div key={j} className="flex items-center justify-between text-[10px] p-1.5 rounded-lg bg-orange-50/40">
                  <span className="text-slate-700 font-medium">{m.label}</span>
                  <span className="text-orange-600 font-bold">{toPersianDigits(m.totalCalories)} کالری</span>
                </div>
              ))}
            </div>
            {/* Macros */}
            <div className="grid grid-cols-3 gap-1 mt-2">
              <div className="text-center p-1 rounded bg-orange-50/30">
                <p className="text-[9px] text-slate-400">پروتئین</p>
                <p className="text-[10px] font-bold text-slate-700">{toPersianDigits(program.totalProtein || 0)}g</p>
              </div>
              <div className="text-center p-1 rounded bg-orange-50/30">
                <p className="text-[9px] text-slate-400">کربو</p>
                <p className="text-[10px] font-bold text-slate-700">{toPersianDigits(program.totalCarbs || 0)}g</p>
              </div>
              <div className="text-center p-1 rounded bg-orange-50/30">
                <p className="text-[9px] text-slate-400">چربی</p>
                <p className="text-[10px] font-bold text-slate-700">{toPersianDigits(program.totalFat || 0)}g</p>
              </div>
            </div>
            <p className="text-[9px] text-slate-400 mt-1">آب روزانه: {toPersianDigits(program.waterLiters || 2.5)} لیتر</p>
          </div>
        )}

        {/* Actions — 3 buttons: تمرین / تغذیه / مکمل */}
        <div className="space-y-2">
          <div className="grid grid-cols-3 gap-2">
            <Button
              size="sm"
              variant="outline"
              className="rounded-xl text-xs border-orange-200 text-orange-600 hover:bg-orange-50 gap-1"
              onClick={() => onOpenView("workout", program)}
            >
              <Dumbbell className="w-3.5 h-3.5" /> تمرین
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="rounded-xl text-xs border-emerald-200 text-emerald-600 hover:bg-emerald-50 gap-1"
              onClick={() => onOpenView("meal", program)}
            >
              <Salad className="w-3.5 h-3.5" /> تغذیه
            </Button>
            {program.supplements && program.supplements.length > 0 ? (
              <Button
                size="sm"
                variant="outline"
                className="rounded-xl text-xs border-purple-200 text-purple-600 hover:bg-purple-50 gap-1"
                onClick={() => onOpenView("supplement", program)}
              >
                <Pill className="w-3.5 h-3.5" /> مکمل
              </Button>
            ) : (
              <Button
                size="sm"
                variant="outline"
                disabled
                className="rounded-xl text-xs border-slate-100 text-slate-300 gap-1 cursor-not-allowed"
                title="مکمل در پلن شما موجود نیست"
              >
                <Pill className="w-3.5 h-3.5" /> مکمل
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              className="flex-1 rounded-xl text-xs border-orange-200 text-orange-600 hover:bg-orange-50 gap-1"
              onClick={onOpenWorkouts}
            >
              <ChevronLeft className="w-3.5 h-3.5" /> مشاهده کامل تمرینات
            </Button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

/* ============ Plan View Modal — نمایش کامل برنامه + دانلود ============ */
function PlanViewModal({ type, program, onClose }: {
  type: "workout" | "meal" | "supplement";
  program: ProgramItem;
  onClose: () => void;
}) {
  const [downloading, setDownloading] = useState<"image" | "pdf" | null>(null);
  const printableRef = useRef<HTMLDivElement>(null);

  if (!program) {
    return null;
  }

  const typeMeta = {
    workout: { label: "برنامه تمرینی", icon: Dumbbell, color: "#f59e0b" },
    meal: { label: "برنامه غذایی", icon: Salad, color: "#10b981" },
    supplement: { label: "برنامه مکمل‌ها", icon: Pill, color: "#a855f7" },
  }[type];
  const Icon = typeMeta.icon;

  async function downloadAsImage() {
    if (!printableRef.current) return;
    setDownloading("image");
    try {
      const { toPng } = await import("html-to-image");
      const node = printableRef.current;
      const orig = { position: node.style.position, top: node.style.top, left: node.style.left, zIndex: node.style.zIndex };
      node.style.position = "fixed"; node.style.top = "0"; node.style.left = "0"; node.style.zIndex = "-9999";
      await new Promise(r => setTimeout(r, 30));
      let dataUrl: string;
      try {
        dataUrl = await toPng(node, { cacheBust: true, pixelRatio: 2, backgroundColor: "#ffffff", width: 800 });
      } finally {
        node.style.position = orig.position; node.style.top = orig.top; node.style.left = orig.left; node.style.zIndex = orig.zIndex;
      }
      const link = document.createElement("a");
      link.download = `fitup-${type}-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
      toast.success("تصویر دانلود شد ✓");
    } catch (e) {
      console.error("[downloadAsImage]", e);
      toast.error("خطا در ساخت تصویر");
    } finally { setDownloading(null); }
  }

  async function downloadAsPDF() {
    if (!printableRef.current) return;
    setDownloading("pdf");
    try {
      const { toPng } = await import("html-to-image");
      const { jsPDF } = await import("jspdf");
      const node = printableRef.current;
      const orig = { position: node.style.position, top: node.style.top, left: node.style.left, zIndex: node.style.zIndex };
      node.style.position = "fixed"; node.style.top = "0"; node.style.left = "0"; node.style.zIndex = "-9999";
      await new Promise(r => setTimeout(r, 30));
      let dataUrl: string;
      try {
        dataUrl = await toPng(node, { cacheBust: true, pixelRatio: 2, backgroundColor: "#ffffff", width: 800 });
      } finally {
        node.style.position = orig.position; node.style.top = orig.top; node.style.left = orig.left; node.style.zIndex = orig.zIndex;
      }
      const img = new Image();
      img.src = dataUrl;
      await new Promise(res => { img.onload = res; });
      const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
      const pw = pdf.internal.pageSize.getWidth();
      const ph = pdf.internal.pageSize.getHeight();
      const ratio = img.height / img.width;
      const iw = pw - 40;
      const ih = iw * ratio;
      if (ih <= ph - 40) {
        pdf.addImage(dataUrl, "PNG", 20, 20, iw, ih);
      } else {
        const canvas = document.createElement("canvas");
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0);
        const sliceH = Math.floor((img.width * (ph - 40)) / (pw - 40));
        let y = 0; let p = 0;
        while (y < img.height) {
          const sc = document.createElement("canvas");
          sc.width = img.width; sc.height = Math.min(sliceH, img.height - y);
          const sctx = sc.getContext("2d")!;
          sctx.drawImage(canvas, 0, y, img.width, sc.height, 0, 0, img.width, sc.height);
          if (p > 0) pdf.addPage();
          pdf.addImage(sc.toDataURL("image/png"), "PNG", 20, 20, iw, (sc.height / img.width) * iw);
          y += sliceH; p++;
        }
      }
      pdf.save(`fitup-${type}-${Date.now()}.pdf`);
      toast.success("PDF دانلود شد ✓");
    } catch (e) {
      console.error("[downloadAsPDF]", e);
      toast.error("خطا در ساخت PDF");
    } finally { setDownloading(null); }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-3xl max-h-[92vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Icon className="w-5 h-5" style={{ color: typeMeta.color }} />
              {typeMeta.label}
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={downloadAsImage} disabled={downloading !== null} className="rounded-xl gap-1.5">
                {downloading === "image" ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                تصویر
              </Button>
              <Button size="sm" variant="outline" onClick={downloadAsPDF} disabled={downloading !== null} className="rounded-xl gap-1.5">
                {downloading === "pdf" ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                PDF
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        {/* Printable content */}
        <div ref={printableRef} className="p-4 bg-white rounded-xl" style={{ fontFamily: "Vazirmatn, Tahoma, Arial, system-ui, sans-serif" }}>
          {/* Header */}
          <div className="flex items-center gap-3 pb-3 mb-4 border-b-2" style={{ borderColor: typeMeta.color }}>
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-black text-xl" style={{ background: `linear-gradient(135deg, ${typeMeta.color}, ${typeMeta.color}dd)` }}>
              ف
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-black text-slate-900">{typeMeta.label} — فیتاپ</h2>
              <p className="text-xs text-slate-500">پلن {program.planName === "basic" ? "اقتصادی" : program.planName === "standard" ? "استاندارد" : program.planName === "advanced" ? "پیشرفته" : program.planName === "ultimate" ? "حرفه‌ای" : (program.planName || "")} • {program.weeklyGoal || ""}</p>
            </div>
          </div>

          {/* Content per type */}
          {type === "workout" && program.workoutDays && (
            <div className="space-y-4">
              {program.workoutDays.map((day, di) => (
                <div key={di}>
                  <div className="rounded-xl p-2.5 mb-2 text-white" style={{ background: `linear-gradient(135deg, ${typeMeta.color}, ${typeMeta.color}dd)` }}>
                    <p className="font-black text-sm">{day.day} — {day.title}</p>
                    <p className="text-[10px] opacity-90">{day.focus} • {toPersianDigits(day.estimatedMinutes)} دقیقه • {toPersianDigits(day.exercises?.length || 0)} حرکت</p>
                  </div>
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr style={{ background: "#fff7ed" }}>
                        <th className="p-2 text-right border border-orange-100 text-orange-700 w-8">#</th>
                        <th className="p-2 text-right border border-orange-100 text-orange-700">حرکت</th>
                        <th className="p-2 text-center border border-orange-100 text-orange-700">ست</th>
                        <th className="p-2 text-center border border-orange-100 text-orange-700">تکرار</th>
                        <th className="p-2 text-center border border-orange-100 text-orange-700">استراحت</th>
                      </tr>
                    </thead>
                    <tbody>
                      {day.exercises?.map((ex, ei) => (
                        <tr key={ei} className="border-b border-orange-50">
                          <td className="p-2 text-right font-bold text-orange-600 align-top">{toPersianDigits(ei + 1)}</td>
                          <td className="p-2 text-right align-top">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-slate-900">{ex.name}</span>
                              {ex.supersetGroup && (
                                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700 border border-purple-200 font-bold">
                                  {ex.supersetType === "triset" ? "تری‌ست" : "سوپرست"} {ex.supersetGroup}
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-slate-400 mt-0.5">{ex.muscle}</p>
                            {ex.description && <p className="text-[10px] text-slate-600 mt-1 leading-relaxed">{ex.description}</p>}
                            {ex.tips && <p className="text-[9px] text-amber-600 mt-0.5">💡 {ex.tips}</p>}
                          </td>
                          <td className="p-2 text-center font-bold text-slate-900 align-top">{toPersianDigits(ex.sets?.length || 0)}</td>
                          <td className="p-2 text-center text-slate-700 align-top">
                            {ex.sets?.map((s, k) => (
                              <span key={k}>{toPersianDigits(s.reps)}{k < ex.sets.length - 1 ? " / " : ""}</span>
                            ))}
                          </td>
                          <td className="p-2 text-center text-slate-700 align-top">
                            {ex.supersetGroup ? "—" : `${toPersianDigits(ex.sets?.[0]?.restSec ?? 0)}s`}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
          )}

          {type === "meal" && program.meals && (
            <div className="space-y-3">
              {/* Macros summary */}
              <div className="grid grid-cols-4 gap-2 p-3 rounded-xl bg-emerald-50/50">
                <div className="text-center">
                  <p className="text-[10px] text-slate-500">کالری</p>
                  <p className="font-black text-emerald-600">{toPersianDigits(program.totalCalories || 0)}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-500">پروتئین</p>
                  <p className="font-bold text-red-600">{toPersianDigits(program.totalProtein || 0)}g</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-500">کربو</p>
                  <p className="font-bold text-amber-600">{toPersianDigits(program.totalCarbs || 0)}g</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-500">چربی</p>
                  <p className="font-bold text-blue-600">{toPersianDigits(program.totalFat || 0)}g</p>
                </div>
              </div>

              {program.meals.map((m, mi) => (
                <div key={mi} className="p-3 rounded-xl border border-emerald-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-slate-900 text-sm">{m.label}</span>
                    <span className="text-xs text-emerald-600 font-bold">{toPersianDigits(m.totalCalories)} کالری</span>
                  </div>
                  {m.combination && (
                    <p className="text-[11px] text-slate-600 mb-2 p-1.5 rounded bg-emerald-50/50">🍽 ترکیب: {m.combination}</p>
                  )}
                  <div className="space-y-1">
                    {m.items?.map((it, ii) => (
                      <div key={ii} className="flex items-center justify-between text-[11px] py-1 border-b last:border-0 border-emerald-50">
                        <div>
                          <span className="font-medium text-slate-700">{it.name}</span>
                          {it.servingSize && <span className="text-slate-400 mr-2">({it.servingSize})</span>}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-500">{toPersianDigits(it.calories)} کالری</span>
                          <span className="text-[9px] px-1 rounded bg-red-50 text-red-600">P{toPersianDigits(it.protein)}</span>
                          <span className="text-[9px] px-1 rounded bg-amber-50 text-amber-600">C{toPersianDigits(it.carbs)}</span>
                          <span className="text-[9px] px-1 rounded bg-blue-50 text-blue-600">F{toPersianDigits(it.fat)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  {m.alternatives && m.alternatives.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-emerald-50">
                      <p className="text-[10px] font-bold text-slate-500 mb-1">🔄 غذاهای جایگزین:</p>
                      {m.alternatives.map((alt, ai) => (
                        <div key={ai} className="text-[10px] text-slate-600 p-1.5 rounded bg-slate-50 mb-1">
                          <span className="font-medium">گزینه {toPersianDigits(ai + 1)}: {alt.combination}</span>
                          <span className="text-slate-400 mr-2">({toPersianDigits(alt.totalCalories)} کالری)</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              {program.waterLiters && (
                <p className="text-[11px] text-cyan-600 text-center">💧 آب روزانه: {toPersianDigits(program.waterLiters)} لیتر</p>
              )}
            </div>
          )}

          {type === "supplement" && program.supplements && (
            <div className="space-y-2">
              {program.supplements.map((s, si) => (
                <div key={si} className="p-3 rounded-xl border border-purple-100 bg-purple-50/30">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm">{s.name}</span>
                    <span className="text-xs text-purple-600 font-bold">{s.dose}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">⏰ {s.timing}</p>
                  {s.note && <p className="text-[10px] text-slate-400 mt-1">{s.note}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
