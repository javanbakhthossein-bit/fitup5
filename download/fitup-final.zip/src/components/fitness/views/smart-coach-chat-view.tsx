"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Send, Sparkles, Dumbbell, Salad, RotateCcw, Bot, ImageIcon, Video, Lock, X, Loader2 } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { UpgradeBanner } from "@/components/fitness/upgrade-banner";
import { canAccess, type ChatMessageDto } from "@/lib/fitness/types";
import { toast } from "sonner";

const QUICK_PROMPTS = [
  { icon: Dumbbell, text: "یکی از حرکات امروز را سخت‌تر کن" },
  { icon: Salad, text: "یک میان‌وعده کم‌کالری پیشنهاد بده" },
  { icon: RotateCcw, text: "جایگزینی برای اسکوات بده" },
];

/** تبدیل File به Data URL برای ارسال به سرور */
function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function SmartCoachChatView() {
  const { user, chatMessages, setChatMessages, addChatMessage, setOverlay } = useAppStore();
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // پیش‌نمایش مدیای انتخاب‌شده قبل از ارسال
  const [selectedImage, setSelectedImage] = useState<string | null>(null); // data URL
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null); // data URL

  const planName = user?.planName ?? null;
  const canChat = canAccess(planName, "aiChatQuestions");
  const canSendImage = canAccess(planName, "chatImageUpload");
  const canSendVideo = canAccess(planName, "chatVideoUpload");

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/coach/chat");
        const data = await res.json();
        setChatMessages(data.messages || []);
        setError(false);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [chatMessages, sending]);

  async function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("فقط فایل تصویری مجاز است.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("حداکثر حجم عکس ۵ مگابایت است.");
      return;
    }
    try {
      const dataUrl = await fileToDataUrl(file);
      setSelectedImage(dataUrl);
      setSelectedVideo(null); // فقط یک مدیا همزمان
    } catch {
      toast.error("خطا در پردازش عکس. دوباره تلاش کنید.");
    }
  }

  async function handleVideoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("video/")) {
      toast.error("فقط فایل ویدیویی مجاز است.");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("حداکثر حجم ویدیو ۲۰ مگابایت است.");
      return;
    }
    try {
      const dataUrl = await fileToDataUrl(file);
      setSelectedVideo(dataUrl);
      setSelectedImage(null); // فقط یک مدیا همزمان
    } catch {
      toast.error("خطا در پردازش ویدیو. دوباره تلاش کنید.");
    }
  }

  async function send(text?: string) {
    const message = (text ?? input).trim();
    if ((!message && !selectedImage && !selectedVideo) || sending) return;
    if (!canChat) {
      toast.info("برای چت با مربی هوشمند باید پلن خود را ارتقا دهید");
      setOverlay("subscription");
      return;
    }
    setInput("");
    setSending(true);

    // ساخت پیام موقت با مدیا برای نمایش فوری
    const tempUserMsg: ChatMessageDto = {
      id: `temp_${Date.now()}`,
      role: "user",
      content: message || (selectedImage ? "📷 عکس" : selectedVideo ? "🎬 ویدیو" : ""),
      mediaUrl: selectedImage ?? selectedVideo,
      mediaType: selectedImage ? "image" : selectedVideo ? "video" : null,
      createdAt: new Date().toISOString(),
    };
    addChatMessage(tempUserMsg);

    // ذخیره مدیا قبل از ارسال به سرور (تا بعد از ارسال هم نمایش داده شود)
    const imageData = selectedImage;
    const videoData = selectedVideo;
    setSelectedImage(null);
    setSelectedVideo(null);

    try {
      const res = await fetch("/api/coach/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          imageBase64: imageData || undefined,
          videoBase64: videoData || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setChatMessages([
        ...chatMessages.filter((m) => m.id !== tempUserMsg.id),
        data.userMessage,
        data.aiMessage,
      ]);
    } catch (e) {
      setChatMessages(chatMessages.filter((m) => m.id !== tempUserMsg.id));
      const errMsg = e instanceof Error ? e.message : "خطا در ارتباط با سرور";
      addChatMessage({
        id: `err_${Date.now()}`,
        role: "assistant",
        content: `⚠️ ${errMsg}. اتصال اینترنت خود را بررسی کنید.`,
        createdAt: new Date().toISOString(),
      });
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  // اگر کاربر به چت دسترسی ندارد (Basic/Standard) → بنر ارتقا
  if (!loading && !canChat) {
    return (
      <div className="px-4 py-4 max-w-md mx-auto">
        <UpgradeBanner
          featureLabel="مربی هوشمند فیتاپ"
          requiredPlan="advanced"
          description="با ارتقا به پلن پیشرفته، به مربی هوشمند با دسترسی کامل به داده‌های آنبوردینگ، آزمایش خون و اهداف شما دسترسی پیدا کن. برنامه تمرینی هفتگی، کالری دقیق، مکمل‌ها و پاسخ فنی — همه در ۲۴ ساعت شبانه‌روز."
          icon={<Dumbbell className="w-8 h-8 text-white" />}
        />
        <div className="mt-4 p-3 rounded-2xl glass border-orange-500/20 text-center">
          <p className="text-xs text-muted-foreground mb-2">💡 در عوض می‌تونی با «نیکا» چت کنی — راهنمای فروش و پشتیبانی</p>
          <Button size="sm" variant="outline" className="rounded-xl" onClick={() => useAppStore.getState().setChatMode("nika")}>
            <Bot className="w-4 h-4 text-orange-400" /> رفتن به چت نیکا
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-12rem)] max-w-md mx-auto">
      {/* فایل‌های مخفی برای انتخاب عکس/ویدیو */}
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageSelect}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleVideoSelect}
      />

      {/* هدر مربی هوشمند — تم تیره طلایی ورزشی */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-primary/15 glass-gold rounded-2xl">
        <div className="relative">
          <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shadow-md glow-gold-sm">
            <Dumbbell className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-background" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-sm">مربی هوشمند فیتاپ</h3>
          <p className="text-[11px] text-emerald-500 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            آنلاین — دسترسی کامل به پرونده شما
          </p>
        </div>
        <Sparkles className="w-5 h-5 text-primary" />
      </div>

      {/* پیام‌ها */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto chat-scroll px-4 py-4 space-y-3">
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-16 w-3/4 rounded-2xl" />
            <Skeleton className="h-20 w-3/4 rounded-2xl mr-auto" />
          </div>
        ) : chatMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring" }}
              className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shadow-xl glow-gold mb-4"
            >
              <Dumbbell className="w-10 h-10 text-primary-foreground" />
            </motion.div>
            <h3 className="font-bold text-lg mb-1">مربی هوشمند آماده‌ست 💪</h3>
            <p className="text-sm text-muted-foreground mb-6">
              من به تمام اطلاعات آنبوردینگ، آزمایش خون و اهداف تو دسترسی دارم. هر سوال فنی ورزشی یا تغذیه‌ای بپرس،
              برنامه تمرینی، مکمل یا کالری دقیق بخواه.
            </p>
            <div className="w-full space-y-2">
              {QUICK_PROMPTS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => send(p.text)}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl glass border-border/50 hover:border-primary/40 transition text-right text-sm"
                >
                  <p.icon className="w-5 h-5 text-primary shrink-0" />
                  {p.text}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            {chatMessages.map((msg) => (
              <CoachBubble key={msg.id} message={msg} />
            ))}
            {sending && <CoachTyping />}
          </>
        )}
      </div>

      {/* ورودی */}
      <div className="border-t bg-card p-3">
        {error && (
          <div className="text-xs text-destructive bg-destructive/10 rounded-lg px-3 py-2 mb-2 text-center">
            اتصال برقرار نشد. در حال تلاش مجدد...
          </div>
        )}

        {/* پیش‌نمایش مدیای انتخاب‌شده */}
        {(selectedImage || selectedVideo) && (
          <div className="mb-2 relative inline-block">
            {selectedImage ? (
              <img
                src={selectedImage}
                alt="پیش‌نمایش عکس"
                className="w-20 h-20 object-cover rounded-xl border border-primary/30"
              />
            ) : selectedVideo ? (
              <video
                src={selectedVideo}
                className="w-20 h-20 object-cover rounded-xl border border-primary/30"
                muted
              />
            ) : null}
            <button
              onClick={() => {
                setSelectedImage(null);
                setSelectedVideo(null);
              }}
              className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center shadow-md"
              aria-label="حذف مدیا"
              title="حذف"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        <div className="flex items-end gap-2">
          <div className="flex gap-1">
            <button
              onClick={() => (canSendImage ? imageInputRef.current?.click() : (toast.info("برای ارسال عکس به پلن پیشرفته ارتقا دهید"), setOverlay("subscription")))}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition ${canSendImage ? "bg-muted hover:bg-primary hover:text-primary-foreground" : "bg-muted/40 text-muted-foreground/50"}`}
              title={canSendImage ? "ارسال عکس" : "نیازمند پلن پیشرفته"}
              disabled={sending}
            >
              {canSendImage ? <ImageIcon className="w-4 h-4" /> : <Lock className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => (canSendVideo ? videoInputRef.current?.click() : (toast.info("برای ارسال ویدیو به پلن حرفه‌ای ارتقا دهید"), setOverlay("subscription")))}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition ${canSendVideo ? "bg-muted hover:bg-primary hover:text-primary-foreground" : "bg-muted/40 text-muted-foreground/50"}`}
              title={canSendVideo ? "ارسال ویدیو" : "نیازمند پلن حرفه‌ای"}
              disabled={sending}
            >
              {canSendVideo ? <Video className="w-4 h-4" /> : <Lock className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="سوال تخصصی از مربی..."
              rows={1}
              className="w-full resize-none rounded-2xl border bg-background px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 max-h-24"
              disabled={sending}
            />
          </div>
          <Button
            onClick={() => send()}
            disabled={(!input.trim() && !selectedImage && !selectedVideo) || sending}
            className="rounded-full w-11 h-11 p-0 shrink-0 bg-gradient-to-br from-primary to-amber-500 glow-gold-sm"
            size="icon"
          >
            {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 -rotate-180" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

function CoachBubble({ message }: { message: ChatMessageDto }) {
  const isUser = message.role === "user";
  const time = new Date(message.createdAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex ${isUser ? "justify-start" : "justify-end"}`}
    >
      <div className={`max-w-[80%] ${isUser ? "order-2" : ""}`}>
        {!isUser && (
          <div className="flex items-center gap-1.5 mb-1 justify-end">
            <span className="text-[10px] text-primary">مربی هوشمند</span>
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center glow-gold-sm">
              <Dumbbell className="w-3 h-3 text-primary-foreground" />
            </div>
          </div>
        )}
        {/* نمایش مدیا در بالای متن پیام کاربر */}
        {isUser && message.mediaUrl && (
          <div className="mb-1.5">
            {message.mediaType === "image" ? (
              <img
                src={message.mediaUrl}
                alt="عکس ارسالی"
                className="max-w-[220px] max-h-[220px] w-auto h-auto object-cover rounded-2xl border-2 border-primary/30"
              />
            ) : message.mediaType === "video" ? (
              <video
                src={message.mediaUrl}
                controls
                className="max-w-[240px] max-h-[260px] w-auto h-auto object-cover rounded-2xl border-2 border-primary/30"
              />
            ) : null}
          </div>
        )}
        {(message.content || !isUser) && (
          <div
            className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
              isUser
                ? "bg-primary text-primary-foreground rounded-bl-md"
                : "glass-strong border-primary/20 rounded-br-md"
            }`}
          >
            {message.content}
          </div>
        )}
        <div className={`text-[10px] text-muted-foreground mt-1 ${isUser ? "text-left" : "text-right"}`}>{time}</div>
      </div>
    </motion.div>
  );
}

function CoachTyping() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-end">
      <div className="glass-strong border-primary/20 rounded-2xl rounded-br-md px-4 py-3 flex items-center gap-1.5">
        <span className="typing-dot w-2 h-2 rounded-full bg-primary" />
        <span className="typing-dot w-2 h-2 rounded-full bg-primary" />
        <span className="typing-dot w-2 h-2 rounded-full bg-primary" />
      </div>
    </motion.div>
  );
}
