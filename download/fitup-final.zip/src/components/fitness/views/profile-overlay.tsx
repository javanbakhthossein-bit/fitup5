"use client";

import { useEffect, useState } from "react";
import {
  X,
  Crown,
  Shield,
  LogOut,
  ChevronLeft,
  CreditCard,
  Settings,
  Dumbbell,
  Activity,
  Wallet,
  Ruler,
  HeartPulse,
  Salad,
  Trophy,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  toPersianDigits, formatToman,
  PLAN_LABELS,
} from "@/lib/fitness/types";
import { toast } from "sonner";

interface OnboardingProfileDto {
  gender: string;
  genderLabel: string;
  age: number;
  height: number;
  weight: number;
  targetWeight: number | null;
  goal: string;
  goalLabel: string;
  activityLevel: string;
  activityLabel: string;
  workoutDays: number;
  workoutDaysList: string[];
  workoutPlace: string;
  workoutPlaceLabel: string;
  dietType: string;
  dietLabel: string;
  allergies: string;
  injuries: string;
  diseases: string;
  equipment: string[];
  trainingExperience: string | null;
  trainingExperienceLabel: string | null;
  previousTrainingType: string | null;
  drugAllergies: string | null;
  currentMedications: string | null;
  maxLifts: string | null;
}

interface BaselineDto {
  weight: number;
  chestMeasurement: number | null;
  armMeasurement: number | null;
  waistMeasurement: number | null;
  hipMeasurement: number | null;
  thighMeasurement: number | null;
  createdAt: string;
}

export function ProfileOverlay() {
  const { user, setOverlay, reset } = useAppStore();
  const [profile, setProfile] = useState<any>(null);
  const [onboarding, setOnboarding] = useState<{
    analysis?: string;
    bmi?: number;
    bmr?: number;
    tdee?: number;
    profile?: OnboardingProfileDto;
    baseline?: BaselineDto | null;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [walletOpen, setWalletOpen] = useState(false);
  const [chargeAmount, setChargeAmount] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const [progressRes, onboardingRes] = await Promise.all([
          fetch("/api/progress"),
          fetch("/api/onboarding/analysis"),
        ]);
        const progressData = await progressRes.json();
        let onboardingData: any = null;
        try { onboardingData = await onboardingRes.json(); } catch {}
        setProfile({
          startWeight: progressData.startWeight,
          targetWeight: progressData.targetWeight,
          bmi: onboardingData?.bmi,
          bmr: onboardingData?.bmr,
          tdee: onboardingData?.tdee,
          gender: (onboardingData?.profile?.genderLabel || "").includes("آقا") ? "male" : (onboardingData?.profile?.genderLabel || "").includes("خانم") ? "female" : null,
        });
        if (onboardingData) setOnboarding(onboardingData);
      } catch {
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      reset();
      toast.success("با موفقیت خارج شدید");
    } catch {
      toast.error("خطا در خروج");
    }
  }

  const subEndDate = user?.subscriptionEnd ? new Date(user.subscriptionEnd) : null;
  const daysLeft = subEndDate ? Math.ceil((subEndDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;

  const p = onboarding?.profile;
  const baseline = onboarding?.baseline;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="font-bold">پروفایل</h2>
        <Button variant="ghost" size="icon" onClick={() => setOverlay(null)} className="rounded-full">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
        {/* User card */}
        <Card className="p-5 relative overflow-hidden">
          <div className="absolute -left-8 -top-8 w-32 h-32 rounded-full bg-primary/10" />
          <div className="relative flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center text-white text-2xl font-black shadow-lg">
              {user?.name?.[0] || "ک"}
            </div>
            <div className="flex-1">
              <h3 className="font-black text-lg">{user?.name || "ورزشکار"}</h3>
              <p className="text-sm text-muted-foreground" dir="ltr">{user?.mobile}</p>
              <div className="flex items-center gap-1.5 flex-wrap mt-1">
                {user?.role === "ADMIN" && (
                  <span className="inline-flex items-center gap-1 text-[11px] bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    <Shield className="w-3 h-3" /> مدیر سیستم
                  </span>
                )}
                {user?.planName && (
                  <span className="inline-flex items-center gap-1 text-[11px] bg-amber-500/15 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full">
                    <Crown className="w-3 h-3" /> پلن {PLAN_LABELS[user.planName as keyof typeof PLAN_LABELS] ?? user.planName}
                  </span>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Subscription status */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-sm">وضعیت اشتراک</h3>
            </div>
          </div>
          {user?.hasActiveSubscription ? (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-sm text-emerald-600 dark:text-emerald-400">اشتراک فعال ✓</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {toPersianDigits(daysLeft)} روز باقی‌مانده
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-[11px] text-muted-foreground">تاریخ پایان</p>
                  <p className="text-xs font-medium">{subEndDate?.toLocaleDateString("fa-IR")}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <p className="text-sm font-medium text-amber-600 dark:text-amber-400 mb-2">اشتراک فعال نیست</p>
              <Button
                size="sm"
                className="w-full rounded-xl"
                onClick={() => setOverlay("subscription")}
              >
                <Crown className="w-4 h-4" />
                خرید پلن
              </Button>
            </div>
          )}
        </Card>

        {/* Wallet */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-cyan-500" />
              <h3 className="font-bold text-sm">کیف پول</h3>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="text-[11px] text-muted-foreground">موجودی فعلی</p>
                <p className="font-black text-lg text-cyan-600 dark:text-cyan-400">
                  {toPersianDigits((user?.walletBalance ?? 0).toLocaleString("en-US"))} <span className="text-xs font-normal">تومان</span>
                </p>
              </div>
              <Wallet className="w-8 h-8 text-cyan-500/40" />
            </div>
            <Button
              size="sm"
              variant="outline"
              className="w-full rounded-xl"
              onClick={() => setWalletOpen(true)}
            >
              شارژ کیف پول
            </Button>
          </div>
        </Card>

        {/* Physical info / metrics */}
        {loading ? (
          <Skeleton className="h-32 rounded-2xl" />
        ) : (
          profile && (
            <Card className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="w-5 h-5 text-primary" />
                <h3 className="font-bold text-sm">اطلاعات فیزیکی</h3>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <InfoRow label="وزن شروع" value={profile.startWeight ? `${toPersianDigits(profile.startWeight)} kg` : "—"} />
                <InfoRow label="وزن هدف" value={profile.targetWeight ? `${toPersianDigits(profile.targetWeight)} kg` : "—"} />
                {profile.bmi && <InfoRow label="شاخص BMI" value={toPersianDigits(profile.bmi)} />}
                {profile.bmr && <InfoRow label="متابولیسم (BMR)" value={`${toPersianDigits(profile.bmr)} کالری`} />}
                {profile.tdee && <InfoRow label="کالری روزانه (TDEE)" value={`${toPersianDigits(profile.tdee)} کالری`} />}
              </div>
            </Card>
          )
        )}

        {/* Onboarding profile — اطلاعات آنبوردینگ */}
        {loading ? (
          <Skeleton className="h-64 rounded-2xl" />
        ) : p ? (
          <Card className="p-4 space-y-4">
            <div className="flex items-center gap-2">
              <Dumbbell className="w-5 h-5 text-primary" />
              <h3 className="font-bold text-sm">اطلاعات آنبوردینگ</h3>
            </div>

            {/* Basic physical info */}
            <Section title="مشخصات پایه">
              <div className="grid grid-cols-2 gap-2">
                <InfoRow label="جنسیت" value={p.genderLabel || "—"} />
                <InfoRow label="سن" value={`${toPersianDigits(p.age)} سال`} />
                <InfoRow label="قد" value={`${toPersianDigits(p.height)} cm`} />
                <InfoRow label="وزن فعلی" value={`${toPersianDigits(p.weight)} kg`} />
                {p.targetWeight != null && <InfoRow label="وزن هدف" value={`${toPersianDigits(p.targetWeight)} kg`} />}
              </div>
            </Section>

            {/* Goal & activity */}
            <Section title="هدف و فعالیت">
              <div className="grid grid-cols-1 gap-2">
                <InfoRow label="هدف اصلی" value={p.goalLabel} />
                <InfoRow label="سطح فعالیت" value={p.activityLabel} />
                <InfoRow label="روزهای تمرین" value={`${toPersianDigits(p.workoutDays)} روز در هفته`} />
                {p.workoutDaysList && p.workoutDaysList.length > 0 && (
                  <InfoRow label="روزهای انتخابی" value={p.workoutDaysList.join("، ")} />
                )}
                <InfoRow label="محیط تمرین" value={p.workoutPlaceLabel} />
              </div>
            </Section>

            {/* Diet */}
            <Section title="تغذیه" icon={<Salad className="w-4 h-4 text-emerald-500" />}>
              <div className="grid grid-cols-1 gap-2">
                <InfoRow label="نوع رژیم" value={p.dietLabel} />
                <InfoRow label="آلرژی غذایی" value={p.allergies?.trim() ? p.allergies : "ندارد"} />
              </div>
            </Section>

            {/* Medical */}
            <Section title="پزشکی" icon={<HeartPulse className="w-4 h-4 text-rose-500" />}>
              <div className="grid grid-cols-1 gap-2">
                <InfoRow label="آسیب‌دیدگی" value={p.injuries?.trim() ? p.injuries : "ندارد"} />
                <InfoRow label="بیماری‌ها" value={p.diseases?.trim() ? p.diseases : "ندارد"} />
                {p.drugAllergies && <InfoRow label="آلرژی دارویی" value={p.drugAllergies} />}
                {p.currentMedications && <InfoRow label="داروهای مصرفی" value={p.currentMedications} />}
              </div>
            </Section>

            {/* Training experience */}
            {(p.trainingExperienceLabel || p.previousTrainingType || p.maxLifts) && (
              <Section title="تجربه ورزشی" icon={<Trophy className="w-4 h-4 text-amber-500" />}>
                <div className="grid grid-cols-1 gap-2">
                  {p.trainingExperienceLabel && <InfoRow label="سابقه ورزشی" value={p.trainingExperienceLabel} />}
                  {p.previousTrainingType && <InfoRow label="نوع تمرین قبلی" value={p.previousTrainingType} />}
                  {p.maxLifts && <InfoRow label="حداکثر وزنه‌ها" value={p.maxLifts} />}
                </div>
              </Section>
            )}

            {/* Equipment */}
            {p.equipment && p.equipment.length > 0 && (
              <Section title="تجهیزات در دسترس">
                <div className="flex flex-wrap gap-1.5">
                  {p.equipment.map((eq) => (
                    <span key={eq} className="text-[11px] px-2 py-1 rounded-lg bg-muted/60 text-foreground">
                      {eq}
                    </span>
                  ))}
                </div>
              </Section>
            )}

            {/* Baseline measurements */}
            {baseline && (
              <Section title="اندازه‌های اولیه بدن (Baseline)" icon={<Ruler className="w-4 h-4 text-violet-500" />}>
                <div className="grid grid-cols-2 gap-2">
                  <InfoRow label="وزن اولیه" value={`${toPersianDigits(baseline.weight)} kg`} />
                  {baseline.chestMeasurement != null && (
                    <InfoRow label="دور سینه" value={`${toPersianDigits(baseline.chestMeasurement)} cm`} />
                  )}
                  {baseline.armMeasurement != null && (
                    <InfoRow label="دور بازو" value={`${toPersianDigits(baseline.armMeasurement)} cm`} />
                  )}
                  {baseline.waistMeasurement != null && (
                    <InfoRow label="دور کمر" value={`${toPersianDigits(baseline.waistMeasurement)} cm`} />
                  )}
                  {baseline.hipMeasurement != null && (
                    <InfoRow label="دور باسن" value={`${toPersianDigits(baseline.hipMeasurement)} cm`} />
                  )}
                  {baseline.thighMeasurement != null && (
                    <InfoRow label="دور ران" value={`${toPersianDigits(baseline.thighMeasurement)} cm`} />
                  )}
                </div>
                {baseline.createdAt && (
                  <p className="text-[10px] text-muted-foreground mt-1.5">
                    ثبت شده در: {new Date(baseline.createdAt).toLocaleDateString("fa-IR")}
                  </p>
                )}
              </Section>
            )}
          </Card>
        ) : null}

        {/* AI analysis snippet */}
        {onboarding?.analysis && (
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <h3 className="font-bold text-sm">تحلیل فیتاپ هوشمند</h3>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-line">
              {onboarding.analysis}
            </p>
          </Card>
        )}

        {/* Settings list */}
        <div className="space-y-1">
          <SettingsRow
            icon={CreditCard}
            label="مدیریت اشتراک"
            onClick={() => setOverlay("subscription")}
            chevron
          />
          {user?.role === "ADMIN" && (
            <SettingsRow
              icon={Settings}
              label="پنل مدیریت"
              onClick={() => setOverlay("admin")}
              chevron
              highlight
            />
          )}
        </div>

        {/* Logout */}
        <Button
          variant="outline"
          onClick={handleLogout}
          className="w-full rounded-xl text-destructive hover:text-destructive hover:bg-destructive/5"
        >
          <LogOut className="w-4 h-4" />
          خروج از حساب
        </Button>

        <p className="text-center text-[11px] text-muted-foreground pt-2">
          فیتاپ — نسخه ۱.۰.۰
        </p>
      </div>

      {/* Wallet Charge Modal */}
      <Dialog open={walletOpen} onOpenChange={setWalletOpen}>
        <DialogContent dir="rtl" className="max-w-sm">
          <DialogHeader><DialogTitle>شارژ کیف پول</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="p-2 rounded-lg bg-orange-50 text-xs text-center">موجودی فعلی: <b className="font-stat">{toPersianDigits(formatToman(user?.walletBalance || 0))} ت</b></div>
            <div>
              <Label className="mb-1 block">مبلغ (تومان)</Label>
              <Input type="number" dir="ltr" value={chargeAmount} onChange={(e) => setChargeAmount(e.target.value)} placeholder="مثلاً ۵۰۰۰۰۰" className="rounded-xl text-center font-stat" />
            </div>
            <div className="flex gap-2 flex-wrap">
              {[100000, 500000, 1000000].map(v => (
                <button key={v} onClick={() => setChargeAmount(String(v))} className="text-xs px-3 py-1.5 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-600 font-stat transition">
                  {toPersianDigits(formatToman(v))}
                </button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setWalletOpen(false)} className="rounded-xl">انصراف</Button>
            <Button
              onClick={async () => {
                if (!chargeAmount || Number(chargeAmount) <= 0) return;
                try {
                  const res = await fetch("/api/wallet", {
                    method: "POST", headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ amount: Number(chargeAmount) }),
                  });
                  if (!res.ok) throw new Error();
                  const data = await res.json();
                  toast.success(`کیف پول ${toPersianDigits(formatToman(Number(chargeAmount)))} ت شارژ شد ✓`);
                  setWalletOpen(false);
                  setChargeAmount("");
                  // Update user in store
                  if (data.user) useAppStore.getState().setUser(data.user);
                } catch { toast.error("خطا در شارژ کیف پول"); }
              }}
              className="rounded-xl text-white"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              شارژ کیف پول
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Sparkles({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z" />
      <path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15z" />
      <path d="M5 4l.6 1.4L7 6l-1.4.6L5 8l-.6-1.4L3 6l1.4-.6L5 4z" />
    </svg>
  );
}

function Section({ title, icon, children }: { title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2">
        {icon}
        <h4 className="text-xs font-bold text-muted-foreground">{title}</h4>
      </div>
      {children}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between p-2.5 rounded-xl bg-muted/40 gap-2">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      <span className="text-sm font-medium text-left" dir="auto">{value}</span>
    </div>
  );
}

function SettingsRow({
  icon: Icon,
  label,
  action,
  onClick,
  chevron,
  highlight,
}: {
  icon: any;
  label: string;
  action?: React.ReactNode;
  onClick?: () => void;
  chevron?: boolean;
  highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 p-3.5 rounded-2xl transition text-right ${
        highlight ? "bg-primary/5 hover:bg-primary/10" : "hover:bg-muted"
      }`}
    >
      <Icon className={`w-5 h-5 ${highlight ? "text-primary" : "text-muted-foreground"}`} />
      <span className="flex-1 text-sm font-medium">{label}</span>
      {action}
      {chevron && <ChevronLeft className="w-4 h-4 text-muted-foreground" />}
    </button>
  );
}
