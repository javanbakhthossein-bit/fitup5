"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Flame,
  Dumbbell,
  Apple,
  Droplets,
  TrendingDown,
  Trophy,
  ChevronLeft,
  Calendar,
  Zap,
  Utensils,
  Sparkles,
  MessageCircle,
  Lock,
  Dumbbell as GymIcon,
  TestTube,
  Video,
  Salad,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  toPersianDigits,
  canAccess,
  PLAN_LABELS,
  GOAL_LABELS,
  PERSIAN_WEEKDAYS,
  type WorkoutPlanContent,
  type MealPlanContent,
} from "@/lib/fitness/types";

export function HomeView() {
  const { user, setMainTab, setOverlay, workoutPlan, setWorkoutPlan, mealPlan, setMealPlan } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [today, setToday] = useState("");

  useEffect(() => {
    const dayIdx = new Date().getDay(); // 0 = Sunday
    // Convert to Persian week (Saturday = 0)
    const persianIdx = (dayIdx + 1) % 7;
    setToday(PERSIAN_WEEKDAYS[persianIdx]);

    (async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/coach/plan");
        const data = await res.json();
        if (data.workout) setWorkoutPlan(data.workout as WorkoutPlanContent);
        if (data.meal) setMealPlan(data.meal as MealPlanContent);
      } catch {
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const todayWorkout = workoutPlan?.days.find((d) => d.day === today);
  const totalCal = mealPlan?.totalCalories ?? 0;

  return (
    <div className="px-4 py-4 space-y-4 max-w-md mx-auto">
      {/* Greeting hero */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-emerald-600 p-5 text-white shadow-xl"
      >
        <div className="absolute -left-8 -top-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="absolute -left-4 bottom-0 w-20 h-20 rounded-full bg-white/10" />
        <div className="relative">
          <p className="text-white/80 text-sm mb-1">{today}</p>
          <h2 className="text-2xl font-black mb-3">
            {getGreeting()}، {user?.name || "ورزشکار"}! 👋
          </h2>
          <div className="flex items-center gap-2 text-sm">
            <Sparkles className="w-4 h-4" />
            <span>برای امروز برنامه تمرینی و غذایی آماده داریم</span>
          </div>
        </div>
      </motion.div>

      {/* Subscription banner */}
      {!user?.hasActiveSubscription && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => setOverlay("subscription")}
          className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-l from-amber-500/20 to-orange-500/10 border border-amber-500/30"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div className="text-right">
              <p className="font-bold text-sm">اشتراک فعال نیست</p>
              <p className="text-xs text-muted-foreground">برای دسترسی کامل ارتقا دهید</p>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-amber-500" />
        </motion.button>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          icon={Flame}
          label="کالری هدف"
          value={loading ? null : toPersianDigits(totalCal)}
          unit="کیلوکالری"
          color="orange"
        />
        <StatCard
          icon={Dumbbell}
          label="تمرین امروز"
          value={loading ? null : todayWorkout ? toPersianDigits(todayWorkout.exercises.length) : "استراحت"}
          unit={todayWorkout ? "حرکت" : ""}
          color="emerald"
        />
        <StatCard
          icon={Droplets}
          label="آب امروز"
          value={loading ? null : toPersianDigits(mealPlan?.waterLiters ?? 2.5)}
          unit="لیتر"
          color="cyan"
        />
        <StatCard
          icon={Calendar}
          label="روزهای تمرین"
          value={loading ? null : toPersianDigits(workoutPlan?.days.length ?? 0)}
          unit="روز در هفته"
          color="violet"
        />
      </div>

      {/* Today's workout */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Dumbbell className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-bold">تمرین امروز</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary text-xs"
            onClick={() => setMainTab("workouts")}
          >
            مشاهده همه
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
        {loading ? (
          <Skeleton className="h-24 rounded-xl" />
        ) : todayWorkout ? (
          <button
            onClick={() => setMainTab("workouts")}
            className="w-full text-right p-3 rounded-xl bg-muted/50 hover:bg-muted transition"
          >
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="font-bold">{todayWorkout.title}</p>
                <p className="text-xs text-muted-foreground">{todayWorkout.focus}</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-primary font-medium">
                <Zap className="w-3.5 h-3.5" />
                {toPersianDigits(todayWorkout.estimatedMinutes)} دقیقه
              </div>
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {todayWorkout.exercises.slice(0, 4).map((ex, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2 py-1 rounded-md bg-background border"
                >
                  {ex.name}
                </span>
              ))}
              {todayWorkout.exercises.length > 4 && (
                <span className="text-[11px] px-2 py-1 rounded-md bg-background border">
                  +{toPersianDigits(todayWorkout.exercises.length - 4)}
                </span>
              )}
            </div>
          </button>
        ) : (
          <div className="text-center py-6 text-muted-foreground">
            <div className="text-3xl mb-2">🛌</div>
            <p className="text-sm font-medium">امروز روز استراحت شماست</p>
            <p className="text-xs">از بدن خود مراقبت کنید!</p>
          </div>
        )}
      </Card>

      {/* Today's nutrition */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Utensils className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-bold">برنامه غذایی امروز</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary text-xs"
            onClick={() => setOverlay("nutrition")}
          >
            جزئیات
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
        {loading ? (
          <Skeleton className="h-24 rounded-xl" />
        ) : mealPlan ? (
          <div>
            {/* Macro rings */}
            <div className="grid grid-cols-4 gap-2 mb-3">
              <MacroMini label="کالری" value={toPersianDigits(mealPlan.totalCalories)} unit="kcal" pct={100} color="#f97316" />
              <MacroMini label="پروتئین" value={toPersianDigits(mealPlan.totalProtein)} unit="g" pct={Math.min(100, (mealPlan.totalProtein / 150) * 100)} color="#10b981" />
              <MacroMini label="کربو" value={toPersianDigits(mealPlan.totalCarbs)} unit="g" pct={Math.min(100, (mealPlan.totalCarbs / 250) * 100)} color="#06b6d4" />
              <MacroMini label="چربی" value={toPersianDigits(mealPlan.totalFat)} unit="g" pct={Math.min(100, (mealPlan.totalFat / 70) * 100)} color="#a855f7" />
            </div>
            <div className="flex gap-2 flex-wrap">
              {mealPlan.meals.map((m, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2.5 py-1 rounded-md bg-muted/60"
                >
                  {m.label}: {toPersianDigits(m.totalCalories)} کالری
                </span>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground text-sm">
            برنامه غذایی در حال آماده‌سازی است...
          </div>
        )}
      </Card>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3">
        <QuickAction
          icon={MessageCircle}
          label="سوال از مربی AI"
          onClick={() => setMainTab("chat")}
        />
        <QuickAction
          icon={TrendingDown}
          label="ثبت وزن جدید"
          onClick={() => setMainTab("progress")}
        />
      </div>

      {/* امکانات ویژه (Gated by plan) */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="font-bold text-sm">امکانات ویژه پلن شما</h3>
          {user?.planName && (
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-primary/10 text-primary">
              پلن {PLAN_LABELS[user.planName]}
            </span>
          )}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <GatedFeature
            icon={GymIcon}
            label="حالت باشگاه"
            unlocked={canAccess(user?.planName, "gymMode")}
            onClick={() => {
              if (canAccess(user?.planName, "gymMode")) {
                toastInfo("حالت باشگاه به‌زودی فعال می‌شود");
              } else {
                setOverlay("subscription");
              }
            }}
          />
          <GatedFeature
            icon={Salad}
            label="دستیار تغذیه"
            unlocked={canAccess(user?.planName, "nutritionCompanion")}
            onClick={() => setOverlay("nutrition")}
          />
          <GatedFeature
            icon={Video}
            label="آنالیز ویدیویی"
            unlocked={canAccess(user?.planName, "videoBodyAnalysis")}
            onClick={() => {
              if (canAccess(user?.planName, "videoBodyAnalysis")) {
                toastInfo("آپلود ویدیو برای آنالیز بدن");
              } else {
                setOverlay("subscription");
              }
            }}
          />
          <GatedFeature
            icon={TestTube}
            label="تحلیل آزمایش خون"
            unlocked={canAccess(user?.planName, "bloodTestAnalysis")}
            onClick={() => {
              if (canAccess(user?.planName, "bloodTestAnalysis")) {
                toastInfo("آپلود آزمایش خون");
              } else {
                setOverlay("subscription");
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "صبح بخیر";
  if (h < 18) return "بعد از ظهر بخیر";
  return "شب بخیر";
}

const COLOR_MAP: Record<string, string> = {
  orange: "from-orange-500/20 to-orange-500/5 text-orange-500",
  emerald: "from-emerald-500/20 to-emerald-500/5 text-emerald-500",
  cyan: "from-cyan-500/20 to-cyan-500/5 text-cyan-500",
  violet: "from-violet-500/20 to-violet-500/5 text-violet-500",
};

function StatCard({
  icon: Icon,
  label,
  value,
  unit,
  color,
}: {
  icon: any;
  label: string;
  value: string | null;
  unit: string;
  color: string;
}) {
  return (
    <Card className="p-4 relative overflow-hidden">
      <div className={`absolute -left-4 -top-4 w-16 h-16 rounded-full bg-gradient-to-br ${COLOR_MAP[color]} opacity-50`} />
      <div className="relative">
        <Icon className={`w-5 h-5 mb-2 ${COLOR_MAP[color].split(" ").pop()}`} />
        {value === null ? (
          <Skeleton className="h-6 w-16 mb-1" />
        ) : (
          <p className="text-xl font-black">{value}</p>
        )}
        <p className="text-[11px] text-muted-foreground">{label}</p>
        {unit && <p className="text-[10px] text-muted-foreground/70">{unit}</p>}
      </div>
    </Card>
  );
}

function MacroMini({ label, value, unit, pct, color }: { label: string; value: string; unit: string; pct: number; color: string }) {
  return (
    <div className="text-center">
      <div className="relative w-12 h-12 mx-auto mb-1">
        <svg className="w-12 h-12 -rotate-90" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="15" fill="none" stroke="currentColor" strokeWidth="3" className="text-muted/30" />
          <circle
            cx="18"
            cy="18"
            r="15"
            fill="none"
            stroke={color}
            strokeWidth="3"
            strokeDasharray={`${(pct / 100) * 94.2} 94.2`}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold">
          {value}
        </div>
      </div>
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="text-[9px] text-muted-foreground/70">{unit}</p>
    </div>
  );
}

function QuickAction({ icon: Icon, label, onClick }: { icon: any; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 p-4 rounded-2xl bg-card border hover:border-primary/40 transition text-right"
    >
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}

/** کارت قابلیت با گیت پلن — اگر قفل باشد آیکون پادلاک نمایش می‌دهد */
function GatedFeature({
  icon: Icon,
  label,
  unlocked,
  onClick,
}: {
  icon: any;
  label: string;
  unlocked: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative flex flex-col items-center gap-2 p-4 rounded-2xl border transition text-center ${
        unlocked
          ? "bg-card hover:border-primary/40"
          : "bg-muted/30 border-dashed opacity-70 hover:opacity-100"
      }`}
    >
      {!unlocked && (
        <div className="absolute top-2 left-2 w-6 h-6 rounded-full bg-muted flex items-center justify-center">
          <Lock className="w-3 h-3 text-muted-foreground" />
        </div>
      )}
      <div
        className={`w-11 h-11 rounded-xl flex items-center justify-center ${
          unlocked ? "bg-primary/10" : "bg-muted/60"
        }`}
      >
        <Icon className={`w-5 h-5 ${unlocked ? "text-primary" : "text-muted-foreground/50"}`} />
      </div>
      <span
        className={`text-xs font-medium ${unlocked ? "" : "text-muted-foreground"}`}
      >
        {label}
      </span>
    </button>
  );
}

/** helper برای toast اطلاع‌رسانی */
function toastInfo(msg: string) {
  import("sonner").then(({ toast }) => toast.info(msg));
}
