"use client";

import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  LayoutDashboard,
  Users,
  Wallet,
  ListChecks,
  Search,
  Ban,
  Check,
  Shield,
  Plus,
  Crown,
  TrendingUp,
  DollarSign,
  UserCheck,
  Target,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Eye,
  Newspaper,
  Sparkles,
  Send,
  Settings as SettingsIcon,
  Trash2,
  Pencil,
  Code2,
  Save,
  Bot,
  FileText,
  ShieldCheck,
  ClipboardCheck,
  Brain,
  LogOut,
  Heading1,
  Heading2,
  Heading3,
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote,
  Link2,
  Upload,
  Image as ImageIcon,
  MessageSquare,
  Phone,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import ReactMarkdown from "react-markdown";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  SUBSCRIPTION_PLANS, toPersianDigits, formatToman, PLAN_LABELS, type Plan,
} from "@/lib/fitness/types";
import { toast } from "sonner";

type AdminTab = "dashboard" | "users" | "finance" | "programs" | "checkups" | "articles" | "head_codes" | "terms" | "copilot" | "admins" | "tickets";

// All admin permission keys (matches AdminPermission Prisma model)
const PERMISSION_KEYS = [
  "canViewDashboard",
  "canManageUsers",
  "canViewFinance",
  "canManagePrograms",
  "canManageCheckups",
  "canManageArticles",
  "canManageHeadCodes",
  "canManageTerms",
  "canUseCopilot",
  "canManageAdmins",
  "canManageTickets",
] as const;

type PermissionKey = (typeof PERMISSION_KEYS)[number];

interface AdminPermissions {
  canViewDashboard: boolean;
  canManageUsers: boolean;
  canViewFinance: boolean;
  canManagePrograms: boolean;
  canManageCheckups: boolean;
  canManageArticles: boolean;
  canManageHeadCodes: boolean;
  canManageTerms: boolean;
  canUseCopilot: boolean;
  canManageAdmins: boolean;
  canManageTickets: boolean;
}

const ALL_TRUE_PERMISSIONS: AdminPermissions = {
  canViewDashboard: true,
  canManageUsers: true,
  canViewFinance: true,
  canManagePrograms: true,
  canManageCheckups: true,
  canManageArticles: true,
  canManageHeadCodes: true,
  canManageTerms: true,
  canUseCopilot: true,
  canManageAdmins: true,
  canManageTickets: true,
};

// Human-readable Persian labels for each permission
const PERMISSION_LABELS: Record<PermissionKey, string> = {
  canViewDashboard: "مشاهده داشبورد",
  canManageUsers: "مدیریت کاربران",
  canViewFinance: "مشاهده مالی و تراکنش‌ها",
  canManagePrograms: "مدیریت صف برنامه‌ها",
  canManageCheckups: "مدیریت چکاپ‌ها",
  canManageArticles: "مدیریت مقالات",
  canManageHeadCodes: "مدیریت کدهای تحلیلی",
  canManageTerms: "مدیریت قوانین",
  canUseCopilot: "دسترسی به دستیار هوشمند",
  canManageAdmins: "مدیریت ادمین‌ها (فقط سوپرادمین)",
  canManageTickets: "مدیریت تیکت‌های پشتیبانی",
};

function emptyPermissions(): AdminPermissions {
  return {
    canViewDashboard: true,
    canManageUsers: false,
    canViewFinance: false,
    canManagePrograms: false,
    canManageCheckups: false,
    canManageArticles: false,
    canManageHeadCodes: false,
    canManageTerms: false,
    canUseCopilot: false,
    canManageAdmins: false,
    canManageTickets: false,
  };
}

const PLAN_COLORS: Record<string, string> = {
  basic: "#64748b", standard: "#06b6d4", advanced: "#f59e0b", ultimate: "#a855f7",
};

const ARTICLE_CATEGORIES: { value: string; label: string }[] = [
  { value: "general", label: "عمومی" },
  { value: "nutrition", label: "تغذیه" },
  { value: "training", label: "تمرین" },
  { value: "motivation", label: "انگیزشی" },
  { value: "news", label: "اخبار" },
];

function articleCategoryLabel(cat: string): string {
  return ARTICLE_CATEGORIES.find((c) => c.value === cat)?.label || "عمومی";
}

// ---- Head Code (analytics / search console / pixels / Inamad) ----
const HEAD_CODE_TYPES: { value: string; label: string; color: string }[] = [
  { value: "analytics", label: "تحلیل آمار", color: "#f59e0b" },
  { value: "search_console", label: "سرچ کنسول", color: "#10b981" },
  { value: "pixel", label: "پیکسل تبلیغات", color: "#a855f7" },
  { value: "inamad", label: "اینماد", color: "#0ea5e9" },
  { value: "samandehi", label: "ساماندهی", color: "#16a34a" },
  { value: "custom", label: "سفارشی", color: "#64748b" },
];

const HEAD_CODE_PLACEMENTS: { value: string; label: string }[] = [
  { value: "head", label: "داخل <head>" },
  { value: "body_start", label: "ابتدای <body>" },
  { value: "body_end", label: "انتهای <body>" },
];

function headCodeTypeLabel(t: string): string {
  return HEAD_CODE_TYPES.find((x) => x.value === t)?.label || "سفارشی";
}
function headCodeTypeColor(t: string): string {
  return HEAD_CODE_TYPES.find((x) => x.value === t)?.color || "#64748b";
}
function headCodePlacementLabel(p: string): string {
  return HEAD_CODE_PLACEMENTS.find((x) => x.value === p)?.label || p;
}

// Quick template snippets — inserted into the code textarea on click
const HEAD_CODE_TEMPLATES: { id: string; label: string; type: string; placement: string; code: string }[] = [
  {
    id: "ga4",
    label: "Google Analytics 4",
    type: "analytics",
    placement: "head",
    code: `<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>`,
  },
  {
    id: "search_console",
    label: "Google Search Console",
    type: "search_console",
    placement: "head",
    code: `<meta name="google-site-verification" content="YOUR_VERIFICATION_CODE" />`,
  },
  {
    id: "meta_pixel",
    label: "Meta (Facebook) Pixel",
    type: "pixel",
    placement: "body_start",
    code: `<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', 'YOUR_PIXEL_ID');
  fbq('track', 'PageView');
</script>
<noscript>
  <img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=YOUR_PIXEL_ID&ev=PageView&noscript=1" alt="" />
</noscript>
<!-- End Meta Pixel Code -->`,
  },
  {
    id: "microsoft_clarity",
    label: "Microsoft Clarity",
    type: "analytics",
    placement: "head",
    code: `<script type="text/javascript">
  (function(c,l,a,r,i,t,y){
    c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
    t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
    y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
  })(window,document,"clarity","script","YOUR_CLARITY_ID");
</script>`,
  },
  {
    id: "inamad",
    label: "اینماد (نماد اعتماد الکترونیکی)",
    type: "inamad",
    placement: "body_end",
    code: `<!-- نماد اعتماد الکترونیکی (اینماد) -->
<!-- جایگزین کنید: YOUR_INAMAD_ID = شناسه نماد شما -->
<div style="display:flex;justify-content:center;padding:16px 0;">
  <img id="nbzmaeg" src="https://trustseal.enamad.ir/namad.php?id=YOUR_INAMAD_ID" alt="نماد اعتماد الکترونیکی" style="width:100px;height:100px;cursor:pointer;" onclick="window.open('https://trustseal.enamad.ir/Verify.aspx?id=YOUR_INAMAD_ID&p=YOUR_INAMAD_TOKEN', 'Popup','toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0, width=580, height=600, top=30')" />
</div>
<script src="https://trustseal.enamad.ir/scriptContent?a=YOUR_INAMAD_ID"></script>
<!-- پایان اینماد -->`,
  },
  {
    id: "samandehi",
    label: "ساماندهی (نماد ساماندهی)",
    type: "samandehi",
    placement: "body_end",
    code: `<!-- نماد ساماندهی -->
<!-- جایگزین کنید: YOUR_SAMANDEHI_ID = شناسه ساماندهی شما -->
<div style="display:flex;justify-content:center;padding:16px 0;">
  <img id="nbzma" src="https://logo.samandehi.ir/logo.aspx?id=YOUR_SAMANDEHI_ID" alt="نماد ساماندهی" style="width:100px;height:100px;cursor:pointer;" onclick="window.open('https://logo.samandehi.ir/Verify.aspx?id=YOUR_SAMANDEHI_ID', 'Popup','toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0, width=580, height=600, top=30')" />
</div>
<!-- پایان ساماندهی -->`,
  },
];

export function AdminOverlay({ standalone = false }: { standalone?: boolean } = {}) {
  const { setOverlay, reset } = useAppStore();
  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [showSettings, setShowSettings] = useState(false);
  const [permissions, setPermissions] = useState<AdminPermissions>(ALL_TRUE_PERMISSIONS);
  const [permsLoaded, setPermsLoaded] = useState(false);

  // Fetch the current admin's permissions on mount — used to filter visible tabs
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/admin/permissions", { cache: "no-store" });
        if (res.ok) {
          const data = await res.json();
          if (data?.permissions) setPermissions(data.permissions as AdminPermissions);
        }
      } catch {
        // fall back to all-true if the call fails (best-effort)
      } finally {
        setPermsLoaded(true);
      }
    })();
  }, []);

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      reset();
      toast.success("از پنل مدیریت خارج شدید");
    } catch {
      toast.error("خطا در خروج");
    }
  }

  // All possible tabs — we filter the visible ones based on permissions
  const allTabs: { id: AdminTab; label: string; icon: any; perm: PermissionKey }[] = [
    { id: "dashboard", label: "داشبورد", icon: LayoutDashboard, perm: "canViewDashboard" },
    { id: "users", label: "کاربران", icon: Users, perm: "canManageUsers" },
    { id: "finance", label: "مالی و تراکنش‌ها", icon: Wallet, perm: "canViewFinance" },
    { id: "programs", label: "صف برنامه‌ها", icon: ListChecks, perm: "canManagePrograms" },
    { id: "checkups", label: "چکاپ‌ها", icon: ClipboardCheck, perm: "canManageCheckups" },
    { id: "articles", label: "مقالات", icon: Newspaper, perm: "canManageArticles" },
    { id: "head_codes", label: "کدهای تحلیلی", icon: Code2, perm: "canManageHeadCodes" },
    { id: "terms", label: "قوانین", icon: ShieldCheck, perm: "canManageTerms" },
    { id: "tickets", label: "تیکت‌ها", icon: MessageSquare, perm: "canManageTickets" },
    { id: "copilot", label: "دستیار هوشمند", icon: Sparkles, perm: "canUseCopilot" },
    { id: "admins", label: "مدیریت ادمین‌ها", icon: ShieldCheck, perm: "canManageAdmins" },
  ];

  // Filter tabs by permission; always show at least the dashboard
  const tabs = allTabs.filter((t) => permissions[t.perm]);

  // If the current tab is not visible (e.g. perms changed), fall back to first available
  useEffect(() => {
    if (permsLoaded && tabs.length > 0 && !tabs.some((t) => t.id === tab)) {
      setTab(tabs[0].id);
    }
  }, [permsLoaded, permissions, tabs, tab]);

  return (
    <div className={`flex flex-col h-full bg-background ${standalone ? "fixed inset-0 z-50" : ""}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-dark">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          <h2 className="font-bold">پنل مدیریت فیتاپ</h2>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={() => setShowSettings(true)} className="rounded-xl gap-1.5 text-xs">
            <SettingsIcon className="w-4 h-4" />
            <span className="hidden sm:inline">تنظیمات سایت</span>
          </Button>
          {standalone ? (
            <Button variant="ghost" size="sm" onClick={handleLogout} className="rounded-xl gap-1.5 text-xs text-red-600 hover:text-red-700 hover:bg-red-50">
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">خروج</span>
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setOverlay(null)} className="rounded-full">
              <X className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-2 border-b overflow-x-auto no-scrollbar glass-dark">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium shrink-0 transition ${
              tab === t.id ? "bg-primary text-primary-foreground glow-gold-sm" : "hover:bg-muted text-muted-foreground"
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}>
            {tab === "dashboard" && <DashboardTab />}
            {tab === "users" && <UsersTab />}
            {tab === "finance" && <FinanceTab />}
            {tab === "programs" && <ProgramsTab />}
            {tab === "checkups" && <CheckupsTab />}
            {tab === "articles" && <ArticlesTab />}
            {tab === "head_codes" && <HeadCodesTab />}
            {tab === "terms" && <TermsTab />}
            {tab === "tickets" && <TicketsTab />}
            {tab === "copilot" && <CopilotTab />}
            {tab === "admins" && <AdminsTab />}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Site Settings Dialog */}
      <SiteSettingsDialog open={showSettings} onClose={() => setShowSettings(false)} />
    </div>
  );
}

/* ============================================================
   ۱. داشبورد — KPIs + نمودارها
   ============================================================ */
function DashboardTab() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/admin/stats");
        const d = await res.json();
        setData(d);
      } catch {} finally { setLoading(false); }
    })();
  }, []);

  if (loading) return <div className="p-4 grid grid-cols-2 lg:grid-cols-4 gap-3">{[1,2,3,4].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>;

  const s = data?.stats;
  const planDistData = (data?.planDistribution || []).map((p: any) => ({
    name: PLAN_LABELS[p.planName as Plan] || p.planName,
    value: p._count,
    color: PLAN_COLORS[p.planName] || "#888",
  }));

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard icon={DollarSign} label="مجموع درآمد" value={`${toPersianDigits(formatToman(s?.totalRevenue || 0))} ت`} color="emerald" />
        <KpiCard icon={Users} label="کل کاربران" value={toPersianDigits(s?.totalUsers || 0)} sub={`ورزشکاران فعال: ${toPersianDigits(s?.activeSubscriptions || 0)}`} color="cyan" />
        <KpiCard icon={ListChecks} label="برنامه‌های فعال" value={toPersianDigits(s?.activeSubscriptions || 0)} sub={`در انتظار: ${toPersianDigits(s?.pendingPrograms || 0)}`} color="amber" />
        <KpiCard icon={Target} label="نرخ تبدیل" value={`${toPersianDigits(s?.conversionRate || 0)}٪`} sub={`${toPersianDigits(s?.usersWithPlan || 0)} کاربر پولی`} color="violet" />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* User growth */}
        <Card className="p-4 glass">
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary" /> روند رشد کاربران</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={data?.userGrowth || []}>
              <defs>
                <linearGradient id="userGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#F4C542" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#F4C542" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-muted/20" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "currentColor" }} className="text-muted-foreground" />
              <YAxis tick={{ fontSize: 11, fill: "currentColor" }} className="text-muted-foreground" />
              <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px" }} />
              <Area type="monotone" dataKey="total" stroke="#F4C542" strokeWidth={2} fill="url(#userGrad)" name="کل کاربران" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Revenue growth */}
        <Card className="p-4 glass">
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4 text-emerald-500" /> روند درآمد (۶ ماه)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data?.revenueGrowth || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-muted/20" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "currentColor" }} className="text-muted-foreground" />
              <YAxis tick={{ fontSize: 11, fill: "currentColor" }} className="text-muted-foreground" tickFormatter={(v) => `${(v / 1000000).toFixed(1)}م`} />
              <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px" }} formatter={(v: any) => `${toPersianDigits(formatToman(v))} ت`} />
              <Bar dataKey="revenue" fill="#10b981" radius={[8, 8, 0, 0]} name="درآمد" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Plan distribution + Revenue by plan */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4 glass">
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2"><Crown className="w-4 h-4 text-primary" /> توزیع کاربران در پلن‌ها</h3>
          {planDistData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={planDistData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {planDistData.map((entry: any, i: number) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px" }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-center text-sm text-muted-foreground py-12">داده‌ای موجود نیست</p>}
        </Card>

        <Card className="p-4 glass">
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4 text-amber-500" /> درآمد بر اساس پلن</h3>
          <div className="space-y-2">
            {(data?.revenueByPlan || []).map((r: any, i: number) => (
              <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-muted/40">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: PLAN_COLORS[r.plan] || "#888" }} />
                  <span className="text-sm font-medium">{PLAN_LABELS[r.plan as Plan] || r.plan}</span>
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm font-stat">{toPersianDigits(formatToman(r._sum.amount || 0))} ت</p>
                  <p className="text-[10px] text-muted-foreground">{toPersianDigits(r._count)} پرداخت</p>
                </div>
              </div>
            ))}
            {(data?.revenueByPlan || []).length === 0 && <p className="text-center text-sm text-muted-foreground py-8">داده‌ای موجود نیست</p>}
          </div>
        </Card>
      </div>

      {/* Recent users */}
      <Card className="p-4 glass">
        <h3 className="font-bold text-sm mb-3">آخرین کاربران ثبت‌نام‌شده</h3>
        <div className="space-y-2">
          {(data?.recentUsers || []).map((u: any) => (
            <div key={u.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-xs font-bold text-primary">{u.name?.[0] || "ک"}</div>
                <div>
                  <p className="text-sm font-medium">{u.name || "بدون نام"}</p>
                  <p className="text-[11px] text-muted-foreground" dir="ltr">{u.mobile}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                {u.planName && <Badge className="text-[9px]" style={{ background: `${PLAN_COLORS[u.planName]}20`, color: PLAN_COLORS[u.planName] }}>{PLAN_LABELS[u.planName as Plan]}</Badge>}
                {u.onboardingDone && <span>✓ آنبوردینگ</span>}
                <span>{new Date(u.createdAt).toLocaleDateString("fa-IR")}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, sub, color }: { icon: any; label: string; value: string; sub?: string; color: string }) {
  const colors: Record<string, string> = {
    emerald: "from-emerald-500/20 to-emerald-500/5 text-emerald-500",
    cyan: "from-cyan-500/20 to-cyan-500/5 text-cyan-500",
    amber: "from-amber-500/20 to-amber-500/5 text-amber-500",
    violet: "from-violet-500/20 to-violet-500/5 text-violet-500",
  };
  return (
    <Card className="p-4 glass relative overflow-hidden">
      <div className={`absolute -left-3 -top-3 w-14 h-14 rounded-full bg-gradient-to-br ${colors[color]} opacity-50`} />
      <div className="relative">
        <Icon className={`w-5 h-5 mb-2 ${colors[color].split(" ").pop()}`} />
        <p className="text-lg font-black font-stat">{value}</p>
        <p className="text-[10px] text-muted-foreground">{label}</p>
        {sub && <p className="text-[9px] text-muted-foreground/70">{sub}</p>}
      </div>
    </Card>
  );
}

/* ============================================================
   ۲. مدیریت کاربران
   ============================================================ */
function UsersTab() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [planFilter, setPlanFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [viewUser, setViewUser] = useState<any>(null);
  const [chargeUser, setChargeUser] = useState<any>(null);
  const pageSize = 15;

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams({ search, page: String(page), pageSize: String(pageSize) });
      if (roleFilter) params.set("role", roleFilter);
      if (planFilter) params.set("plan", planFilter);
      const res = await fetch(`/api/admin/users?${params}`);
      const data = await res.json();
      setUsers(data.users || []);
      setTotalPages(Math.ceil((data.total || 0) / pageSize));
    } catch {} finally { setLoading(false); }
  }

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, roleFilter, planFilter, page]);

  async function action(userId: string, act: string) {
    try {
      const res = await fetch("/api/admin/users", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: act }),
      });
      if (!res.ok) throw new Error();
      toast.success("عملیات انجام شد");
      load();
    } catch { toast.error("خطا"); }
  }

  return (
    <div className="p-4 space-y-3 max-w-7xl mx-auto">
      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="جستجو با شماره یا نام..." className="pr-10 rounded-xl glass" />
        </div>
        <Select value={roleFilter} onValueChange={(v) => { setRoleFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[130px] rounded-xl glass"><SelectValue placeholder="نقش" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه نقش‌ها</SelectItem>
            <SelectItem value="USER">ورزشکار</SelectItem>
            <SelectItem value="ADMIN">ادمین</SelectItem>
          </SelectContent>
        </Select>
        <Select value={planFilter} onValueChange={(v) => { setPlanFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[130px] rounded-xl glass"><SelectValue placeholder="پلن" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه پلن‌ها</SelectItem>
            <SelectItem value="none">بدون پلن</SelectItem>
            <SelectItem value="basic">اقتصادی</SelectItem>
            <SelectItem value="standard">استاندارد</SelectItem>
            <SelectItem value="advanced">پیشرفته</SelectItem>
            <SelectItem value="ultimate">حرفه‌ای</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card className="glass overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/40 text-xs text-muted-foreground">
                <th className="text-right p-3 font-bold">کاربر</th>
                <th className="text-right p-3 font-bold hidden sm:table-cell">نقش</th>
                <th className="text-right p-3 font-bold">پلن</th>
                <th className="text-right p-3 font-bold hidden md:table-cell">کیف پول</th>
                <th className="text-right p-3 font-bold hidden lg:table-cell">ثبت‌نام</th>
                <th className="text-center p-3 font-bold">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [1,2,3].map(i => <tr key={i}><td colSpan={6}><Skeleton className="h-12 m-1" /></td></tr>)
              ) : users.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">کاربری یافت نشد</td></tr>
              ) : users.map((u) => (
                <tr key={u.id} className="border-b last:border-0 hover:bg-muted/20">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-xs font-bold text-primary shrink-0">{u.name?.[0] || "ک"}</div>
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate flex items-center gap-1">
                          {u.name || "بدون نام"}
                          {u.isBlocked && <Ban className="w-3 h-3 text-destructive" />}
                        </p>
                        <p className="text-[10px] text-muted-foreground" dir="ltr">{u.mobile}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 hidden sm:table-cell">
                    {u.role === "ADMIN" ? <Badge className="bg-primary text-[9px]">ادمین</Badge> : <span className="text-xs text-muted-foreground">ورزشکار</span>}
                  </td>
                  <td className="p-3">
                    {u.planName ? (
                      <Badge className="text-[9px]" style={{ background: `${PLAN_COLORS[u.planName]}20`, color: PLAN_COLORS[u.planName] }}>
                        {PLAN_LABELS[u.planName as Plan]}
                      </Badge>
                    ) : <span className="text-xs text-muted-foreground">—</span>}
                  </td>
                  <td className="p-3 hidden md:table-cell font-stat text-xs">{toPersianDigits(formatToman(u.walletBalance || 0))} ت</td>
                  <td className="p-3 hidden lg:table-cell text-[11px] text-muted-foreground">{new Date(u.createdAt).toLocaleDateString("fa-IR")}</td>
                  <td className="p-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setViewUser(u)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition" title="مشاهده پروفایل"><Eye className="w-3.5 h-3.5" /></button>
                      <button onClick={() => setChargeUser(u)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-cyan-500 transition" title="شارژ کیف پول"><Wallet className="w-3.5 h-3.5" /></button>
                      {u.isBlocked ? (
                        <button onClick={() => action(u.id, "unblock")} className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-muted-foreground hover:text-emerald-500 transition" title="رفع مسدودیت"><Check className="w-3.5 h-3.5" /></button>
                      ) : (
                        <button onClick={() => action(u.id, "block")} className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition" title="مسدود"><Ban className="w-3.5 h-3.5" /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-3 border-t">
            <span className="text-xs text-muted-foreground">صفحه {toPersianDigits(page)} از {toPersianDigits(totalPages)}</span>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="rounded-lg h-8"><ChevronRight className="w-4 h-4" /></Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-lg h-8"><ChevronLeft className="w-4 h-4" /></Button>
            </div>
          </div>
        )}
      </Card>

      {/* View user profile */}
      {viewUser && <UserProfileDialog user={viewUser} onClose={() => setViewUser(null)} />}
      {/* Charge wallet */}
      {chargeUser && <ChargeWalletDialog user={chargeUser} onClose={() => setChargeUser(null)} onDone={() => { load(); setChargeUser(null); }} />}
    </div>
  );
}

function UserProfileDialog({ user, onClose }: { user: any; onClose: () => void }) {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/progress`);
        const data = await res.json();
        setProfile(data);
      } catch {} finally { setLoading(false); }
    })();
  }, []);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-md">
        <DialogHeader><DialogTitle>پروفایل {user.name || "ورزشکار"}</DialogTitle></DialogHeader>
        {loading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-2">
              <InfoRow label="شماره موبایل" value={user.mobile} />
              <InfoRow label="نقش" value={user.role === "ADMIN" ? "ادمین" : "ورزشکار"} />
              <InfoRow label="پلن" value={user.planName ? PLAN_LABELS[user.planName as Plan] : "بدون پلن"} />
              <InfoRow label="کیف پول" value={`${toPersianDigits(formatToman(user.walletBalance || 0))} ت`} />
              <InfoRow label="وزن شروع" value={profile?.startWeight ? `${toPersianDigits(profile.startWeight)} kg` : "—"} />
              <InfoRow label="وزن هدف" value={profile?.targetWeight ? `${toPersianDigits(profile.targetWeight)} kg` : "—"} />
            </div>
            {user.hasActiveSubscription && (
              <div className="p-2 rounded-lg bg-emerald-500/10 text-xs text-emerald-500">✓ اشتراک فعال — انقضا: {user.subscriptionEnd ? new Date(user.subscriptionEnd).toLocaleDateString("fa-IR") : "—"}</div>
            )}
          </div>
        )}
        <DialogFooter><Button onClick={onClose} variant="outline" className="rounded-xl">بستن</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ChargeWalletDialog({ user, onClose, onDone }: { user: any; onClose: () => void; onDone: () => void }) {
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [saving, setSaving] = useState(false);

  async function charge() {
    if (!amount || Number(amount) <= 0) return;
    setSaving(true);
    try {
      const res = await fetch("/api/admin/wallet-charge", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, amount: Number(amount), description: desc }),
      });
      if (!res.ok) throw new Error();
      toast.success(`کیف پول ${toPersianDigits(formatToman(Number(amount)))} ت شارژ شد`);
      onDone();
    } catch { toast.error("خطا در شارژ"); } finally { setSaving(false); }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-sm">
        <DialogHeader><DialogTitle>شارژ کیف پول — {user.name || user.mobile}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="p-2 rounded-lg bg-muted/40 text-xs text-center">موجودی فعلی: <b className="font-stat">{toPersianDigits(formatToman(user.walletBalance || 0))} ت</b></div>
          <div>
            <Label className="mb-1 block">مبلغ (تومان)</Label>
            <Input type="number" dir="ltr" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="مثلاً 500000" className="rounded-xl text-center font-stat" />
          </div>
          <div>
            <Label className="mb-1 block">توضیحات (اختیاری)</Label>
            <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="شارژ تستی / پشتیبانی" className="rounded-xl" />
          </div>
          <div className="flex gap-2 flex-wrap">
            {[100000, 500000, 1000000].map(v => (
              <button key={v} onClick={() => setAmount(String(v))} className="text-xs px-3 py-1.5 rounded-lg bg-muted hover:bg-primary hover:text-primary-foreground transition font-stat">
                {toPersianDigits(formatToman(v))}
              </button>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={charge} disabled={!amount || saving} className="rounded-xl">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : "شارژ"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between p-2 rounded-lg bg-muted/40">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}

/* ============================================================
   ۳. مالی و تراکنش‌ها
   ============================================================ */
function FinanceTab() {
  const [txns, setTxns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const pageSize = 20;

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
      if (statusFilter) params.set("status", statusFilter);
      if (search) params.set("search", search);
      const res = await fetch(`/api/admin/transactions?${params}`);
      const data = await res.json();
      setTxns(data.transactions || []);
      setTotalPages(data.totalPages || 1);
    } catch {} finally { setLoading(false); }
  }

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, statusFilter, search]);

  const STATUS_LABELS: Record<string, string> = { success: "موفق", failed: "ناموفق", pending: "در انتظار", cancelled: "لغو شده" };
  const STATUS_COLORS: Record<string, string> = { success: "text-emerald-500", failed: "text-red-500", pending: "text-amber-500", cancelled: "text-muted-foreground" };

  return (
    <div className="p-4 space-y-3 max-w-7xl mx-auto">
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="جستجو با شماره یا نام..." className="pr-10 rounded-xl glass" />
        </div>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[140px] rounded-xl glass"><SelectValue placeholder="وضعیت" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه</SelectItem>
            <SelectItem value="success">موفق</SelectItem>
            <SelectItem value="pending">در انتظار</SelectItem>
            <SelectItem value="failed">ناموفق</SelectItem>
            <SelectItem value="cancelled">لغو شده</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="glass overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/40 text-xs text-muted-foreground">
                <th className="text-right p-3 font-bold">کاربر</th>
                <th className="text-right p-3 font-bold">نوع</th>
                <th className="text-right p-3 font-bold">مبلغ</th>
                <th className="text-right p-3 font-bold hidden md:table-cell">پلن/روش</th>
                <th className="text-right p-3 font-bold">وضعیت</th>
                <th className="text-right p-3 font-bold hidden lg:table-cell">تاریخ</th>
                <th className="text-right p-3 font-bold hidden xl:table-cell">کد پیگیری</th>
              </tr>
            </thead>
            <tbody>
              {loading ? [1,2,3].map(i => <tr key={i}><td colSpan={7}><Skeleton className="h-12 m-1" /></td></tr>) :
               txns.length === 0 ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">تراکنشی یافت نشد</td></tr> :
               txns.map((t) => (
                <tr key={t.id} className="border-b last:border-0 hover:bg-muted/20">
                  <td className="p-3">
                    <p className="text-sm font-medium">{t.userName || "—"}</p>
                    <p className="text-[10px] text-muted-foreground" dir="ltr">{t.userMobile}</p>
                  </td>
                  <td className="p-3">
                    {t.type === "wallet" ? <Badge className="bg-cyan-500/15 text-cyan-500 text-[9px]">کیف پول</Badge> : <Badge className="bg-amber-500/15 text-amber-500 text-[9px]">پلن</Badge>}
                  </td>
                  <td className="p-3 font-stat text-sm font-bold">{t.amount > 0 ? "+" : ""}{toPersianDigits(formatToman(Math.abs(t.amount)))} ت</td>
                  <td className="p-3 hidden md:table-cell text-xs">
                    {t.plan ? <span>{PLAN_LABELS[t.plan as Plan] || t.plan}</span> : ""}
                    <span className="text-muted-foreground"> • {t.paymentMethod === "wallet" ? "کیف پول" : "درگاه"}</span>
                  </td>
                  <td className="p-3"><span className={`text-xs font-bold ${STATUS_COLORS[t.status]}`}>{STATUS_LABELS[t.status]}</span></td>
                  <td className="p-3 hidden lg:table-cell text-[11px] text-muted-foreground">{new Date(t.createdAt).toLocaleString("fa-IR", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</td>
                  <td className="p-3 hidden xl:table-cell text-[10px] font-mono text-muted-foreground" dir="ltr">{t.refId?.slice(0, 12) || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-3 border-t">
            <span className="text-xs text-muted-foreground">صفحه {toPersianDigits(page)} از {toPersianDigits(totalPages)}</span>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="rounded-lg h-8"><ChevronRight className="w-4 h-4" /></Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-lg h-8"><ChevronLeft className="w-4 h-4" /></Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ============================================================
   ۴. صف برنامه‌ها
   ============================================================ */
function ProgramsTab() {
  const [programs, setPrograms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("pending");

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter && statusFilter !== "all") params.set("status", statusFilter);
      const res = await fetch(`/api/admin/programs?${params}`);
      const data = await res.json();
      setPrograms(data.programs || []);
    } catch {} finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [statusFilter]);

  async function updateStatus(programId: string, status: string) {
    try {
      const res = await fetch("/api/admin/programs", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ programId, status }),
      });
      if (!res.ok) throw new Error();
      toast.success("وضعیت برنامه به‌روزرسانی شد");
      load();
    } catch { toast.error("خطا"); }
  }

  const STATUS_LABELS: Record<string, string> = { pending: "در انتظار تولید", generating: "در حال تولید", ready: "آماده", failed: "ناموفق" };
  const STATUS_ICONS: Record<string, any> = { pending: Clock, generating: Loader2, ready: CheckCircle2, failed: AlertTriangle };
  const STATUS_COLORS: Record<string, string> = { pending: "text-amber-500", generating: "text-cyan-500", ready: "text-emerald-500", failed: "text-red-500" };

  return (
    <div className="p-4 space-y-3 max-w-5xl mx-auto">
      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {[
          { id: "pending", label: "در انتظار تولید" },
          { id: "generating", label: "در حال تولید" },
          { id: "ready", label: "آماده" },
          { id: "failed", label: "ناموفق" },
          { id: "all", label: "همه" },
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setStatusFilter(f.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              statusFilter === f.id ? "bg-primary text-primary-foreground glow-gold-sm" : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Program cards */}
      {loading ? (
        <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>
      ) : programs.length === 0 ? (
        <Card className="p-8 text-center glass">
          <ListChecks className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
          <p className="text-sm text-muted-foreground">برنامه‌ای در این وضعیت موجود نیست</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {programs.map((p) => {
            const StatusIcon = STATUS_ICONS[p.status] || Clock;
            const isVip = p.plan === "ultimate";
            return (
              <Card key={p.id} className={`p-4 glass ${isVip ? "border-violet-500/30" : ""}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${PLAN_COLORS[p.plan]}20` }}>
                      <Crown className="w-5 h-5" style={{ color: PLAN_COLORS[p.plan] }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="font-bold text-sm truncate">{p.userName || "—"}</p>
                        <Badge className="text-[9px]" style={{ background: `${PLAN_COLORS[p.plan]}20`, color: PLAN_COLORS[p.plan] }}>{PLAN_LABELS[p.plan as Plan] || p.plan}</Badge>
                        {isVip && <Badge className="bg-violet-500/15 text-violet-500 text-[9px]">VIP</Badge>}
                      </div>
                      <p className="text-[11px] text-muted-foreground" dir="ltr">{p.userMobile}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <StatusIcon className={`w-3.5 h-3.5 ${STATUS_COLORS[p.status]} ${p.status === "generating" ? "animate-spin" : ""}`} />
                        <span className={`text-xs font-bold ${STATUS_COLORS[p.status]}`}>{STATUS_LABELS[p.status]}</span>
                        <span className="text-[10px] text-muted-foreground">• {new Date(p.createdAt).toLocaleString("fa-IR", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {p.status === "pending" && (
                      <Button size="sm" variant="outline" className="rounded-lg text-xs h-8" onClick={() => updateStatus(p.id, "generating")}>
                        شروع تولید
                      </Button>
                    )}
                    {p.status === "generating" && (
                      <Button size="sm" className="rounded-lg text-xs h-8 bg-emerald-600 hover:bg-emerald-700" onClick={() => updateStatus(p.id, "ready")}>
                        <Check className="w-3.5 h-3.5" /> تایید
                      </Button>
                    )}
                    {p.status === "pending" && (
                      <Button size="sm" variant="ghost" className="rounded-lg text-xs h-8 text-destructive" onClick={() => updateStatus(p.id, "failed")}>
                        رد
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   ۵. مقالات — Article CMS
   ============================================================ */
interface ArticleRow {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  status: "draft" | "published";
  coverImage: string;
  views: number;
  createdAt: string;
  updatedAt: string;
  // SEO fields
  seoTitle?: string;
  seoDescription?: string;
  metaKeywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  robots?: string;
  readingMinutes?: number;
}

/* ============================================================
   ۴.۵. چکاپ‌ها — بررسی مربی / ادمین
   ============================================================ */
function CheckupsTab() {
  const [checkups, setCheckups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [activeCheckup, setActiveCheckup] = useState<any | null>(null);
  const [coachNotes, setCoachNotes] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== "all") params.set("status", statusFilter);
      const res = await fetch(`/api/admin/checkup?${params}`);
      const data = await res.json();
      setCheckups(data.checkups || []);
    } catch {
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  function openReview(c: any) {
    setActiveCheckup(c);
    setCoachNotes(c.coachNotes ?? "");
    setReviewOpen(true);
  }

  async function submitReview(markCompleted: boolean) {
    if (!activeCheckup) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/checkup/${activeCheckup.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          coachNotes,
          status: markCompleted ? "completed" : "pending_coach",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast.success(markCompleted ? "چکاپ تأیید شد و به ورزشکار اطلاع داده شد." : "یادداشت ذخیره شد.");
      setReviewOpen(false);
      setActiveCheckup(null);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ذخیره");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <ClipboardCheck className="w-5 h-5 text-primary" />
          <h3 className="font-bold">چکاپ‌های دوره‌ای ورزشکاران</h3>
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44 rounded-xl">
            <SelectValue placeholder="همه وضعیت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="pending_coach">در انتظار مربی</SelectItem>
            <SelectItem value="completed">تأیید شده</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
      ) : checkups.length === 0 ? (
        <div className="rounded-2xl border border-dashed p-8 text-center text-muted-foreground">
          <ClipboardCheck className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">چکاپی یافت نشد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {checkups.map((c) => (
            <Card key={c.id} className="p-4 glass">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-bold text-sm flex items-center gap-1.5">
                    <span className="text-[11px] px-2 py-0.5 rounded-full bg-primary/15 text-primary">فاز {toPersianDigits(c.phaseNumber)}</span>
                    {c.isFinalCheckup && <span className="text-[10px] text-amber-600">نهایی</span>}
                    {c.user?.name || c.user?.mobile}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {new Date(c.createdAt).toLocaleString("fa-IR", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
                {c.status === "completed" ? (
                  <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/20">تأیید شده</Badge>
                ) : (
                  <Badge className="bg-amber-500/15 text-amber-600 border-amber-500/20">در انتظار</Badge>
                )}
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[11px] mb-2">
                <div className="rounded-lg bg-muted/40 p-1.5">
                  <p className="text-muted-foreground">وزن</p>
                  <p className="font-bold">{toPersianDigits(c.weight)} kg</p>
                </div>
                {c.bodyFatPercent != null && (
                  <div className="rounded-lg bg-muted/40 p-1.5">
                    <p className="text-muted-foreground">چربی</p>
                    <p className="font-bold">{toPersianDigits(c.bodyFatPercent)}٪</p>
                  </div>
                )}
                {c.aiAnalysis && (
                  <div className="rounded-lg bg-primary/10 p-1.5">
                    <p className="text-muted-foreground">امتیاز</p>
                    <p className="font-bold text-primary">{toPersianDigits(c.aiAnalysis.bodyScore)}/۱۰۰</p>
                  </div>
                )}
              </div>
              {c.notes && (
                <p className="text-[11px] text-muted-foreground bg-muted/30 rounded p-2 mb-2 line-clamp-2">{c.notes}</p>
              )}
              <Button size="sm" variant="outline" className="w-full rounded-xl text-xs" onClick={() => openReview(c)}>
                <Eye className="w-3.5 h-3.5" /> بررسی و یادداشت مربی
              </Button>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent dir="rtl" className="max-w-lg max-h-[90vh] overflow-y-auto bg-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-slate-900">
              <ClipboardCheck className="w-5 h-5 text-orange-500" />
              بررسی چکاپ فاز {activeCheckup ? toPersianDigits(activeCheckup.phaseNumber) : ""}
            </DialogTitle>
          </DialogHeader>
          {activeCheckup && (
            <div className="space-y-3">
              <div className="rounded-xl bg-slate-50 p-3 text-sm">
                <p className="text-xs text-slate-500 mb-1">ورزشکار</p>
                <p className="font-bold">{activeCheckup.user?.name || "—"} • {activeCheckup.user?.mobile}</p>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">وزن</p><p className="font-bold">{toPersianDigits(activeCheckup.weight)} kg</p></div>
                {activeCheckup.bodyFatPercent != null && <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">چربی</p><p className="font-bold">{toPersianDigits(activeCheckup.bodyFatPercent)}٪</p></div>}
                {activeCheckup.leanBodyMass != null && <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">LBM</p><p className="font-bold">{toPersianDigits(activeCheckup.leanBodyMass)} kg</p></div>}
                {activeCheckup.waistMeasurement != null && <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">کمر</p><p className="font-bold">{toPersianDigits(activeCheckup.waistMeasurement)}</p></div>}
                {activeCheckup.armMeasurement != null && <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">بازو</p><p className="font-bold">{toPersianDigits(activeCheckup.armMeasurement)}</p></div>}
                {activeCheckup.chestMeasurement != null && <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">سینه</p><p className="font-bold">{toPersianDigits(activeCheckup.chestMeasurement)}</p></div>}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">پیروی تمرین</p><p className="font-bold">{toPersianDigits(activeCheckup.workoutAdherence)}/۵</p></div>
                <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">پیروی رژیم</p><p className="font-bold">{toPersianDigits(activeCheckup.dietAdherence)}/۵</p></div>
                <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">کیفیت خواب</p><p className="font-bold">{toPersianDigits(activeCheckup.sleepQuality)}/۵</p></div>
                <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">خستگی</p><p className="font-bold">{toPersianDigits(activeCheckup.fatigueLevel)}/۵</p></div>
              </div>
              {activeCheckup.notes && (
                <div className="rounded-xl bg-amber-50 p-3 text-xs border border-amber-200">
                  <p className="text-amber-700 font-bold mb-1">یادداشت ورزشکار:</p>
                  <p className="text-slate-700">{activeCheckup.notes}</p>
                </div>
              )}
              {activeCheckup.aiAnalysis && (
                <div className="rounded-xl bg-white p-3 border-2 border-orange-200">
                  <p className="text-xs font-bold text-slate-900 mb-1 flex items-center gap-1">
                    <Brain className="w-3.5 h-3.5 text-orange-500" /> تحلیل هوش مصنوعی (امتیاز: {toPersianDigits(activeCheckup.aiAnalysis.bodyScore)}/۱۰۰)
                  </p>
                  <p className="text-[11px] text-slate-700 leading-relaxed">{activeCheckup.aiAnalysis.analysis}</p>
                  {activeCheckup.aiAnalysis.recommendations?.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {activeCheckup.aiAnalysis.recommendations.map((r: string, i: number) => (
                        <li key={i} className="text-[11px] text-slate-600">• {r}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
              <div>
                <Label className="mb-1.5 block text-sm text-slate-700">یادداشت مربی</Label>
                <Textarea
                  value={coachNotes}
                  onChange={(e) => setCoachNotes(e.target.value)}
                  placeholder="بازخورد، توصیه‌ها، یا تأیید چکاپ..."
                  rows={4}
                  className="rounded-xl"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setReviewOpen(false)} disabled={saving}>بستن</Button>
            <Button
              variant="outline"
              onClick={() => submitReview(false)}
              disabled={saving}
              className="rounded-xl"
            >
              ذخیره یادداشت
            </Button>
            <Button
              onClick={() => submitReview(true)}
              disabled={saving}
              className="rounded-xl text-white"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              تأیید و اطلاع به ورزشکار
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ArticlesTab() {
  const [articles, setArticles] = useState<ArticleRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editArticle, setEditArticle] = useState<ArticleRow | null>(null);

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams({ pageSize: "50" });
      if (statusFilter !== "all") params.set("status", statusFilter);
      if (categoryFilter !== "all") params.set("category", categoryFilter);
      if (search) params.set("search", search);
      const res = await fetch(`/api/articles?${params}`);
      const data = await res.json();
      setArticles(data.articles || []);
    } catch {} finally { setLoading(false); }
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, statusFilter, categoryFilter]);

  async function deleteArticle(article: ArticleRow) {
    if (!confirm(`حذف مقاله «${article.title}»؟`)) return;
    try {
      const res = await fetch(`/api/articles/${article.slug}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      toast.success("مقاله حذف شد");
      load();
    } catch { toast.error("خطا در حذف"); }
  }

  async function toggleStatus(article: ArticleRow) {
    const newStatus = article.status === "published" ? "draft" : "published";
    try {
      const res = await fetch(`/api/articles/${article.slug}`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) throw new Error();
      toast.success(newStatus === "published" ? "مقاله منتشر شد" : "مقاله پیش‌نویس شد");
      load();
    } catch { toast.error("خطا"); }
  }

  return (
    <div className="p-4 space-y-3 max-w-7xl mx-auto">
      {/* Filters + create */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="جستجوی عنوان یا تگ..." className="pr-10 rounded-xl glass" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[120px] rounded-xl glass"><SelectValue placeholder="وضعیت" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="published">منتشر شده</SelectItem>
            <SelectItem value="draft">پیش‌نویس</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[120px] rounded-xl glass"><SelectValue placeholder="دسته" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه دسته‌ها</SelectItem>
            {ARTICLE_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={() => { setEditArticle(null); setEditorOpen(true); }} className="rounded-xl gap-1.5 bg-primary text-primary-foreground glow-gold-sm">
          <Plus className="w-4 h-4" /> مقاله جدید
        </Button>
      </div>

      {/* Table */}
      <Card className="glass overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/40 text-xs text-muted-foreground">
                <th className="text-right p-3 font-bold">عنوان</th>
                <th className="text-right p-3 font-bold hidden sm:table-cell">دسته</th>
                <th className="text-right p-3 font-bold">وضعیت</th>
                <th className="text-right p-3 font-bold hidden md:table-cell">بازدید</th>
                <th className="text-right p-3 font-bold hidden lg:table-cell">تاریخ</th>
                <th className="text-center p-3 font-bold">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [1, 2, 3].map((i) => <tr key={i}><td colSpan={6}><Skeleton className="h-12 m-1" /></td></tr>)
              ) : articles.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">
                  <Newspaper className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
                  مقاله‌ای یافت نشد — اولین مقاله را بسازید!
                </td></tr>
              ) : articles.map((a) => (
                <tr key={a.id} className="border-b last:border-0 hover:bg-muted/20">
                  <td className="p-3">
                    <p className="font-medium text-sm truncate max-w-xs">{a.title}</p>
                    <p className="text-[10px] text-muted-foreground font-mono" dir="ltr">/{a.slug}</p>
                  </td>
                  <td className="p-3 hidden sm:table-cell">
                    <Badge className="text-[9px] bg-primary/15 text-primary">{articleCategoryLabel(a.category)}</Badge>
                  </td>
                  <td className="p-3">
                    <button onClick={() => toggleStatus(a)} className="inline-flex items-center gap-1.5" title="تغییر وضعیت">
                      <span className={`inline-block w-2 h-2 rounded-full ${a.status === "published" ? "bg-emerald-500" : "bg-amber-500"}`} />
                      <span className={`text-xs font-bold ${a.status === "published" ? "text-emerald-500" : "text-amber-500"}`}>
                        {a.status === "published" ? "منتشر شده" : "پیش‌نویس"}
                      </span>
                    </button>
                  </td>
                  <td className="p-3 hidden md:table-cell font-stat text-xs">{toPersianDigits(a.views)}</td>
                  <td className="p-3 hidden lg:table-cell text-[11px] text-muted-foreground">{new Date(a.createdAt).toLocaleDateString("fa-IR")}</td>
                  <td className="p-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => { setEditArticle(a); setEditorOpen(true); }} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition" title="ویرایش">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deleteArticle(a)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition" title="حذف">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {editorOpen && (
        <ArticleEditorDialog
          article={editArticle}
          onClose={() => { setEditorOpen(false); setEditArticle(null); }}
          onSaved={() => { setEditorOpen(false); setEditArticle(null); load(); }}
        />
      )}
    </div>
  );
}

/* ---- Article Editor Dialog — Rich Markdown + SEO ---- */
function ArticleEditorDialog({ article, onClose, onSaved }: { article: ArticleRow | null; onClose: () => void; onSaved: () => void }) {
  const [title, setTitle] = useState(article?.title || "");
  const [slug, setSlug] = useState(article?.slug || "");
  const [excerpt, setExcerpt] = useState(article?.excerpt || "");
  const [content, setContent] = useState(article?.content || "");
  const [category, setCategory] = useState(article?.category || "general");
  const [tags, setTags] = useState(article?.tags || "");
  const [coverImage, setCoverImage] = useState(article?.coverImage || "");
  const [published, setPublished] = useState(article?.status === "published");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showSeo, setShowSeo] = useState(false);
  // SEO state
  const [seoTitle, setSeoTitle] = useState(article?.seoTitle || "");
  const [seoDescription, setSeoDescription] = useState(article?.seoDescription || "");
  const [metaKeywords, setMetaKeywords] = useState(article?.metaKeywords || "");
  const [canonicalUrl, setCanonicalUrl] = useState(article?.canonicalUrl || "");
  const [ogImage, setOgImage] = useState(article?.ogImage || "");
  const [robots, setRobots] = useState(article?.robots || "index,follow");
  const contentRef = useRef<HTMLTextAreaElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const inlineImageInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate slug from title
  useEffect(() => {
    if (!article && title) {
      setSlug(title.trim().toLowerCase().replace(/\s+/g, "-").slice(0, 80));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title]);

  /** Insert markdown syntax at cursor position / wrap selection */
  function insertMarkdown(before: string, after: string = "", placeholder: string = "") {
    const el = contentRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const selected = content.substring(start, end) || placeholder;
    const newText = `${before}${selected}${after}`;
    const newContent = content.substring(0, start) + newText + content.substring(end);
    setContent(newContent);
    setTimeout(() => {
      el.focus();
      el.selectionStart = start + before.length;
      el.selectionEnd = start + before.length + selected.length;
    }, 0);
  }

  /** Insert a full line prefix (headings, lists) */
  function insertLinePrefix(prefix: string, placeholder: string = "متن...") {
    const el = contentRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const lineStart = content.lastIndexOf("\n", start - 1) + 1;
    const lineEnd = content.indexOf("\n", start);
    const actualLineEnd = lineEnd === -1 ? content.length : lineEnd;
    const currentLine = content.substring(lineStart, actualLineEnd) || placeholder;
    const newLine = `${prefix}${currentLine}`;
    const newContent = content.substring(0, lineStart) + newLine + content.substring(actualLineEnd);
    setContent(newContent);
    setTimeout(() => {
      el.focus();
      el.selectionStart = lineStart + prefix.length;
      el.selectionEnd = lineStart + prefix.length + currentLine.length;
    }, 0);
  }

  /** Upload an image file (cover or inline) and return its URL */
  async function uploadImage(file: File): Promise<string | null> {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const res = await fetch("/api/articles/upload-image", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در آپلود");
      return data.url as string;
    } catch (e: any) {
      toast.error(e.message || "خطا در آپلود تصویر");
      return null;
    } finally {
      setUploading(false);
    }
  }

  async function handleCoverUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadImage(file);
    if (url) {
      setCoverImage(url);
      toast.success("کاور مقاله آپلود شد ✓");
    }
    e.target.value = "";
  }

  async function handleInlineImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadImage(file);
    if (url) {
      // insert markdown image at cursor
      insertMarkdown(`\n![`, `](${url})\n`, "توضیح تصویر");
      toast.success("تصویر در متن درج شد ✓");
    }
    e.target.value = "";
  }

  async function save() {
    if (!title.trim() || title.trim().length < 3) {
      toast.error("عنوان حداقل ۳ کاراکتر باید باشد");
      return;
    }
    if (!content.trim() || content.trim().length < 10) {
      toast.error("محتوای مقاله را کامل کنید");
      return;
    }
    setSaving(true);
    try {
      const body = {
        title: title.trim(),
        slug: slug.trim(),
        excerpt: excerpt.trim(),
        content,
        category,
        tags: tags.trim(),
        coverImage: coverImage.trim(),
        status: published ? "published" : "draft",
        seoTitle: seoTitle.trim(),
        seoDescription: seoDescription.trim(),
        metaKeywords: metaKeywords.trim(),
        canonicalUrl: canonicalUrl.trim(),
        ogImage: (ogImage.trim() || coverImage.trim()),
        robots,
      };
      const url = article ? `/api/articles/${article.slug}` : "/api/articles";
      const method = article ? "PUT" : "POST";
      const res = await fetch(url, {
        method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "خطا در ذخیره");
      }
      toast.success(article ? "مقاله به‌روزرسانی شد" : "مقاله ساخته شد");
      onSaved();
    } catch (e: any) {
      toast.error(e.message || "خطا");
    } finally { setSaving(false); }
  }

  // Toolbar buttons config
  const toolbar: { icon: any; label: string; action: () => void; }[] = [
    { icon: Heading1, label: "تیتر ۱", action: () => insertLinePrefix("# ", "تیتر اصلی") },
    { icon: Heading2, label: "تیتر ۲", action: () => insertLinePrefix("## ", "تیتر فرعی") },
    { icon: Heading3, label: "تیتر ۳", action: () => insertLinePrefix("### ", "تیتر کوچک") },
    { icon: Bold, label: "ضخیم", action: () => insertMarkdown("**", "**", "متن ضخیم") },
    { icon: Italic, label: "کج", action: () => insertMarkdown("*", "*", "متن کج") },
    { icon: List, label: "لیست نقطه‌ای", action: () => insertLinePrefix("- ", "مورد لیست") },
    { icon: ListOrdered, label: "لیست شماره‌دار", action: () => insertLinePrefix("1. ", "مورد لیست") },
    { icon: Quote, label: "نقل قول", action: () => insertLinePrefix("> ", "نقل قول") },
    { icon: Link2, label: "لینک", action: () => insertMarkdown("[", "](https://)", "متن لینک") },
    { icon: Code2, label: "بلاک کد", action: () => insertMarkdown("\n```javascript\n", "\n```\n", "کد شما") },
  ];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-4xl max-h-[92vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Newspaper className="w-5 h-5 text-primary" />
            {article ? "ویرایش مقاله" : "مقاله جدید"}
          </DialogTitle>
        </DialogHeader>

        {/* Title + Slug */}
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>عنوان مقاله *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: ۵ نکته طلایی برای عضله‌سازی" className="rounded-xl" />
          </div>
          <div className="space-y-1.5">
            <Label>شناسه URL (slug)</Label>
            <Input dir="ltr" value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="auto-generated" className="rounded-xl font-mono text-sm" />
          </div>
        </div>

        {/* Excerpt */}
        <div className="space-y-1.5">
          <Label>خلاصه کوتاه</Label>
          <Textarea value={excerpt} onChange={(e) => setExcerpt(e.target.value)} rows={2} placeholder="توضیح یک‌خطی برای پیش‌نمایش و سئو" className="rounded-xl resize-none" />
        </div>

        {/* Category + Tags */}
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>دسته‌بندی</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {ARTICLE_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>تگ‌ها (با ویرگول)</Label>
            <Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="تغذیه,تمرین,مبتدی" className="rounded-xl" />
          </div>
        </div>

        {/* Cover Image Upload */}
        <div className="space-y-1.5">
          <Label>تصویر کاور</Label>
          <div className="flex items-center gap-2">
            <Input dir="ltr" value={coverImage} onChange={(e) => setCoverImage(e.target.value)} placeholder="/uploads/articles/... یا https://..." className="rounded-xl text-xs flex-1" />
            <input ref={coverInputRef} type="file" accept="image/*" onChange={handleCoverUpload} className="hidden" />
            <Button type="button" variant="outline" size="sm" onClick={() => coverInputRef.current?.click()} disabled={uploading} className="rounded-xl gap-1.5 shrink-0">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              آپلود
            </Button>
          </div>
          {coverImage && (
            <div className="mt-2 rounded-xl overflow-hidden border border-border max-h-40">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={coverImage} alt="cover" className="w-full h-40 object-cover" />
            </div>
          )}
        </div>

        {/* Rich Markdown Editor */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <Label>محتوا (Markdown غنی)</Label>
            <input ref={inlineImageInputRef} type="file" accept="image/*" onChange={handleInlineImageUpload} className="hidden" />
            <Button type="button" variant="outline" size="sm" onClick={() => inlineImageInputRef.current?.click()} disabled={uploading} className="rounded-lg text-xs gap-1 h-7">
              {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ImageIcon className="w-3.5 h-3.5" />}
              درج تصویر در متن
            </Button>
          </div>

          {/* Toolbar */}
          <div className="flex items-center gap-1 flex-wrap p-2 rounded-t-xl border border-b-0 border-border bg-muted/40">
            {toolbar.map((b, i) => (
              <button
                key={i}
                type="button"
                onClick={b.action}
                title={b.label}
                className="w-8 h-8 rounded-lg hover:bg-primary/15 hover:text-primary flex items-center justify-center transition"
              >
                <b.icon className="w-4 h-4" />
              </button>
            ))}
            <div className="w-px h-6 bg-border mx-1" />
            <span className="text-[10px] text-muted-foreground px-2">Markdown</span>
          </div>
          <Textarea
            ref={contentRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={14}
            placeholder={"# عنوان مقاله\n\nمقدمه مقاله...\n\n## بخش اول\n\n- مورد ۱\n- مورد ۲\n\n![توضیح](image-url)\n\n> نقل قول مهم"}
            className="rounded-t-none rounded-xl resize-y font-mono text-sm leading-relaxed"
            dir="rtl"
          />
          <p className="text-[10px] text-muted-foreground">پشتیبانی از: تیتر (#, ##, ###)، ضخیم (**)، کج (*)، لیست (-، ۱.)، نقل قول ({">"})، لینک، تصویر، بلاک کد</p>
        </div>

        {/* SEO Section (collapsible) */}
        <div className="rounded-xl border border-orange-200 overflow-hidden">
          <button
            type="button"
            onClick={() => setShowSeo(!showSeo)}
            className="w-full flex items-center justify-between p-3 bg-orange-50/50 hover:bg-orange-50 transition"
          >
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-orange-500" />
              <span className="font-bold text-sm text-slate-800">تنظیمات سئو (SEO)</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 text-orange-600">حرفه‌ای</span>
            </div>
            <ChevronLeft className={`w-4 h-4 text-slate-400 transition-transform ${showSeo ? "-rotate-90" : ""}`} />
          </button>
          {showSeo && (
            <div className="p-3 space-y-3 bg-white">
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">عنوان سئو (SEO Title) — {seoTitle.length}/۶۰</Label>
                  <Input value={seoTitle} onChange={(e) => setSeoTitle(e.target.value.slice(0, 60))} placeholder="عنوان برای موتور جستجو" className="rounded-xl text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">کلمات کلیدی (Meta Keywords)</Label>
                  <Input value={metaKeywords} onChange={(e) => setMetaKeywords(e.target.value)} placeholder="کلمه1, کلمه2, کلمه3" className="rounded-xl text-sm" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">توضیحات متا (Meta Description) — {seoDescription.length}/۱۶۰</Label>
                <Textarea value={seoDescription} onChange={(e) => setSeoDescription(e.target.value.slice(0, 160))} rows={2} placeholder="توضیح کوتاه برای نمایش در نتایج جستجو" className="rounded-xl resize-none text-sm" />
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Canonical URL (اختیاری)</Label>
                  <Input dir="ltr" value={canonicalUrl} onChange={(e) => setCanonicalUrl(e.target.value)} placeholder="https://fittup.ir/..." className="rounded-xl text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">تصویر Open Graph (OG Image)</Label>
                  <Input dir="ltr" value={ogImage} onChange={(e) => setOgImage(e.target.value)} placeholder="خالی = تصویر کاور" className="rounded-xl text-sm" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">دستورالعمل ربات‌ها (Robots)</Label>
                <Select value={robots} onValueChange={setRobots}>
                  <SelectTrigger className="rounded-xl text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="index,follow">index,follow (پیش‌فرض — ایندکس شود)</SelectItem>
                    <SelectItem value="noindex,follow">noindex,follow (ایندکس نشود)</SelectItem>
                    <SelectItem value="index,nofollow">index,nofollow (لینک‌ها دنبال نشود)</SelectItem>
                    <SelectItem value="noindex,nofollow">noindex,nofollow (کاملاً مخفی)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="text-[10px] text-muted-foreground bg-orange-50/50 rounded-lg p-2">
                💡 اگر عنوان سئو خالی باشد، از عنوان مقاله استفاده می‌شود. اگر توضیحات متا خالی باشد، از خلاصه استفاده می‌شود. زمان مطالعه به‌صورت خودکار از روی متن محاسبه می‌شود.
              </div>
            </div>
          )}
        </div>

        {/* Publish toggle */}
        <div className="flex items-center justify-between p-3 rounded-xl glass">
          <div>
            <Label className="text-sm font-medium">انتشار مقاله</Label>
            <p className="text-[11px] text-muted-foreground">در صورت خاموش بودن، به‌صورت پیش‌نویس ذخیره می‌شود</p>
          </div>
          <Switch checked={published} onCheckedChange={setPublished} />
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={save} disabled={saving || uploading} className="rounded-xl gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            ذخیره مقاله
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   ۶. دستیار هوشمند — Admin AI Copilot
   ============================================================ */
interface CopilotMessage {
  role: "user" | "assistant";
  content: string;
}

function CopilotTab() {
  const [messages, setMessages] = useState<CopilotMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [stats, setStats] = useState<{ totalUsers: number; totalRevenue: number; activeSubs: number; pendingPrograms: number } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial greeting + load stats
    (async () => {
      try {
        const res = await fetch("/api/admin/stats");
        const d = await res.json();
        const s = d.stats;
        if (s) {
          setStats({
            totalUsers: s.totalUsers || 0,
            totalRevenue: s.totalRevenue || 0,
            activeSubs: s.activeSubscriptions || 0,
            pendingPrograms: s.pendingPrograms || 0,
          });
          setMessages([{
            role: "assistant",
            content: `سلام مدیر عزیز 👋 من دستیار هوشمند پنل فیتاپ هستم.\n\nآمار فعلی سایت شما:\n• 👥 ${toPersianDigits(s.totalUsers || 0)} کاربر\n• 💰 ${toPersianDigits(formatToman(s.totalRevenue || 0))} تومان درآمد\n• 🔥 ${toPersianDigits(s.activeSubscriptions || 0)} اشتراک فعال\n• ⏳ ${toPersianDigits(s.pendingPrograms || 0)} برنامه در انتظار تولید\n\nچطور می‌تونم کمکتون کنم؟ می‌تونم در تحلیل آمار، پیشنهاد استراتژی، نوشتن مقالات یا پاسخ به سوالات فنی کمک کنم.`,
          }]);
        }
      } catch {
        setMessages([{ role: "assistant", content: "سلام! دستیار هوشمند آماده پاسخگویی است." }]);
      }
    })();
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, sending]);

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || sending) return;
    setInput("");
    const nextMessages = [...messages, { role: "user" as const, content: msg }];
    setMessages(nextMessages);
    setSending(true);
    try {
      const res = await fetch("/api/admin/copilot", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msg,
          history: nextMessages.slice(0, -1).map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      if (data.context) setStats(data.context);
      setMessages([...nextMessages, { role: "assistant", content: data.reply || "پاسخی دریافت نشد." }]);
    } catch {
      toast.error("خطا در ارتباط با دستیار");
      setMessages([...nextMessages, { role: "assistant", content: "متأسفم، در ارتباط با سرور خطایی رخ داد. دوباره تلاش کنید." }]);
    } finally { setSending(false); }
  }

  const QUICK_PROMPTS = [
    "تحلیل کلی وضعیت سایت",
    "چطور می‌تونم نرخ تبدیل رو افزایش بدم؟",
    "یک مقاله کوتاه درباره اهمیت پروتئین بنویس",
    "کدام پلن بیشترین درآمد رو داشته؟",
    "پیشنهاد استراتژی برای نگه‌داشت کاربران",
  ];

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4" style={{ minHeight: "calc(95vh - 130px)" }}>
      {/* Stats banner */}
      {stats && (
        <Card className="p-3 glass-gold mb-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            <div>
              <p className="text-[10px] text-muted-foreground">کاربران</p>
              <p className="font-stat font-bold text-sm">{toPersianDigits(stats.totalUsers)}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">درآمد (تومان)</p>
              <p className="font-stat font-bold text-sm">{toPersianDigits(formatToman(stats.totalRevenue))}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">اشتراک فعال</p>
              <p className="font-stat font-bold text-sm">{toPersianDigits(stats.activeSubs)}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">در انتظار تولید</p>
              <p className="font-stat font-bold text-sm">{toPersianDigits(stats.pendingPrograms)}</p>
            </div>
          </div>
        </Card>
      )}

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pb-3">
        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex gap-2 ${m.role === "user" ? "flex-row-reverse" : "flex-row"}`}
          >
            <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
              m.role === "user" ? "bg-primary/15 text-primary" : "bg-gradient-to-br from-amber-500/20 to-yellow-500/10 text-amber-500 glow-gold-sm"
            }`}>
              {m.role === "user" ? <Shield className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div className={`max-w-[80%] p-3 rounded-2xl text-sm whitespace-pre-wrap leading-relaxed ${
              m.role === "user" ? "bg-primary text-primary-foreground rounded-tl-sm" : "glass rounded-tr-sm"
            }`}>
              {m.content}
            </div>
          </motion.div>
        ))}
        {sending && (
          <div className="flex gap-2 flex-row">
            <div className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-br from-amber-500/20 to-yellow-500/10 text-amber-500">
              <Bot className="w-4 h-4" />
            </div>
            <div className="glass p-3 rounded-2xl rounded-tr-sm">
              <div className="flex gap-1">
                <span className="typing-dot w-2 h-2 rounded-full bg-amber-500 inline-block" />
                <span className="typing-dot w-2 h-2 rounded-full bg-amber-500 inline-block" />
                <span className="typing-dot w-2 h-2 rounded-full bg-amber-500 inline-block" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick prompts */}
      {messages.length <= 1 && (
        <div className="flex gap-2 flex-wrap mb-2">
          {QUICK_PROMPTS.map((p, i) => (
            <button key={i} onClick={() => send(p)} className="text-xs px-3 py-1.5 rounded-xl glass hover:bg-primary hover:text-primary-foreground transition">
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2 items-end">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="سوال یا درخواست خود را بنویسید... (Enter برای ارسال)"
          rows={1}
          className="rounded-xl resize-none min-h-[44px] max-h-32 glass"
        />
        <Button onClick={() => send()} disabled={!input.trim() || sending} className="rounded-xl h-11 w-11 p-0 bg-primary text-primary-foreground glow-gold-sm shrink-0">
          {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </div>
    </div>
  );
}

/* ============================================================
   ۶.۴. کدهای تحلیلی — Analytics / Search Console / Pixels
   ============================================================ */
interface HeadCodeRow {
  id: string;
  name: string;
  type: string;
  code: string;
  placement: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

function HeadCodesTab() {
  const [codes, setCodes] = useState<HeadCodeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editCode, setEditCode] = useState<HeadCodeRow | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/head-codes");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setCodes(data.codes || []);
    } catch {
      toast.error("خطا در بارگذاری کدها");
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  async function toggleActive(c: HeadCodeRow) {
    try {
      const res = await fetch(`/api/admin/head-codes/${c.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !c.isActive }),
      });
      if (!res.ok) throw new Error();
      toast.success(c.isActive ? "کد غیرفعال شد" : "کد فعال شد");
      load();
    } catch { toast.error("خطا در تغییر وضعیت"); }
  }

  async function remove(c: HeadCodeRow) {
    if (!confirm(`حذف «${c.name}»؟ این عمل قابل بازگشت نیست.`)) return;
    try {
      const res = await fetch(`/api/admin/head-codes/${c.id}`, { method: "DELETE" });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "خطا در حذف");
      }
      toast.success("کد حذف شد");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در حذف");
    }
  }

  const activeCount = codes.filter((c) => c.isActive).length;

  return (
    <div className="p-4 space-y-4 max-w-5xl mx-auto">
      {/* Summary card */}
      <Card className="p-5 glass">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 text-amber-500 flex items-center justify-center shrink-0">
              <Code2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground font-bold uppercase tracking-wider mb-0.5">کدهای تحلیلی و ردیاب</p>
              <h3 className="font-black text-base">تزریق کد به صفحات سایت</h3>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                <Badge className="text-[10px] bg-emerald-500/15 text-emerald-500">{toPersianDigits(activeCount)} فعال</Badge>
                <Badge className="text-[10px] bg-muted text-foreground">{toPersianDigits(codes.length)} کل</Badge>
                <span>Google Analytics • Search Console • Meta Pixel</span>
              </p>
            </div>
          </div>
          <Button
            onClick={() => { setEditCode(null); setEditorOpen(true); }}
            className="rounded-xl gap-1.5 bg-primary text-primary-foreground glow-gold-sm"
          >
            <Plus className="w-4 h-4" /> کد جدید
          </Button>
        </div>
      </Card>

      {/* Codes table */}
      <Card className="glass overflow-hidden">
        <div className="p-3 border-b bg-muted/40">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <Code2 className="w-4 h-4 text-primary" />
            همه کدها ({toPersianDigits(codes.length)})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30 text-xs text-muted-foreground">
                <th className="text-right p-3 font-bold">نام</th>
                <th className="text-right p-3 font-bold">نوع</th>
                <th className="text-right p-3 font-bold hidden sm:table-cell">محل تزریق</th>
                <th className="text-center p-3 font-bold">فعال</th>
                <th className="text-center p-3 font-bold">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [1, 2].map((i) => <tr key={i}><td colSpan={5}><Skeleton className="h-12 m-1" /></td></tr>)
              ) : codes.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">
                  <Code2 className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
                  هنوز کدی اضافه نشده است.
                </td></tr>
              ) : codes.map((c) => (
                <tr key={c.id} className="border-b last:border-0 hover:bg-muted/20">
                  <td className="p-3">
                    <p className="font-medium text-sm truncate max-w-[200px]">{c.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate max-w-[200px] font-mono" dir="ltr">
                      {c.code.replace(/<[^>]+>/g, "").trim().slice(0, 50) || c.code.slice(0, 50)}
                    </p>
                  </td>
                  <td className="p-3">
                    <Badge
                      className="text-[10px]"
                      style={{ background: `${headCodeTypeColor(c.type)}20`, color: headCodeTypeColor(c.type) }}
                    >
                      {headCodeTypeLabel(c.type)}
                    </Badge>
                  </td>
                  <td className="p-3 hidden sm:table-cell">
                    <span className="text-[11px] text-muted-foreground font-mono" dir="ltr">{headCodePlacementLabel(c.placement)}</span>
                  </td>
                  <td className="p-3 text-center">
                    <Switch checked={c.isActive} onCheckedChange={() => toggleActive(c)} aria-label="فعال/غیرفعال" />
                  </td>
                  <td className="p-3">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => { setEditCode(c); setEditorOpen(true); }}
                        className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition"
                        title="ویرایش"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => remove(c)}
                        className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {editorOpen && (
        <HeadCodeEditorDialog
          code={editCode}
          onClose={() => { setEditorOpen(false); setEditCode(null); }}
          onSaved={() => { setEditorOpen(false); setEditCode(null); load(); }}
        />
      )}
    </div>
  );
}

/* ---- Head Code Editor Dialog ---- */
function HeadCodeEditorDialog({ code, onClose, onSaved }: { code: HeadCodeRow | null; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(code?.name || "");
  const [type, setType] = useState(code?.type || "custom");
  const [placement, setPlacement] = useState(code?.placement || "head");
  const [codeValue, setCodeValue] = useState(code?.code || "");
  const [isActive, setIsActive] = useState(code?.isActive ?? true);
  const [saving, setSaving] = useState(false);

  function applyTemplate(tplId: string) {
    const tpl = HEAD_CODE_TEMPLATES.find((t) => t.id === tplId);
    if (!tpl) return;
    setCodeValue(tpl.code);
    setType(tpl.type);
    setPlacement(tpl.placement);
    if (!name.trim()) setName(tpl.label);
    toast.success(`قالب «${tpl.label}» بارگذاری شد`);
  }

  async function save() {
    if (!name.trim() || name.trim().length < 2) {
      toast.error("نام باید حداقل ۲ کاراکتر باشد");
      return;
    }
    if (!codeValue.trim() || codeValue.trim().length < 5) {
      toast.error("کد را به‌صورت کامل وارد کنید");
      return;
    }
    setSaving(true);
    try {
      const isEdit = !!code;
      const url = isEdit ? `/api/admin/head-codes/${code!.id}` : "/api/admin/head-codes";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          type,
          placement,
          code: codeValue.trim(),
          isActive,
        }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "خطا در ذخیره");
      }
      toast.success(isEdit ? "کد به‌روزرسانی شد" : "کد جدید اضافه شد");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ذخیره");
    } finally { setSaving(false); }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-primary" />
            {code ? `ویرایش «${code.name}»` : "افزودن کد تحلیلی جدید"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 overflow-y-auto custom-scrollbar pr-1">
          {/* Quick templates */}
          <div className="space-y-1.5">
            <Label className="text-xs">قالب‌های آماده</Label>
            <div className="flex flex-wrap gap-1.5">
              {HEAD_CODE_TEMPLATES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => applyTemplate(t.id)}
                  className="px-2.5 py-1.5 rounded-lg text-[11px] font-medium border border-orange-200 bg-orange-50 hover:bg-orange-100 text-orange-700 dark:border-orange-500/30 dark:bg-orange-500/10 dark:text-orange-400 dark:hover:bg-orange-500/20 transition flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  {t.label}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground">
              با کلیک روی هر قالب، کد نمونه در فیلد کد قرار می‌گیرد. مقادیرPLACEHOLDER را با شناسه واقعی خود جایگزین کنید.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">نام</Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثلاً: Google Analytics 4"
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">نوع</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {HEAD_CODE_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">محل تزریق</Label>
            <Select value={placement} onValueChange={setPlacement}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {HEAD_CODE_PLACEMENTS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground">
              برای متا تگ‌ها (مانند تأییدیه گوگل) و اسکریپت‌های زودهنگام، «داخل head» را انتخاب کنید.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">کد (HTML / Script)</Label>
            <Textarea
              value={codeValue}
              onChange={(e) => setCodeValue(e.target.value)}
              rows={10}
              dir="ltr"
              className="rounded-xl font-mono text-xs resize-y leading-relaxed"
              placeholder={'<!-- Google tag (gtag.js) -->\n<script async src="https://..."></script>\n<script>...</script>'}
            />
            <p className="text-[10px] text-muted-foreground">
              کد را دقیقاً همان‌طور که از سرویس دریافت کرده‌اید اینجا قرار دهید.
            </p>
          </div>

          <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-muted/40">
            <div>
              <p className="text-sm font-bold">فعال‌سازی کد</p>
              <p className="text-[11px] text-muted-foreground">
                کدهای فعال به‌صورت خودکار در تمام صفحات سایت تزریق می‌شوند.
              </p>
            </div>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={save} disabled={saving} className="rounded-xl gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {code ? "ذخیره تغییرات" : "افزودن کد"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   ۶.۵. قوانین — Terms & Conditions Management
   ============================================================ */
interface TermsRow {
  id: string;
  version: number;
  title: string;
  content: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

function TermsTab() {
  const [versions, setVersions] = useState<TermsRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editTerms, setEditTerms] = useState<TermsRow | null>(null);
  const [previewTerms, setPreviewTerms] = useState<TermsRow | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/terms");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setVersions(data.versions || []);
    } catch {
      toast.error("خطا در بارگذاری قوانین");
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  async function setActive(v: TermsRow) {
    if (v.isActive) return;
    try {
      const res = await fetch(`/api/admin/terms/${v.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: true }),
      });
      if (!res.ok) throw new Error();
      toast.success(`نسخه ${toPersianDigits(v.version)} فعال شد`);
      load();
    } catch { toast.error("خطا در فعال‌سازی نسخه"); }
  }

  async function deactivate(v: TermsRow) {
    try {
      const res = await fetch(`/api/admin/terms/${v.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: false }),
      });
      if (!res.ok) throw new Error();
      toast.success(`نسخه ${toPersianDigits(v.version)} غیرفعال شد`);
      load();
    } catch { toast.error("خطا در غیرفعال‌سازی نسخه"); }
  }

  async function remove(v: TermsRow) {
    if (!confirm(`حذف نسخه ${toPersianDigits(v.version)} — «${v.title}»؟`)) return;
    try {
      const res = await fetch(`/api/admin/terms/${v.id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "خطا در حذف");
      }
      toast.success("نسخه حذف شد");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در حذف");
    }
  }

  const activeVersion = versions.find((v) => v.isActive) || null;

  return (
    <div className="p-4 space-y-4 max-w-5xl mx-auto">
      {/* Active version summary */}
      <Card className="p-5 glass">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500/20 to-yellow-500/10 text-amber-500 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground font-bold uppercase tracking-wider mb-0.5">نسخه فعال فعلی</p>
              {activeVersion ? (
                <>
                  <h3 className="font-black text-base">{activeVersion.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                    <Badge className="text-[10px] bg-primary/15 text-primary">نسخه {toPersianDigits(activeVersion.version)}</Badge>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(activeVersion.updatedAt).toLocaleDateString("fa-IR")}</span>
                  </p>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">هیچ نسخه فعالی موجود نیست — یک نسخه را فعال کنید.</p>
              )}
            </div>
          </div>
          <Button
            onClick={() => { setEditTerms(null); setEditorOpen(true); }}
            className="rounded-xl gap-1.5 bg-primary text-primary-foreground glow-gold-sm"
          >
            <Plus className="w-4 h-4" /> نسخه جدید
          </Button>
        </div>
      </Card>

      {/* Versions list */}
      <Card className="glass overflow-hidden">
        <div className="p-3 border-b bg-muted/40">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-primary" />
            همه نسخه‌ها ({toPersianDigits(versions.length)})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30 text-xs text-muted-foreground">
                <th className="text-right p-3 font-bold">نسخه</th>
                <th className="text-right p-3 font-bold">عنوان</th>
                <th className="text-right p-3 font-bold">وضعیت</th>
                <th className="text-right p-3 font-bold hidden md:table-cell">آخرین تغییر</th>
                <th className="text-center p-3 font-bold">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [1, 2].map((i) => <tr key={i}><td colSpan={5}><Skeleton className="h-12 m-1" /></td></tr>)
              ) : versions.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">
                  <ShieldCheck className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
                  هنوز نسخه‌ای ساخته نشده است.
                </td></tr>
              ) : versions.map((v) => (
                <tr key={v.id} className="border-b last:border-0 hover:bg-muted/20">
                  <td className="p-3">
                    <Badge className="text-[10px] bg-muted text-foreground">v{toPersianDigits(v.version)}</Badge>
                  </td>
                  <td className="p-3">
                    <p className="font-medium text-sm truncate max-w-[200px]">{v.title}</p>
                    <p className="text-[10px] text-muted-foreground truncate max-w-[200px]">{v.content.slice(0, 60).replace(/[#*]/g, "")}...</p>
                  </td>
                  <td className="p-3">
                    {v.isActive ? (
                      <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-500">
                        <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />فعال
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
                        <span className="inline-block w-2 h-2 rounded-full bg-muted-foreground/40" />غیرفعال
                      </span>
                    )}
                  </td>
                  <td className="p-3 hidden md:table-cell text-[11px] text-muted-foreground">
                    {new Date(v.updatedAt).toLocaleDateString("fa-IR")}
                  </td>
                  <td className="p-3">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => setPreviewTerms(v)}
                        className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition"
                        title="مشاهده"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => { setEditTerms(v); setEditorOpen(true); }}
                        className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition"
                        title="ویرایش"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      {v.isActive ? (
                        <button
                          onClick={() => deactivate(v)}
                          className="p-1.5 rounded-lg hover:bg-amber-500/10 text-muted-foreground hover:text-amber-500 transition"
                          title="غیرفعال کردن"
                        >
                          <Ban className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <button
                          onClick={() => setActive(v)}
                          className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-muted-foreground hover:text-emerald-500 transition"
                          title="فعال کردن"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => remove(v)}
                        className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {editorOpen && (
        <TermsEditorDialog
          terms={editTerms}
          onClose={() => { setEditorOpen(false); setEditTerms(null); }}
          onSaved={() => { setEditorOpen(false); setEditTerms(null); load(); }}
        />
      )}

      {previewTerms && (
        <TermsPreviewDialog terms={previewTerms} onClose={() => setPreviewTerms(null)} />
      )}
    </div>
  );
}

/* ---- Terms Editor Dialog ---- */
function TermsEditorDialog({ terms, onClose, onSaved }: { terms: TermsRow | null; onClose: () => void; onSaved: () => void }) {
  const [title, setTitle] = useState(terms?.title || "شرایط و قوانین فیت‌آپ");
  const [content, setContent] = useState(terms?.content || "");
  const [isActive, setIsActive] = useState(terms?.isActive ?? true);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!title.trim() || title.trim().length < 3) {
      toast.error("عنوان حداقل ۳ کاراکتر باید باشد");
      return;
    }
    if (!content.trim() || content.trim().length < 10) {
      toast.error("محتوای قوانین را کامل کنید");
      return;
    }
    setSaving(true);
    try {
      const isEdit = !!terms;
      const url = isEdit ? `/api/admin/terms/${terms!.id}` : "/api/admin/terms";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title.trim(), content: content.trim(), isActive }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "خطا در ذخیره");
      }
      toast.success(isEdit ? "نسخه به‌روزرسانی شد" : "نسخه جدید ساخته شد");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ذخیره");
    } finally { setSaving(false); }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            {terms ? `ویرایش نسخه ${toPersianDigits(terms.version)}` : "ایجاد نسخه جدید قوانین"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 overflow-y-auto custom-scrollbar pr-1">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} className="rounded-xl" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">محتوا (Markdown)</Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={14}
              dir="rtl"
              className="rounded-xl font-mono text-xs resize-y leading-relaxed"
              placeholder="# شرایط و قوانین&#10;&#10;متن قوانین را اینجا بنویسید..."
            />
            <p className="text-[10px] text-muted-foreground">
              از Markdown استفاده کنید: # عنوان، ## زیرعنوان، **پررنگ**، - فهرست
            </p>
          </div>

          <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-muted/40">
            <div>
              <p className="text-sm font-bold">فعال‌سازی به عنوان نسخه فعلی</p>
              <p className="text-[11px] text-muted-foreground">
                با فعال‌سازی، سایر نسخه‌ها غیرفعال می‌شوند و کاربران جدید باید این نسخه را بپذیرند.
              </p>
            </div>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={save} disabled={saving} className="rounded-xl gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {terms ? "ذخیره تغییرات" : "ایجاد نسخه"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---- Terms Preview Dialog ---- */
function TermsPreviewDialog({ terms, onClose }: { terms: TermsRow; onClose: () => void }) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-2xl max-h-[88vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-primary" />
            {terms.title}
            <Badge className="text-[10px] bg-muted text-foreground">نسخه {toPersianDigits(terms.version)}</Badge>
          </DialogTitle>
        </DialogHeader>
        <div className="overflow-y-auto custom-scrollbar pr-1">
          <div dir="rtl" className="text-sm leading-relaxed text-foreground/90">
            <ReactMarkdown>{terms.content}</ReactMarkdown>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">بستن</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   ۷. تنظیمات سایت — Site Settings Dialog
   ============================================================ */
function SiteSettingsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [settings, setSettings] = useState<{ key: string; label: string; value: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/settings");
      const data = await res.json();
      setSettings(data.settings || []);
    } catch {} finally { setLoading(false); }
  }

  useEffect(() => {
    if (open) load();
  }, [open]);

  function update(key: string, value: string) {
    setSettings((s) => s.map((x) => (x.key === key ? { ...x, value } : x)));
  }

  async function saveAll() {
    setSaving(true);
    try {
      const promises = settings.map((s) =>
        fetch("/api/admin/settings", {
          method: "PUT", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: s.key, value: s.value }),
        })
      );
      await Promise.all(promises);
      toast.success("تنظیمات ذخیره شد");
      onClose();
    } catch { toast.error("خطا در ذخیره"); } finally { setSaving(false); }
  }

  if (!open) return null;

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-primary" />
            تنظیمات سایت
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="space-y-2">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-12 rounded-xl" />)}</div>
        ) : (
          <div className="space-y-3">
            {settings.map((s) => (
              <div key={s.key} className="space-y-1.5">
                <Label className="text-xs">{s.label}</Label>
                {s.key === "heroSubtitle" ? (
                  <Textarea value={s.value} onChange={(e) => update(s.key, e.target.value)} rows={2} className="rounded-xl resize-none" />
                ) : s.key === "primaryColor" ? (
                  <div className="flex gap-2">
                    <Input dir="ltr" value={s.value} onChange={(e) => update(s.key, e.target.value)} placeholder="#F4C542" className="rounded-xl font-mono text-sm" />
                    <input
                      type="color"
                      value={/^#[0-9A-Fa-f]{6}$/.test(s.value) ? s.value : "#F4C542"}
                      onChange={(e) => update(s.key, e.target.value)}
                      className="w-11 h-9 rounded-lg border border-border cursor-pointer bg-transparent"
                      aria-label="انتخاب رنگ"
                    />
                  </div>
                ) : (
                  <Input value={s.value} onChange={(e) => update(s.key, e.target.value)} className="rounded-xl" />
                )}
              </div>
            ))}
          </div>
        )}

        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={saveAll} disabled={saving || loading} className="rounded-xl gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            ذخیره تغییرات
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   ۸. مدیریت ادمین‌ها — AdminsTab
   ============================================================ */
interface AdminRow {
  id: string;
  mobile: string;
  name: string | null;
  role: string;
  createdAt: string;
  isSuperAdmin: boolean;
  permissions: AdminPermissions | null;
}

function AdminsTab() {
  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<AdminRow | null>(null);
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/admins", { cache: "no-store" });
      const data = await res.json();
      if (Array.isArray(data.admins)) setAdmins(data.admins);
    } catch {
      toast.error("خطا در دریافت لیست ادمین‌ها");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function removeAdmin(a: AdminRow) {
    if (a.isSuperAdmin) {
      toast.error("سوپرادمین قابل حذف نیست");
      return;
    }
    if (!confirm(`حذف دسترسی ادمین از «${a.name || a.mobile}»؟ نقش کاربر به ورزشکار بازمی‌گردد.`)) return;
    try {
      const res = await fetch(`/api/admin/admins/${a.id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error || "خطا در حذف");
      }
      toast.success("ادمین حذف شد");
      setAdmins((prev) => prev.filter((x) => x.id !== a.id));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  return (
    <div className="p-4 space-y-4 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="w-4.5 h-4.5 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-sm">مدیریت ادمین‌ها</h3>
            <p className="text-[11px] text-muted-foreground">
              {toPersianDigits(admins.length)} ادمین فعال
            </p>
          </div>
        </div>
        <Button onClick={() => setCreating(true)} className="rounded-xl gap-1.5">
          <Plus className="w-4 h-4" />
          افزودن ادمین
        </Button>
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
      ) : admins.length === 0 ? (
        <Card className="p-8 text-center glass">
          <Shield className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">ادمینی یافت نشد</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {admins.map((a) => (
            <AdminCard key={a.id} admin={a} onEdit={() => setEditing(a)} onRemove={() => removeAdmin(a)} />
          ))}
        </div>
      )}

      {creating && (
        <AdminEditDialog
          mode="create"
          onClose={() => setCreating(false)}
          onSaved={() => { setCreating(false); void load(); }}
        />
      )}
      {editing && (
        <AdminEditDialog
          mode="edit"
          admin={editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); void load(); }}
        />
      )}
    </div>
  );
}

function AdminCard({ admin, onEdit, onRemove }: { admin: AdminRow; onEdit: () => void; onRemove: () => void }) {
  // Collect active permission badges
  const activePerms = admin.permissions
    ? PERMISSION_KEYS.filter((k) => (admin.permissions as any)[k])
    : [];
  return (
    <Card className="p-4 glass">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0 flex-1">
          <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center text-primary font-bold shrink-0">
            {admin.isSuperAdmin ? "★" : (admin.name?.[0] || "ا")}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <p className="font-bold text-sm">{admin.name || "بدون نام"}</p>
              {admin.isSuperAdmin ? (
                <Badge className="text-[9px] bg-amber-500 text-white">سوپرادمین</Badge>
              ) : (
                <Badge className="text-[9px] bg-primary text-primary-foreground">ادمین</Badge>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1" dir="ltr">
              <Phone className="w-3 h-3" />
              {admin.mobile}
            </p>
            <div className="flex flex-wrap gap-1 mt-2">
              {activePerms.length === 0 ? (
                <span className="text-[10px] text-muted-foreground">بدون دسترسی خاص</span>
              ) : (
                activePerms.slice(0, 6).map((k) => (
                  <Badge key={k} variant="outline" className="text-[9px]">
                    {PERMISSION_LABELS[k]}
                  </Badge>
                ))
              )}
              {activePerms.length > 6 && (
                <Badge variant="outline" className="text-[9px]">
                  +{toPersianDigits(activePerms.length - 6)}
                </Badge>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {!admin.isSuperAdmin && (
            <>
              <button
                onClick={onEdit}
                className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition"
                title="ویرایش دسترسی‌ها"
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={onRemove}
                className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition"
                title="حذف ادمین"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>
      </div>
    </Card>
  );
}

function AdminEditDialog({
  mode,
  admin,
  onClose,
  onSaved,
}: {
  mode: "create" | "edit";
  admin?: AdminRow;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [mobile, setMobile] = useState("");
  const [name, setName] = useState("");
  const [perms, setPerms] = useState<AdminPermissions>(emptyPermissions());
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (mode === "edit" && admin) {
      setMobile(admin.mobile);
      setName(admin.name || "");
      setPerms(admin.permissions ? { ...admin.permissions } : ALL_TRUE_PERMISSIONS);
    }
  }, [mode, admin]);

  function togglePerm(k: PermissionKey, val: boolean) {
    setPerms((p) => ({ ...p, [k]: val }));
  }

  async function save() {
    setSaving(true);
    try {
      if (mode === "create") {
        if (!/^09\d{9}$/.test(mobile.replace(/\s/g, ""))) {
          toast.error("شماره موبایل نامعتبر است (مثال: 09123456789)");
          setSaving(false);
          return;
        }
        const res = await fetch("/api/admin/admins", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            mobile: mobile.replace(/\s/g, ""),
            name: name.trim() || undefined,
            permissions: perms,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "خطا در ایجاد ادمین");
        toast.success("ادمین جدید اضافه شد");
        onSaved();
      } else if (admin) {
        const res = await fetch(`/api/admin/admins/${admin.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: name.trim() || undefined,
            permissions: perms,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "خطا در به‌روزرسانی");
        toast.success("دسترسی‌ها به‌روزرسانی شد");
        onSaved();
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            {mode === "create" ? "افزودن ادمین جدید" : "ویرایش دسترسی ادمین"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 overflow-y-auto custom-scrollbar pr-1">
          {mode === "create" && (
            <div className="space-y-1.5">
              <Label className="text-xs">شماره موبایل</Label>
              <Input
                dir="ltr"
                value={mobile}
                onChange={(e) => setMobile(e.target.value.replace(/[^\d]/g, "").slice(0, 11))}
                placeholder="09123456789"
                className="rounded-xl text-left font-mono"
              />
              <p className="text-[10px] text-muted-foreground">
                اگر کاربری با این شماره وجود داشته باشد، به ادمین ارتقا می‌یابد. در غیر این‌صورت حساب جدید ساخته می‌شود.
              </p>
            </div>
          )}
          <div className="space-y-1.5">
            <Label className="text-xs">نام نمایشی (اختیاری)</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="rounded-xl" placeholder="مثلاً: علی ادمین" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">دسترسی‌ها</Label>
            <div className="space-y-2 p-3 rounded-xl bg-muted/40">
              {PERMISSION_KEYS.map((k) => (
                <div key={k} className="flex items-center justify-between gap-2">
                  <Label htmlFor={`perm-${k}`} className="text-xs font-normal cursor-pointer">
                    {PERMISSION_LABELS[k]}
                  </Label>
                  <Switch
                    id={`perm-${k}`}
                    checked={perms[k]}
                    onCheckedChange={(v) => togglePerm(k, v)}
                  />
                </div>
              ))}
            </div>
            {mode === "edit" && admin?.isSuperAdmin && (
              <p className="text-[10px] text-amber-600">
                توجه: سوپرادمین همیشه همه دسترسی‌ها را دارد.
              </p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" className="rounded-xl">انصراف</Button>
          <Button onClick={save} disabled={saving} className="rounded-xl gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {mode === "create" ? "ایجاد ادمین" : "ذخیره تغییرات"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   ۹. تیکت‌های پشتیبانی — TicketsTab
   ============================================================ */
const TICKET_CATEGORY_LABELS: Record<string, string> = {
  general: "عمومی",
  technical: "فنی",
  payment: "پرداخت",
  program: "برنامه",
  bug: "باگ",
};

const TICKET_PRIORITY_LABELS: Record<string, string> = {
  low: "کم",
  normal: "معمولی",
  high: "مهم",
  urgent: "فوری",
};

const TICKET_PRIORITY_COLORS: Record<string, string> = {
  low: "bg-slate-100 text-slate-700",
  normal: "bg-cyan-100 text-cyan-700",
  high: "bg-amber-100 text-amber-700",
  urgent: "bg-red-100 text-red-700",
};

const TICKET_STATUS_LABELS: Record<string, string> = {
  open: "باز",
  answered: "پاسخ داده شد",
  closed: "بسته شد",
};

const TICKET_STATUS_COLORS: Record<string, string> = {
  open: "bg-amber-100 text-amber-700",
  answered: "bg-emerald-100 text-emerald-700",
  closed: "bg-slate-100 text-slate-600",
};

interface AdminTicketDto {
  id: string;
  subject: string;
  category: string;
  priority: string;
  status: string;
  message: string;
  adminReply: string | null;
  createdAt: string;
  updatedAt: string;
  repliedAt: string | null;
  userId: string;
  user: { id: string; name: string | null; mobile: string; planName: string | null };
  replies: Array<{
    id: string;
    role: string;
    message: string;
    createdAt: string;
    user: { id: string; name: string | null; mobile: string };
  }>;
}

function TicketsTab() {
  const [tickets, setTickets] = useState<AdminTicketDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [selected, setSelected] = useState<AdminTicketDto | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/support/tickets", { cache: "no-store" });
      const data = await res.json();
      if (Array.isArray(data.tickets)) setTickets(data.tickets);
    } catch {
      toast.error("خطا در دریافت تیکت‌ها");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  function applyFilters(t: AdminTicketDto) {
    if (statusFilter !== "all" && t.status !== statusFilter) return false;
    if (categoryFilter !== "all" && t.category !== categoryFilter) return false;
    if (priorityFilter !== "all" && t.priority !== priorityFilter) return false;
    return true;
  }

  const filtered = tickets.filter(applyFilters);

  function handleUpdated(t: AdminTicketDto) {
    setTickets((prev) => prev.map((x) => (x.id === t.id ? t : x)));
    setSelected(t);
  }

  if (selected) {
    return (
      <AdminTicketDetail
        ticket={selected}
        onBack={() => setSelected(null)}
        onUpdated={handleUpdated}
      />
    );
  }

  return (
    <div className="p-4 space-y-3 max-w-5xl mx-auto">
      {/* Header + filters */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <MessageSquare className="w-4.5 h-4.5 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-sm">تیکت‌های پشتیبانی</h3>
            <p className="text-[11px] text-muted-foreground">
              {toPersianDigits(filtered.length)} تیکت
            </p>
          </div>
        </div>
        <Button onClick={() => void load()} variant="outline" size="sm" className="rounded-xl gap-1.5">
          <Loader2 className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          به‌روزرسانی
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[130px] rounded-xl glass"><SelectValue placeholder="وضعیت" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="open">باز</SelectItem>
            <SelectItem value="answered">پاسخ داده شد</SelectItem>
            <SelectItem value="closed">بسته شد</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[130px] rounded-xl glass"><SelectValue placeholder="دسته" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه دسته‌ها</SelectItem>
            <SelectItem value="general">عمومی</SelectItem>
            <SelectItem value="technical">فنی</SelectItem>
            <SelectItem value="payment">پرداخت</SelectItem>
            <SelectItem value="program">برنامه</SelectItem>
            <SelectItem value="bug">باگ</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[130px] rounded-xl glass"><SelectValue placeholder="اولویت" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه اولویت‌ها</SelectItem>
            <SelectItem value="low">کم</SelectItem>
            <SelectItem value="normal">معمولی</SelectItem>
            <SelectItem value="high">مهم</SelectItem>
            <SelectItem value="urgent">فوری</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-8 text-center glass">
          <MessageSquare className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">تیکتی یافت نشد</p>
        </Card>
      ) : (
        <div className="space-y-2 max-h-[70vh] overflow-y-auto custom-scrollbar pr-1">
          {filtered.map((t) => (
            <button key={t.id} onClick={() => setSelected(t)} className="w-full text-right">
              <Card className="p-3.5 glass hover:border-primary/30 transition-all hover:shadow-md">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5 min-w-0 flex-1">
                    <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <MessageSquare className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-sm truncate">{t.subject}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{t.message}</p>
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        <Badge className={`text-[10px] ${TICKET_STATUS_COLORS[t.status] || "bg-slate-100"}`}>
                          {TICKET_STATUS_LABELS[t.status] || t.status}
                        </Badge>
                        <Badge className={`text-[10px] ${TICKET_PRIORITY_COLORS[t.priority] || "bg-slate-100"}`}>
                          {TICKET_PRIORITY_LABELS[t.priority] || t.priority}
                        </Badge>
                        <Badge variant="outline" className="text-[10px]">
                          {TICKET_CATEGORY_LABELS[t.category] || t.category}
                        </Badge>
                        {t.replies.length > 0 && (
                          <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                            <MessageSquare className="w-3 h-3" />
                            {toPersianDigits(t.replies.length)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <p className="text-[11px] font-medium">{t.user.name || "بدون نام"}</p>
                    <p className="text-[10px] text-muted-foreground" dir="ltr">{t.user.mobile}</p>
                    {t.user.planName && (
                      <Badge className="text-[9px]" style={{ background: `${PLAN_COLORS[t.user.planName]}20`, color: PLAN_COLORS[t.user.planName] }}>
                        {PLAN_LABELS[t.user.planName as Plan]}
                      </Badge>
                    )}
                    <span className="text-[10px] text-muted-foreground whitespace-nowrap mt-1">
                      {new Date(t.updatedAt).toLocaleDateString("fa-IR")}
                    </span>
                  </div>
                </div>
              </Card>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminTicketDetail({
  ticket,
  onBack,
  onUpdated,
}: {
  ticket: AdminTicketDto;
  onBack: () => void;
  onUpdated: (t: AdminTicketDto) => void;
}) {
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [ticket.replies.length]);

  async function sendReply(e?: React.FormEvent) {
    e?.preventDefault();
    if (!reply.trim()) return;
    setSending(true);
    try {
      const res = await fetch(`/api/support/tickets/${ticket.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: reply.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "خطا در ارسال پاسخ");
      onUpdated(data.ticket);
      setReply("");
      toast.success("پاسخ ارسال شد");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطا");
    } finally {
      setSending(false);
    }
  }

  async function changeStatus(status: string, label: string) {
    setUpdatingStatus(true);
    try {
      const res = await fetch(`/api/support/tickets/${ticket.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "خطا در تغییر وضعیت");
      onUpdated(data.ticket);
      toast.success(`تیکت ${label}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطا");
    } finally {
      setUpdatingStatus(false);
    }
  }

  return (
    <div className="p-4 space-y-3 max-w-4xl mx-auto">
      <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition">
        <ChevronRight className="w-4 h-4" />
        بازگشت به لیست تیکت‌ها
      </button>

      {/* User info card */}
      <Card className="p-3 glass">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center text-primary font-bold">
              {ticket.user.name?.[0] || "؟"}
            </div>
            <div>
              <p className="font-bold text-sm">{ticket.user.name || "بدون نام"}</p>
              <p className="text-[11px] text-muted-foreground" dir="ltr">{ticket.user.mobile}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {ticket.user.planName && (
              <Badge style={{ background: `${PLAN_COLORS[ticket.user.planName]}20`, color: PLAN_COLORS[ticket.user.planName] }}>
                {PLAN_LABELS[ticket.user.planName as Plan]}
              </Badge>
            )}
            <Badge className={TICKET_STATUS_COLORS[ticket.status] || "bg-slate-100"}>
              {TICKET_STATUS_LABELS[ticket.status] || ticket.status}
            </Badge>
          </div>
        </div>
      </Card>

      {/* Ticket message card */}
      <Card className="p-4 glass">
        <div className="flex items-start justify-between gap-3 mb-3">
          <h2 className="font-bold text-base">{ticket.subject}</h2>
          <span className="text-[10px] text-muted-foreground whitespace-nowrap">
            {new Date(ticket.createdAt).toLocaleString("fa-IR")}
          </span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap mb-3">
          <Badge variant="outline" className="text-[10px]">
            {TICKET_CATEGORY_LABELS[ticket.category] || ticket.category}
          </Badge>
          <Badge className={`text-[10px] ${TICKET_PRIORITY_COLORS[ticket.priority] || "bg-slate-100"}`}>
            اولویت: {TICKET_PRIORITY_LABELS[ticket.priority] || ticket.priority}
          </Badge>
        </div>
        <p className="text-sm leading-relaxed whitespace-pre-wrap">{ticket.message}</p>
      </Card>

      {/* Replies thread */}
      <Card className="p-3 glass">
        <h3 className="text-xs font-bold mb-2">گفتگو ({toPersianDigits(ticket.replies.length)} پاسخ)</h3>
        <div ref={scrollRef} className="max-h-[40vh] overflow-y-auto custom-scrollbar space-y-2.5 pr-1">
          {ticket.replies.length === 0 && (
            <div className="text-center py-4 text-xs text-muted-foreground">
              هنوز پاسخی ثبت نشده است
            </div>
          )}
          {ticket.replies.map((r) => {
            const isAdmin = r.role === "admin";
            return (
              <div key={r.id} className={`flex ${isAdmin ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 ${
                  isAdmin
                    ? "bg-primary/10 border border-primary/20 text-foreground rounded-bl-md"
                    : "bg-muted text-foreground rounded-br-md"
                }`}>
                  <div className="flex items-center gap-1.5 mb-1">
                    {isAdmin ? (
                      <Badge className="text-[9px] bg-primary text-primary-foreground">ادمین</Badge>
                    ) : (
                      <span className="text-[10px] font-bold">{r.user.name || "کاربر"}</span>
                    )}
                    <span className="text-[9px] text-muted-foreground">
                      {new Date(r.createdAt).toLocaleString("fa-IR")}
                    </span>
                  </div>
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{r.message}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Reply + actions */}
      <Card className="p-3 glass space-y-3">
        <form onSubmit={sendReply} className="space-y-2">
          <Label className="text-xs">پاسخ به کاربر</Label>
          <Textarea
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            placeholder="پاسخ خود را بنویسید..."
            rows={3}
            className="rounded-xl resize-none"
            dir="rtl"
          />
          <div className="flex justify-end">
            <Button type="submit" disabled={sending || !reply.trim()} className="rounded-xl gap-1.5">
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              ارسال پاسخ
            </Button>
          </div>
        </form>

        {/* Status actions */}
        <div className="flex items-center gap-2 flex-wrap pt-2 border-t">
          <span className="text-[11px] text-muted-foreground">تغییر وضعیت:</span>
          <Button
            size="sm"
            variant="outline"
            disabled={updatingStatus || ticket.status === "open"}
            onClick={() => changeStatus("open", "باز شد")}
            className="rounded-lg h-8 gap-1 text-xs"
          >
            <AlertTriangle className="w-3 h-3" />
            باز کردن
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={updatingStatus || ticket.status === "answered"}
            onClick={() => changeStatus("answered", "پاسخ داده شد")}
            className="rounded-lg h-8 gap-1 text-xs"
          >
            <CheckCircle2 className="w-3 h-3" />
            پاسخ داده شد
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={updatingStatus || ticket.status === "closed"}
            onClick={() => changeStatus("closed", "بسته شد")}
            className="rounded-lg h-8 gap-1 text-xs text-destructive hover:text-destructive"
          >
            <Ban className="w-3 h-3" />
            بستن
          </Button>
        </div>
      </Card>
    </div>
  );
}
