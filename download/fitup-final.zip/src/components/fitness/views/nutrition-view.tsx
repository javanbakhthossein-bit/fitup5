"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Apple,
  Flame,
  Beef,
  Wheat,
  Droplet,
  Plus,
  Trash2,
  Utensils,
  Sparkles,
  X,
  Check,
  Salad,
  Pill,
  ChevronLeft,
  Camera,
  Loader2,
} from "lucide-react";
import { useAppStore, type LoggedFood } from "@/lib/fitness/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import {
  canAccess,
  toPersianDigits,
  type MealPlanContent,
} from "@/lib/fitness/types";

const MEAL_LABELS: Record<string, string> = {
  breakfast: "صبحانه",
  lunch: "ناهار",
  dinner: "شام",
  snack: "میان‌وعده",
};

export function NutritionView() {
  const {
    user,
    mealPlan,
    setMealPlan,
    caloriesConsumed,
    setCaloriesConsumed,
    loggedFoods,
    addLoggedFood,
    removeLoggedFood,
  } = useAppStore();
  const [loading, setLoading] = useState(!mealPlan);
  const [showAddFood, setShowAddFood] = useState(false);
  const [expandedMeal, setExpandedMeal] = useState<number | null>(0);

  // --- آنالیز عکس غذا (پلن پیشرفته+) ---
  const canAnalyzeMeal = canAccess(user?.planName ?? null, "mealPhotoAnalysis");
  const [mealAnalyzing, setMealAnalyzing] = useState(false);
  const [mealAnalysisResult, setMealAnalysisResult] = useState<{ analysis: string; imageUrl: string } | null>(null);
  const mealPhotoInputRef = useRef<HTMLInputElement>(null);

  async function handleMealPhotoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    // ریست مقدار input تا همان فایل دوباره قابل انتخاب باشد
    e.target.value = "";
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("فقط فایل تصویری مجاز است.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("حداکثر حجم فایل ۵ مگابایت است.");
      return;
    }

    setMealAnalyzing(true);
    setMealAnalysisResult(null);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const res = await fetch("/api/coach/meal-photo-analysis", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در آنالیز عکس");
      setMealAnalysisResult({ analysis: data.analysis, imageUrl: data.imageUrl });
      toast.success("آنالیز عکس غذا انجام شد! 🍽️");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطا در ارتباط با سرور");
    } finally {
      setMealAnalyzing(false);
    }
  }

  useEffect(() => {
    // Always fetch the CURRENT user's active meal plan fresh from the server
    // so the nutrition tab never shows a stale/cached/generic version.
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/coach/plan", { cache: "no-store" });
        const data = await res.json();
        if (cancelled) return;
        setMealPlan(data.meal ? (data.meal as MealPlanContent) : null);
      } catch {
        // network error — keep whatever is in store
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const targetCal = mealPlan?.totalCalories ?? 2200;
  const burnedCal = 0;
  const remainingCal = Math.max(0, targetCal - caloriesConsumed + burnedCal);

  // Aggregate macros from logged foods (fallback to meal plan)
  const macroTotals = loggedFoods.length
    ? {
        protein: loggedFoods.reduce((s, f) => s + f.protein, 0),
        carbs: loggedFoods.reduce((s, f) => s + f.carbs, 0),
        fat: loggedFoods.reduce((s, f) => s + f.fat, 0),
      }
    : {
        protein: mealPlan?.totalProtein ?? 0,
        carbs: mealPlan?.totalCarbs ?? 0,
        fat: mealPlan?.totalFat ?? 0,
      };

  return (
    <div className="px-4 py-4 space-y-4 max-w-5xl mx-auto lg:px-6">
      {/* فایل مخفی برای انتخاب عکس غذا */}
      <input
        ref={mealPhotoInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleMealPhotoSelect}
      />
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black">کالری‌شمار و تغذیه</h2>
          <p className="text-sm text-muted-foreground">هر لقمه رو ثبت کن، به هدفت نزدیک‌تر شو</p>
        </div>
        <div className="flex items-center gap-2">
          {canAnalyzeMeal && (
            <Button
              variant="outline"
              className="rounded-xl"
              onClick={() => mealPhotoInputRef.current?.click()}
              disabled={mealAnalyzing}
              title="آنالیز عکس غذا با هوش مصنوعی"
            >
              {mealAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
              <span className="hidden sm:inline">آنالیز عکس غذا</span>
            </Button>
          )}
          <Button onClick={() => setShowAddFood(true)} className="rounded-xl">
            <Plus className="w-4 h-4" />
            ثبت غذا
          </Button>
        </div>
      </div>

      {/* کارت نتیجه آنالیز عکس غذا */}
      {mealAnalyzing && (
        <Card className="p-5 border-2 border-orange-200 bg-orange-50/30">
          <div className="flex items-center gap-3">
            <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
            <div>
              <p className="font-bold text-slate-900">در حال آنالیز عکس غذا...</p>
              <p className="text-xs text-slate-500">کمی صبر کنید، هوش مصنوعی در حال شناسایی مواد و کالری است.</p>
            </div>
          </div>
        </Card>
      )}

      {mealAnalysisResult && !mealAnalyzing && (
        <Card className="p-5 border-2 border-orange-200 bg-orange-50/30">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                <Camera className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900">آنالیز عکس غذا</h3>
                <p className="text-[11px] text-slate-500">با هوش مصنوعی فیتاپ</p>
              </div>
            </div>
            <button
              onClick={() => setMealAnalysisResult(null)}
              className="p-1.5 rounded-lg hover:bg-orange-100 text-slate-400 hover:text-slate-700 transition"
              title="بستن"
              aria-label="بستن نتیجه آنالیز"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            {/* عکس آپلودشده */}
            <div className="shrink-0">
              <img
                src={mealAnalysisResult.imageUrl}
                alt="عکس غذای ارسالی"
                className="w-full sm:w-32 h-32 object-cover rounded-xl border border-orange-200"
              />
            </div>
            {/* متن تحلیل */}
            <div className="flex-1 min-w-0">
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">
                {mealAnalysisResult.analysis}
              </p>
            </div>
          </div>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-28 rounded-2xl" />
          <Skeleton className="h-48 rounded-2xl" />
        </div>
      ) : !mealPlan ? (
        <Card className="p-8 text-center border-2 border-orange-200 bg-orange-50/30">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Salad className="w-8 h-8 text-white" />
          </div>
          <h3 className="font-black text-lg text-slate-900 mb-2">برنامه غذایی شما ساخته نشده</h3>
          <p className="text-sm text-slate-500 mb-5">
            {user?.planName
              ? "فیتاپ هوشمند می‌تواند همین حالا برنامه غذایی شخصی‌سازی‌شده برای شما بسازد."
              : "برای دریافت برنامه غذایی اختصاصی، ابتدا یک پلن خریداری کنید."}
          </p>
          {user?.planName ? (
            <Button
              onClick={async () => {
                try {
                  const res = await fetch("/api/coach/plan", { method: "PUT" });
                  const data = await res.json();
                  if (!res.ok) throw new Error(data.error);
                  if (data.meal) setMealPlan(data.meal as MealPlanContent);
                  toast.success("برنامه غذایی شما ساخته شد! 🎯");
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : "خطا در ساخت برنامه");
                }
              }}
              className="rounded-xl text-white gap-2"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              <Sparkles className="w-4 h-4" /> ساخت برنامه غذایی
            </Button>
          ) : (
            <Button onClick={() => useAppStore.getState().setMainTab("plans")} className="rounded-xl text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
              خرید پلن
            </Button>
          )}
        </Card>
      ) : (
        <>
          {/* Calorie formula bar */}
          <Card className="p-5 glass">
            <div className="flex items-center gap-2 mb-3">
              <Flame className="w-5 h-5 text-orange-400" />
              <h3 className="font-bold">وضعیت کالری امروز</h3>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 text-xs mb-4">
              <span className="px-2.5 py-1 rounded-lg bg-muted/60"><b className="text-cyan-400">{toPersianDigits(targetCal)}</b> هدف</span>
              <span className="text-muted-foreground">−</span>
              <span className="px-2.5 py-1 rounded-lg bg-muted/60"><b className="text-orange-400">{toPersianDigits(caloriesConsumed)}</b> مصرف</span>
              <span className="text-muted-foreground">+</span>
              <span className="px-2.5 py-1 rounded-lg bg-muted/60"><b className="text-emerald-400">{toPersianDigits(burnedCal)}</b> تمرین</span>
              <span className="text-muted-foreground">=</span>
              <span className="px-2.5 py-1 rounded-lg bg-primary/15"><b className="text-primary">{toPersianDigits(remainingCal)}</b> باقی‌مانده</span>
            </div>
            <div className="h-4 rounded-full bg-muted overflow-hidden flex relative">
              <motion.div
                className="h-full bg-gradient-to-l from-orange-400 to-orange-500"
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (caloriesConsumed / targetCal) * 100)}%` }}
                transition={{ duration: 0.8 }}
              />
            </div>
            <p className="text-[11px] text-muted-foreground text-center mt-2">
              {remainingCal > 0
                ? `${toPersianDigits(remainingCal)} کالری دیگه می‌تونی بخوری`
                : "به هدف کالری رسیدی! 🎯"}
            </p>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Macro donut */}
            <Card className="p-5 glass">
              <div className="flex items-center gap-2 mb-4">
                <Beef className="w-5 h-5 text-primary" />
                <h3 className="font-bold">درشت‌مغذی‌ها (ماکروها)</h3>
              </div>
              <MacroDonut
                protein={macroTotals.protein}
                carbs={macroTotals.carbs}
                fat={macroTotals.fat}
              />
            </Card>

            {/* Today's meals from plan — full meal plan with food items */}
            <Card className="p-5 glass border-2 border-orange-200">
              <div className="flex items-center gap-2 mb-4">
                <Utensils className="w-5 h-5 text-orange-500" />
                <h3 className="font-bold text-slate-900">برنامه غذایی امروز — چه بخوریم؟</h3>
              </div>
              <div className="space-y-2">
                {mealPlan?.meals.map((meal, i) => {
                  const expanded = expandedMeal === i;
                  return (
                    <div key={i} className="rounded-xl border border-orange-100 overflow-hidden bg-white">
                      {/* Meal header (clickable) */}
                      <button
                        onClick={() => setExpandedMeal(expanded ? null : i)}
                        className="w-full flex items-center justify-between p-3 hover:bg-orange-50/50 transition"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{getMealIcon(meal.type)}</span>
                          <div className="text-right">
                            <span className="text-sm font-bold text-slate-900">{meal.label}</span>
                            <span className="block text-[10px] text-slate-400">
                              {toPersianDigits(meal.items?.length || 0)} مورد • {toPersianDigits(meal.totalCalories)} کالری
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400">
                            P: {toPersianDigits(Math.round(meal.totalProtein))}g
                          </span>
                          <motion.div animate={{ rotate: expanded ? 90 : 0 }} transition={{ duration: 0.2 }}>
                            <ChevronLeft className="w-4 h-4 text-orange-500" />
                          </motion.div>
                        </div>
                      </button>
                      {/* Food items (expandable) */}
                      {expanded && meal.items && meal.items.length > 0 && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          className="border-t border-orange-50 bg-orange-50/30"
                        >
                          {/* Combination banner */}
                          {meal.combination && (
                            <div className="p-2 bg-emerald-50/50 border-b border-emerald-100">
                              <p className="text-[11px] text-emerald-700 font-medium">🍽 ترکیب این وعده: <span className="font-bold">{meal.combination}</span></p>
                            </div>
                          )}
                          {meal.items.map((item, j) => (
                            <div key={j} className="flex items-start justify-between p-2.5 border-b last:border-0 border-orange-50/50">
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-bold text-slate-900">{item.name}</p>
                                <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500 flex-wrap">
                                  {item.servingSize && <span>🍽 {item.servingSize}</span>}
                                  <span>🔥 {toPersianDigits(item.calories)} کالری</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 text-[9px] text-slate-400 shrink-0 mr-2">
                                <span className="px-1.5 py-0.5 rounded bg-red-50 text-red-600">P {toPersianDigits(item.protein)}g</span>
                                <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-600">C {toPersianDigits(item.carbs)}g</span>
                                <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-600">F {toPersianDigits(item.fat)}g</span>
                              </div>
                            </div>
                          ))}
                          {/* Alternatives */}
                          {meal.alternatives && meal.alternatives.length > 0 && (
                            <div className="p-2.5 bg-purple-50/30 border-t border-purple-100">
                              <p className="text-[10px] font-bold text-purple-700 mb-1.5 flex items-center gap-1">
                                <Sparkles className="w-3 h-3" /> غذاهای جایگزین (یکی را انتخاب کنید):
                              </p>
                              <div className="space-y-1.5">
                                {meal.alternatives.map((alt, ai) => (
                                  <div key={ai} className="p-2 rounded-lg bg-white border border-purple-100">
                                    <div className="flex items-center justify-between mb-1">
                                      <span className="text-[11px] font-bold text-purple-800">گزینه {toPersianDigits(ai + 1)}: {alt.combination}</span>
                                      <span className="text-[9px] text-purple-500">{toPersianDigits(alt.totalCalories)} کالری</span>
                                    </div>
                                    <div className="flex flex-wrap gap-1">
                                      {alt.items.map((it, ii) => (
                                        <span key={ii} className="text-[9px] px-1.5 py-0.5 rounded bg-purple-50 text-purple-600">
                                          {it.name} ({it.servingSize})
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </div>
                  );
                })}
              </div>
              {mealPlan?.notes && (
                <div className="mt-3 p-3 rounded-xl bg-orange-50/50 border border-orange-100">
                  <p className="text-[11px] text-slate-600 leading-relaxed">💡 {mealPlan.notes}</p>
                </div>
              )}
              {mealPlan?.waterLiters && (
                <div className="mt-2 flex items-center gap-2 text-[11px] text-cyan-600">
                  <Droplet className="w-3.5 h-3.5" />
                  آب روزانه: {toPersianDigits(mealPlan.waterLiters)} لیتر
                </div>
              )}
            </Card>
          </div>

          {/* Supplements — برنامه مکمل‌ها (Standard+) */}
          {mealPlan?.supplements && mealPlan.supplements.length > 0 && (
            <Card className="p-5 border-2 border-orange-200 bg-orange-50/30">
              <div className="flex items-center gap-2 mb-3">
                <Pill className="w-5 h-5 text-orange-500" />
                <h3 className="font-bold text-slate-900">برنامه مکمل‌های شما</h3>
              </div>
              <div className="space-y-2">
                {mealPlan.supplements.map((s, i) => (
                  <div key={i} className="flex items-start justify-between p-3 rounded-xl bg-white border border-orange-100">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-900">{s.name}</p>
                      <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500">
                        {s.dose && <span>💊 {s.dose}</span>}
                        {s.timing && <span>⏰ {s.timing}</span>}
                      </div>
                      {s.note && <p className="text-[10px] text-slate-400 mt-1">{s.note}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Logged foods today */}
          <Card className="p-5 glass">
            <div className="flex items-center gap-2 mb-3">
              <Apple className="w-5 h-5 text-primary" />
              <h3 className="font-bold">غذاهای ثبت‌شده امروز</h3>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground mr-auto">
                {toPersianDigits(loggedFoods.length)} مورد
              </span>
            </div>
            {loggedFoods.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                <Apple className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">هنوز غذایی ثبت نشده</p>
                <Button size="sm" variant="outline" className="mt-2 rounded-xl" onClick={() => setShowAddFood(true)}>
                  <Plus className="w-4 h-4" />
                  اولین غذات رو ثبت کن
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {loggedFoods.map((f) => (
                  <motion.div
                    key={f.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="p-3 rounded-xl bg-white border-2 border-orange-100"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{getMealIcon(f.meal)}</span>
                          <p className="text-sm font-bold truncate">{f.name}</p>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-0.5">
                          {MEAL_LABELS[f.meal]}
                        </p>
                      </div>
                      <div className="flex flex-col items-end shrink-0">
                        <div className="flex items-baseline gap-1">
                          <span className="text-lg font-black text-orange-500 leading-none">
                            {toPersianDigits(f.calories)}
                          </span>
                          <span className="text-[10px] text-muted-foreground">کالری</span>
                        </div>
                        <button
                          onClick={() => removeLoggedFood(f.id)}
                          className="p-1 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive mt-1"
                          aria-label="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    {/* Macros row */}
                    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-orange-50">
                      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-yellow-50 text-yellow-700">
                        <Beef className="w-2.5 h-2.5" /> P {toPersianDigits(f.protein)}g
                      </span>
                      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-cyan-50 text-cyan-700">
                        <Wheat className="w-2.5 h-2.5" /> C {toPersianDigits(f.carbs)}g
                      </span>
                      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-50 text-purple-700">
                        <Droplet className="w-2.5 h-2.5" /> F {toPersianDigits(f.fat)}g
                      </span>
                    </div>
                  </motion.div>
                ))}

                {/* Total bar */}
                <div
                  className="flex items-center justify-between p-3 rounded-xl text-white mt-3"
                  style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                >
                  <span className="text-sm font-bold flex items-center gap-1.5">
                    <Flame className="w-4 h-4" />
                    مجموع
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-black">{toPersianDigits(caloriesConsumed)}</span>
                    <span className="text-xs opacity-90">کالری</span>
                  </div>
                </div>
              </div>
            )}
          </Card>
        </>
      )}

      {/* Add food modal */}
      <AnimatePresence>
        {showAddFood && (
          <AddFoodModal
            onClose={() => setShowAddFood(false)}
            onAdd={(food) => {
              addLoggedFood(food);
              setShowAddFood(false);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function MacroDonut({ protein, carbs, fat }: { protein: number; carbs: number; fat: number }) {
  const total = protein + carbs + fat || 1;
  const pPct = (protein / total) * 100;
  const cPct = (carbs / total) * 100;
  const fPct = (fat / total) * 100;

  const segments = [
    { pct: pPct, color: "#F4C542", label: "پروتئین", value: protein, icon: Beef },
    { pct: cPct, color: "#06b6d4", label: "کربوهیدرات", value: carbs, icon: Wheat },
    { pct: fPct, color: "#a855f7", label: "چربی", value: fat, icon: Droplet },
  ];

  let offset = 0;
  const c = 2 * Math.PI * 40;

  return (
    <div className="flex items-center gap-4">
      <div className="relative w-32 h-32 shrink-0">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle cx="50" cy="50" r="40" fill="none" stroke="currentColor" strokeWidth="10" className="text-muted/30" />
          {segments.map((seg, i) => {
            const len = (seg.pct / 100) * c;
            const dasharray = `${len} ${c - len}`;
            const el = (
              <motion.circle
                key={i}
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke={seg.color}
                strokeWidth="10"
                strokeDasharray={dasharray}
                strokeDashoffset={-offset}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.2 }}
                style={{ filter: `drop-shadow(0 0 3px ${seg.color}60)` }}
              />
            );
            offset += len;
            return el;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-lg font-black">{toPersianDigits(Math.round(total))}</span>
          <span className="text-[10px] text-muted-foreground">گرم کل</span>
        </div>
      </div>
      <div className="flex-1 space-y-2">
        {segments.map((seg, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ background: seg.color }} />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">{seg.label}</p>
              <p className="text-sm font-bold">
                {toPersianDigits(Math.round(seg.value))}g <span className="text-[10px] text-muted-foreground font-normal">({toPersianDigits(Math.round(seg.pct))}٪)</span>
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AddFoodModal({ onClose, onAdd }: { onClose: () => void; onAdd: (f: LoggedFood) => void }) {
  const [name, setName] = useState("");
  const [meal, setMeal] = useState<LoggedFood["meal"]>("snack");
  const [calories, setCalories] = useState("");
  const [protein, setProtein] = useState("");
  const [carbs, setCarbs] = useState("");
  const [fat, setFat] = useState("");

  function submit() {
    if (!name || !calories) return;
    onAdd({
      id: `food_${Date.now()}`,
      name,
      meal,
      calories: Number(calories),
      protein: Number(protein) || 0,
      carbs: Number(carbs) || 0,
      fat: Number(fat) || 0,
      loggedAt: new Date().toISOString(),
    });
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[90] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="glass-strong rounded-3xl p-5 w-full max-w-md"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Apple className="w-5 h-5 text-primary" />
            ثبت سریع غذا
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block text-sm">نام غذا</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً سینه مرغ گریل" className="rounded-xl" />
          </div>
          <div>
            <Label className="mb-1.5 block text-sm">وعده غذایی</Label>
            <div className="grid grid-cols-4 gap-2">
              {(["breakfast", "lunch", "dinner", "snack"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMeal(m)}
                  className={`py-2 rounded-xl text-xs font-medium transition ${
                    meal === m ? "bg-primary text-primary-foreground" : "bg-muted/60 text-muted-foreground"
                  }`}
                >
                  {MEAL_LABELS[m]}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="mb-1.5 block text-sm">کالری</Label>
            <Input type="number" dir="ltr" value={calories} onChange={(e) => setCalories(e.target.value)} placeholder="250" className="rounded-xl text-center" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="mb-1 block text-xs text-yellow-500">پروتئین (g)</Label>
              <Input type="number" dir="ltr" value={protein} onChange={(e) => setProtein(e.target.value)} placeholder="20" className="rounded-lg text-center text-sm h-9" />
            </div>
            <div>
              <Label className="mb-1 block text-xs text-cyan-400">کربو (g)</Label>
              <Input type="number" dir="ltr" value={carbs} onChange={(e) => setCarbs(e.target.value)} placeholder="30" className="rounded-lg text-center text-sm h-9" />
            </div>
            <div>
              <Label className="mb-1 block text-xs text-purple-400">چربی (g)</Label>
              <Input type="number" dir="ltr" value={fat} onChange={(e) => setFat(e.target.value)} placeholder="8" className="rounded-lg text-center text-sm h-9" />
            </div>
          </div>
          <Button onClick={submit} disabled={!name || !calories} className="w-full rounded-xl h-11 font-bold">
            <Check className="w-4 h-4" />
            ثبت غذا
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function getMealIcon(type: string): string {
  const map: Record<string, string> = { breakfast: "🍳", lunch: "🍱", dinner: "🍽️", snack: "🍎" };
  return map[type] || "🍽️";
}
