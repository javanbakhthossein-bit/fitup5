"use client";

import { SmartCoachChatView } from "@/components/fitness/views/smart-coach-chat-view";

export function ChatView() {
  return (
    <div className="h-full">
      <SmartCoachChatView />
    </div>
  );
}
