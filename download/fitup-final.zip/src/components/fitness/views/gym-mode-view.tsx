"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Music,
  Plus,
  Check,
  Dumbbell,
  Clock,
  Zap,
  ChevronLeft,
  Volume2,
  ListMusic,
  Trash2,
} from "lucide-react";
import { useAppStore, type GymTrack } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toPersianDigits, PERSIAN_WEEKDAYS } from "@/lib/fitness/types";
import { toast } from "sonner";
import {
  saveTrackToDB,
  loadTracksFromDB,
  deleteTrackFromDB,
} from "@/lib/fitness/gym-playlist-db";

export function GymModeView() {
  const {
    setOverlay,
    workoutPlan,
    gymPlaylist,
    setGymPlaylist,
    activeSession,
    startSession,
    logSet,
  } = useAppStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  const [currentTrackIdx, setCurrentTrackIdx] = useState(0);
  const currentTrack = gymPlaylist[currentTrackIdx];
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [selectedDayIdx, setSelectedDayIdx] = useState(0);
  const [setWeights, setSetWeights] = useState<Record<string, string>>({});
  const [setReps, setSetReps] = useState<Record<string, string>>({});
  const [doneSets, setDoneSets] = useState<Record<string, boolean>>({});

  // --- Ref برای ردیابی «قصد پخش» هنگام تغییر ترک ---
  // وقتی کاربر روی ترک جدید کلیک می‌کند یا next/prev را می‌زند، این ref روی true
  // قرار می‌گیرد تا رویداد onPause (که هنگام تعویض src صادر می‌شود) باعث توقف
  // نمایش حالت «در حال پخش» نشود. سپس هنگام بارگذاری metadata ترک جدید،
  // play() صدا زده می‌شود.
  const pendingPlayRef = useRef(false);

  // Default to today's day
  useEffect(() => {
    if (workoutPlan) {
      const dayIdx = new Date().getDay();
      const persianIdx = (dayIdx + 1) % 7;
      const todayName = PERSIAN_WEEKDAYS[persianIdx];
      const idx = workoutPlan.days.findIndex((d) => d.day === todayName);
      if (idx >= 0) setSelectedDayIdx(idx);
    }
  }, [workoutPlan]);

  // ─── Hydrate playlist from IndexedDB on every mount ───
  // Object URLs are session-specific, so we always rebuild them from the
  // persisted Blobs stored in IndexedDB. Any stale URLs in the store are
  // revoked first to avoid memory leaks.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const stored = await loadTracksFromDB();
      if (cancelled) return;
      // Revoke any stale URLs from a previous mount
      const stale = useAppStore.getState().gymPlaylist;
      stale.forEach((t) => {
        try { URL.revokeObjectURL(t.url); } catch {}
      });
      const tracks: GymTrack[] = stored.map((s) => ({
        id: s.id,
        name: s.name,
        url: URL.createObjectURL(s.blob),
        blob: s.blob,
      }));
      setGymPlaylist(tracks);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // ─── Revoke object URLs on unmount to avoid memory leaks ───
  // (the playlist itself persists in IndexedDB; URLs are re-created next mount)
  useEffect(() => {
    return () => {
      const tracks = useAppStore.getState().gymPlaylist;
      tracks.forEach((t) => {
        try {
          URL.revokeObjectURL(t.url);
        } catch {}
      });
    };
  }, []);

  // Audio events
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTime = () => setProgress(audio.currentTime);
    const onMeta = () => {
      setDuration(audio.duration || 0);
      // When a new track's metadata is loaded and we intend to play, start playback.
      // This is the reliable path: play() after metadata is loaded won't be blocked
      // by the browser's autoplay policy because it's triggered by user interaction.
      if (pendingPlayRef.current) {
        audio.play().catch(() => {});
      }
    };
    const onEnd = () => next();
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("ended", onEnd);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("ended", onEnd);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTrackIdx, gymPlaylist]);

  // ─── Explicitly start playback whenever the active track URL changes ───
  // changing `src` doesn't always honor the `autoPlay` attribute, especially
  // when the audio element was previously paused. So when isPlaying is true
  // and the current track URL changes (e.g. user clicked a different track),
  // we explicitly call play(). This effect also serves as a fallback for the
  // onLoadedMetadata handler below.
  useEffect(() => {
    if (!currentTrack?.url) return;
    // If we're switching tracks with intent to play, mark the ref so the
    // pause event fired during src reload doesn't reset isPlaying.
    // The actual play() call happens in onLoadedMetadata (when the new src
    // is ready) — but we also try play() here as a fallback.
    const audio = audioRef.current;
    if (!audio) return;
    if (pendingPlayRef.current) {
      // Try to play immediately; if it fails (src still loading), the
      // onLoadedMetadata handler will retry.
      audio.play().catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTrack?.url]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files) return;
    const fileArr = Array.from(files).filter((f) => f.type.startsWith("audio/"));
    if (fileArr.length === 0) {
      toast.error("فقط فایل‌های صوتی پخش می‌شوند");
      return;
    }
    const tracks: GymTrack[] = fileArr.map((f) => ({
      id: `track_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: f.name.replace(/\.[^/.]+$/, ""),
      url: URL.createObjectURL(f),
      blob: f,
    }));
    setGymPlaylist([...gymPlaylist, ...tracks]);
    toast.success(`${toPersianDigits(tracks.length)} آهنگ به لیست اضافه شد 🎵`);
    e.target.value = "";
    // Persist to IndexedDB (fire-and-forget)
    await Promise.all(
      tracks.map((t) =>
        t.blob
          ? saveTrackToDB({ id: t.id, name: t.name, blob: t.blob })
          : Promise.resolve()
      )
    );
  }

  function togglePlay() {
    if (gymPlaylist.length === 0) {
      fileInputRef.current?.click();
      return;
    }
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      pendingPlayRef.current = false;
      audio.pause();
      setIsPlaying(false);
    } else {
      pendingPlayRef.current = true;
      audio.play().catch(() => {
        // If play() fails (e.g., src not loaded yet), onLoadedMetadata will retry.
      });
      setIsPlaying(true);
    }
  }

  function next() {
    if (gymPlaylist.length === 0) return;
    const idx = (currentTrackIdx + 1) % gymPlaylist.length;
    pendingPlayRef.current = true;
    setCurrentTrackIdx(idx);
    setProgress(0);
    setIsPlaying(true);
  }

  function prev() {
    if (gymPlaylist.length === 0) return;
    const idx = (currentTrackIdx - 1 + gymPlaylist.length) % gymPlaylist.length;
    pendingPlayRef.current = true;
    setCurrentTrackIdx(idx);
    setProgress(0);
    setIsPlaying(true);
  }

  function playTrack(idx: number) {
    if (idx === currentTrackIdx) {
      // کلیک روی ترک در حال پخش → toggle
      togglePlay();
      return;
    }
    // کلیک روی ترک متفاوت → آن را پخش کن
    pendingPlayRef.current = true;
    setCurrentTrackIdx(idx);
    setProgress(0);
    setIsPlaying(true);
  }

  function removeTrack(id: string) {
    const track = gymPlaylist.find((t) => t.id === id);
    if (track) URL.revokeObjectURL(track.url);
    const filtered = gymPlaylist.filter((t) => t.id !== id);
    setGymPlaylist(filtered);
    if (currentTrackIdx >= filtered.length) setCurrentTrackIdx(0);
    // Also delete from IndexedDB
    void deleteTrackFromDB(id);
  }

  // ─── Seek bar (mouse + touch) ───
  function seekFromClientX(clientX: number) {
    const el = progressBarRef.current;
    if (!el || !duration || !audioRef.current) return;
    const rect = el.getBoundingClientRect();
    // RTL-aware: in RTL the bar fills from right to left visually,
    // but the audio currentTime is always 0→duration left-to-right logically.
    // We compute the fraction from the left edge for both LTR and RTL.
    const pct = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    audioRef.current.currentTime = pct * duration;
    setProgress(pct * duration);
  }

  function seek(e: React.MouseEvent<HTMLDivElement>) {
    seekFromClientX(e.clientX);
  }

  function handleTouchSeek(e: React.TouchEvent<HTMLDivElement>) {
    const touch = e.touches[0];
    if (!touch) return;
    seekFromClientX(touch.clientX);
    // Prevent the browser from scrolling while dragging the seek bar
    e.preventDefault();
  }

  function completeSet(exerciseId: string, setNumber: number) {
    const key = `${exerciseId}_${setNumber}`;
    setDoneSets((s) => ({ ...s, [key]: true }));
    const w = Number(setWeights[key] || 0);
    const r = Number(setReps[key] || 0);
    if (activeSession) {
      logSet(exerciseId, setNumber, w, r);
    } else {
      // auto-start session if not active
      if (workoutPlan) startSession(workoutPlan.days[selectedDayIdx].day);
      setTimeout(() => logSet(exerciseId, setNumber, w, r), 50);
    }
    toast.success(`ست ${toPersianDigits(setNumber)} انجام شد! 💪`);
  }

  const activeDay = workoutPlan?.days[selectedDayIdx];

  function fmt(s: number) {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${toPersianDigits(m.toString().padStart(2, "0"))}:${toPersianDigits(sec.toString().padStart(2, "0"))}`;
  }

  return (
    <div className="flex flex-col h-full animated-gradient-bg">
      <input ref={fileInputRef} type="file" accept="audio/*" multiple className="hidden" onChange={handleFileSelect} />
      <audio
        ref={audioRef}
        src={currentTrack?.url}
        onPlay={() => {
          pendingPlayRef.current = false;
          setIsPlaying(true);
        }}
        onPause={() => {
          // هنگام تعویض src، رویداد pause به‌طور خودکار صادر می‌شود.
          // در این حالت نباید isPlaying را false کنیم چون قصد پخش داریم.
          if (!pendingPlayRef.current) {
            setIsPlaying(false);
          }
        }}
        onLoadedMetadata={() => {
          const audio = audioRef.current;
          if (!audio) return;
          setDuration(audio.duration || 0);
          // وقتی ترک جدید بارگذاری شد و قصد پخش داریم، پخش را شروع کن.
          // این زمانی critical است که play() در useEffect قبلی به‌دلیل
          // آماده‌نبودن src ناموفق بوده است.
          if (pendingPlayRef.current) {
            audio.play().catch(() => {
              pendingPlayRef.current = false;
            });
          }
        }}
      />

      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/8 glass-dark">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center">
            <Dumbbell className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-bold text-sm">حالت باشگاه (Gym Mode)</h2>
            <p className="text-[10px] text-muted-foreground">موزیک + برنامه تمرین روز</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setOverlay(null)} className="rounded-full">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4 max-w-5xl mx-auto w-full">
        {/* MUSIC PLAYER */}
        <div className="glass rounded-3xl overflow-hidden">
          {/* Now playing visualizer */}
          <div className="relative h-32 bg-gradient-to-br from-primary/20 via-amber-500/10 to-background flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 opacity-20">
              <div className="absolute top-2 right-4 w-20 h-20 rounded-full bg-primary/40 blur-2xl" />
              <div className="absolute bottom-2 left-4 w-16 h-16 rounded-full bg-amber-500/40 blur-2xl" />
            </div>
            <motion.div
              animate={isPlaying ? { scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] } : {}}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="relative z-10"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shadow-2xl glow-yellow-sm">
                <Music className="w-8 h-8 text-primary-foreground" />
              </div>
            </motion.div>
            {/* Equalizer bars */}
            {isPlaying && (
              <div className="absolute bottom-3 left-4 flex items-end gap-0.5 h-6">
                {[0, 1, 2, 3, 4].map((i) => (
                  <motion.div
                    key={i}
                    className="w-1 bg-primary rounded-full"
                    animate={{ height: [6, 18, 10, 22, 8] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.1 }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Track info + controls */}
          <div className="p-4">
            <div className="text-center mb-3">
              <p className="font-bold text-sm truncate">{currentTrack?.name || "هیچ آهنگی انتخاب نشده"}</p>
              <p className="text-[11px] text-muted-foreground">
                {gymPlaylist.length > 0
                  ? `آهنگ ${toPersianDigits(currentTrackIdx + 1)} از ${toPersianDigits(gymPlaylist.length)}`
                  : "از موسیقی‌های گوشیت اضافه کن"}
              </p>
            </div>

            {/* Progress bar (larger, touch-friendly, LTR-explicit for predictable seeking) */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-[10px] text-muted-foreground font-mono shrink-0 w-10 text-center">{fmt(progress)}</span>
              <div
                ref={progressBarRef}
                dir="ltr"
                role="slider"
                aria-label="پیشرفت پخش"
                aria-valuemin={0}
                aria-valuemax={Math.floor(duration) || 0}
                aria-valuenow={Math.floor(progress) || 0}
                tabIndex={0}
                className="flex-1 h-3 bg-muted rounded-full cursor-pointer relative touch-none select-none group"
                onClick={seek}
                onTouchStart={handleTouchSeek}
                onTouchMove={handleTouchSeek}
                onKeyDown={(e) => {
                  if (!duration || !audioRef.current) return;
                  if (e.key === "ArrowLeft") {
                    audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 5);
                  } else if (e.key === "ArrowRight") {
                    audioRef.current.currentTime = Math.min(duration, audioRef.current.currentTime + 5);
                  }
                }}
              >
                {/* Filled portion (LTR: grows from left to right) */}
                <div
                  className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-amber-500 to-primary pointer-events-none"
                  style={{ width: `${duration ? (progress / duration) * 100 : 0}%` }}
                />
                {/* Draggable thumb */}
                <div
                  className="absolute top-1/2 -translate-y-1/2 -ml-2 w-4 h-4 rounded-full bg-white shadow-md border-2 border-primary pointer-events-none opacity-90 group-hover:scale-110 transition"
                  style={{ left: `${duration ? (progress / duration) * 100 : 0}%` }}
                />
              </div>
              <span className="text-[10px] text-muted-foreground font-mono shrink-0 w-10 text-center">{fmt(duration)}</span>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4 mb-3">
              <button onClick={prev} disabled={gymPlaylist.length === 0} className="p-2 rounded-full hover:bg-muted transition disabled:opacity-30">
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={togglePlay}
                className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-amber-500 text-primary-foreground flex items-center justify-center shadow-lg glow-yellow-sm hover:scale-105 transition"
              >
                {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current mr-0.5" />}
              </button>
              <button onClick={next} disabled={gymPlaylist.length === 0} className="p-2 rounded-full hover:bg-muted transition disabled:opacity-30">
                <SkipForward className="w-5 h-5" />
              </button>
            </div>

            {/* Volume + add music */}
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-muted-foreground" />
              <input
                type="range"
                dir="ltr"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                aria-label="صدا"
                className="flex-1 accent-primary h-1"
              />
              <Button size="sm" variant="outline" className="rounded-xl text-xs shrink-0" onClick={() => fileInputRef.current?.click()}>
                <Plus className="w-4 h-4" />
                افزودن موزیک
              </Button>
            </div>
          </div>

          {/* Playlist */}
          {gymPlaylist.length > 0 && (
            <div className="border-t border-border/50 max-h-44 overflow-y-auto custom-scrollbar">
              <div className="flex items-center gap-1.5 px-4 py-2 text-[11px] text-muted-foreground sticky top-0 bg-card/80 backdrop-blur">
                <ListMusic className="w-3.5 h-3.5" />
                لیست پخش ({toPersianDigits(gymPlaylist.length)})
              </div>
              {gymPlaylist.map((track, i) => (
                <div
                  key={track.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => playTrack(i)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      playTrack(i);
                    }
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/50 transition text-right group cursor-pointer ${
                    i === currentTrackIdx ? "bg-primary/10" : ""
                  }`}
                >
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${i === currentTrackIdx ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    {i === currentTrackIdx && isPlaying ? (
                      <div className="flex items-end gap-0.5 h-3">
                        {[0, 1, 2].map((j) => (
                          <motion.div key={j} className="w-0.5 bg-current rounded-full" animate={{ height: [3, 8, 3] }} transition={{ duration: 0.5, repeat: Infinity, delay: j * 0.1 }} />
                        ))}
                      </div>
                    ) : (
                      <span className="text-[10px] font-bold">{toPersianDigits(i + 1)}</span>
                    )}
                  </div>
                  <span className={`flex-1 text-xs truncate ${i === currentTrackIdx ? "text-primary font-bold" : ""}`}>{track.name}</span>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); removeTrack(track.id); }}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition"
                    aria-label="حذف آهنگ"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* DAY SELECTOR + WORKOUT PROGRAM */}
        <div className="glass rounded-3xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm flex items-center gap-2">
              <Dumbbell className="w-4 h-4 text-primary" />
              برنامه تمرین
            </h3>
            <span className="text-[11px] text-muted-foreground">روز را انتخاب کن</span>
          </div>

          {/* Day selector */}
          {workoutPlan && (
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-3">
              {workoutPlan.days.map((day, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedDayIdx(i)}
                  className={`shrink-0 px-3 py-2 rounded-2xl border-2 transition text-center min-w-[80px] ${
                    selectedDayIdx === i
                      ? "border-primary bg-primary/10"
                      : "border-border bg-card/50"
                  }`}
                >
                  <div className="text-xs font-bold">{day.day}</div>
                  <div className="text-[9px] text-muted-foreground truncate">{day.focus}</div>
                </button>
              ))}
            </div>
          )}

          {/* Active day info */}
          {activeDay ? (
            <>
              <div className="flex items-center justify-between mb-3 p-3 rounded-xl bg-primary/5">
                <div>
                  <p className="font-bold text-sm">{activeDay.title}</p>
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground mt-0.5">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{toPersianDigits(activeDay.estimatedMinutes)} دقیقه</span>
                    <span className="flex items-center gap-1"><Zap className="w-3 h-3" />{toPersianDigits(activeDay.exercises.length)} حرکت</span>
                  </div>
                </div>
              </div>

              {/* Exercises with quick log */}
              <div className="space-y-2.5">
                {activeDay.exercises.map((ex, ei) => (
                  <div key={ex.id} className="rounded-2xl border border-border/50 bg-card/40 p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-6 h-6 rounded-lg bg-primary/15 text-primary text-[10px] font-bold flex items-center justify-center">{toPersianDigits(ei + 1)}</span>
                      <div className="flex-1">
                        <p className="font-bold text-sm">{ex.name}</p>
                        <p className="text-[10px] text-muted-foreground">{ex.muscle} • {toPersianDigits(ex.sets.length)} ست</p>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      {ex.sets.map((set) => {
                        const key = `${ex.id}_${set.setNumber}`;
                        const done = doneSets[key];
                        return (
                          <div key={set.setNumber} className={`flex items-center gap-2 p-2 rounded-lg transition ${done ? "bg-primary/10" : "bg-muted/30"}`}>
                            <span className="text-[10px] text-muted-foreground w-6">ست {toPersianDigits(set.setNumber)}</span>
                            <span className="text-[10px] text-muted-foreground flex-1">هدف: {toPersianDigits(set.reps)}</span>
                            <input
                              type="number"
                              dir="ltr"
                              placeholder="kg"
                              value={setWeights[key] ?? ""}
                              onChange={(e) => setSetWeights((w) => ({ ...w, [key]: e.target.value }))}
                              disabled={done}
                              className="w-12 h-7 text-center text-[11px] rounded-md border bg-background"
                            />
                            <input
                              type="number"
                              dir="ltr"
                              placeholder="rep"
                              value={setReps[key] ?? ""}
                              onChange={(e) => setSetReps((r) => ({ ...r, [key]: e.target.value }))}
                              disabled={done}
                              className="w-12 h-7 text-center text-[11px] rounded-md border bg-background"
                            />
                            <button
                              onClick={() => completeSet(ex.id, set.setNumber)}
                              disabled={done}
                              className={`w-7 h-7 rounded-full flex items-center justify-center transition ${
                                done ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-primary hover:text-primary-foreground"
                              }`}
                            >
                              <Check className="w-3.5 h-3.5" strokeWidth={3} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-6 text-muted-foreground text-sm">
              برنامه تمرینی موجود نیست
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
