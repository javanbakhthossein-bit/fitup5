"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  TrendingDown,
  Plus,
  Camera,
  Trash2,
  Target,
  Scale,
  Trophy,
  X,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { useAppStore } from "@/lib/fitness/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { ImageComparisonSlider } from "@/components/fitness/image-comparison-slider";
import { Ruler } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toPersianDigits } from "@/lib/fitness/types";
import { toast } from "sonner";
import { CheckupSection } from "./checkup-section";

interface ProgressData {
  weights: { id: string; weight: number; note: string; loggedAt: string }[];
  photos: { id: string; imageUrl: string; type: string; note: string; takenAt: string }[];
  startWeight: number | null;
  targetWeight: number | null;
}

export function ProgressView() {
  const { bodyMeasurements, setBodyMeasurements } = useAppStore();
  const [data, setData] = useState<ProgressData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLogModal, setShowLogModal] = useState(false);
  const [newWeight, setNewWeight] = useState("");
  const [newNote, setNewNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [showMeasurements, setShowMeasurements] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/progress");
      const d = await res.json();
      setData(d);
    } catch {
    } finally {
      setLoading(false);
    }
  }

  async function logWeight() {
    if (!newWeight) return;
    setSaving(true);
    try {
      const res = await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ weight: Number(newWeight), note: newNote }),
      });
      if (!res.ok) {
        const e = await res.json();
        throw new Error(e.error);
      }
      toast.success("وزن ثبت شد! 🎉");
      setNewWeight("");
      setNewNote("");
      setShowLogModal(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setSaving(false);
    }
  }

  async function deleteWeight(id: string) {
    try {
      await fetch(`/api/progress?id=${id}`, { method: "DELETE" });
      load();
    } catch {}
  }

  const chartData =
    data?.weights?.map((w) => ({
      date: new Date(w.loggedAt).toLocaleDateString("fa-IR", { month: "short", day: "numeric" }),
      وزن: w.weight,
      id: w.id,
    })) || [];

  const currentWeight = data?.weights[data.weights.length - 1]?.weight;
  const startWeight = data?.startWeight;
  const targetWeight = data?.targetWeight;
  const totalLost = startWeight && currentWeight ? (startWeight - currentWeight) : 0;

  return (
    <div className="px-4 py-4 space-y-4 max-w-md mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black">پیشرفت من</h2>
          <p className="text-sm text-muted-foreground">پیگیری وزن و تصاویر پیشرفت</p>
        </div>
        <Button onClick={() => setShowLogModal(true)} className="rounded-xl">
          <Plus className="w-4 h-4" />
          ثبت وزن
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-2">
        <SummaryCard
          icon={Scale}
          label="وزن فعلی"
          value={loading ? null : currentWeight ? `${toPersianDigits(currentWeight)}` : null}
          unit="kg"
          color="emerald"
        />
        <SummaryCard
          icon={TrendingDown}
          label="تغییرات"
          value={loading ? null : totalLost > 0 ? `-${toPersianDigits(totalLost.toFixed(1))}` : totalLost < 0 ? `+${toPersianDigits(Math.abs(totalLost).toFixed(1))}` : "۰"}
          unit="kg"
          color="orange"
        />
        <SummaryCard
          icon={Target}
          label="وزن هدف"
          value={loading ? null : targetWeight ? `${toPersianDigits(targetWeight)}` : "—"}
          unit="kg"
          color="violet"
        />
      </div>

      {/* Weight chart */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-sm">نمودار وزن</h3>
          <TrendingDown className="w-4 h-4 text-primary" />
        </div>
        {loading ? (
          <Skeleton className="h-48 rounded-xl" />
        ) : chartData.length === 0 ? (
          <div className="h-48 flex flex-col items-center justify-center text-muted-foreground">
            <Scale className="w-10 h-10 mb-2 opacity-40" />
            <p className="text-sm">هنوز وزنی ثبت نشده</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
              <defs>
                <linearGradient id="weightGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-muted/30" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10, fill: "currentColor" }}
                className="text-muted-foreground"
                reversed
              />
              <YAxis
                tick={{ fontSize: 10, fill: "currentColor" }}
                className="text-muted-foreground"
                orientation="right"
                domain={["dataMin - 2", "dataMax + 2"]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "12px",
                  fontSize: "12px",
                }}
                labelStyle={{ color: "currentColor" }}
              />
              {targetWeight && (
                <ReferenceLine
                  y={targetWeight}
                  stroke="#a855f7"
                  strokeDasharray="5 5"
                  label={{ value: "هدف", fontSize: 10, fill: "#a855f7" }}
                />
              )}
              <Line
                type="monotone"
                dataKey="وزن"
                stroke="#F4C542"
                strokeWidth={3}
                dot={{ fill: "#F4C542", r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </Card>

      {/* Weight log list */}
      {data && data.weights.length > 0 && (
        <Card className="p-4">
          <h3 className="font-bold text-sm mb-3">سوابق وزن</h3>
          <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
            {[...data.weights].reverse().map((w) => (
              <div
                key={w.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-muted/40"
              >
                <div>
                  <span className="font-bold text-sm">{toPersianDigits(w.weight)} kg</span>
                  {w.note && <p className="text-[11px] text-muted-foreground">{w.note}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-muted-foreground">
                    {new Date(w.loggedAt).toLocaleDateString("fa-IR")}
                  </span>
                  <button
                    onClick={() => deleteWeight(w.id)}
                    className="p-1 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Progress photos */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-primary" />
            <h3 className="font-bold text-sm">گالری پیشرفت</h3>
          </div>
          <span className="text-[11px] text-muted-foreground">خصوصی</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {data?.photos.length ? (
            data.photos.map((p) => (
              <div key={p.id} className="aspect-square rounded-xl overflow-hidden bg-muted relative group">
                <img src={p.imageUrl} alt={p.type} className="w-full h-full object-cover" />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-1.5">
                  <p className="text-[9px] text-white">{p.type}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-3 py-8 text-center text-muted-foreground">
              <Camera className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-xs">برای ثبت پیشرفت، تصاویر خود را اضافه کنید</p>
            </div>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground mt-3 text-center">
          تصاویر پیشرفت کاملاً خصوصی هستند و فقط برای شما نمایش داده می‌شوند.
        </p>
      </Card>

      {/* Achievement */}
      {totalLost > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-4 rounded-2xl bg-gradient-to-l from-amber-500/20 to-orange-500/10 border border-amber-500/30 flex items-center gap-3"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center">
            <Trophy className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="font-bold text-sm">آفرین! {toPersianDigits(totalLost.toFixed(1))} کیلو کاهش وزن</p>
            <p className="text-xs text-muted-foreground">به مسیر موفقیت ادامه بده! 💪</p>
          </div>
        </motion.div>
      )}

      {/* Body measurements */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Ruler className="w-4 h-4 text-primary" />
            <h3 className="font-bold text-sm">اندازه‌های بدن</h3>
          </div>
          <Button size="sm" variant="outline" className="rounded-xl text-xs" onClick={() => setShowMeasurements((v) => !v)}>
            {showMeasurements ? "بستن" : "ثبت اندازه"}
          </Button>
        </div>
        {showMeasurements ? (
          <BodyMeasurementsForm
            values={bodyMeasurements}
            onSave={(m) => {
              setBodyMeasurements(m);
              setShowMeasurements(false);
              toast.success("اندازه‌های بدن ثبت شد");
            }}
          />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <MeasurementChip label="دور کمر" value={bodyMeasurements.waist} unit="cm" />
            <MeasurementChip label="دور بازو" value={bodyMeasurements.arm} unit="cm" />
            <MeasurementChip label="دور سینه" value={bodyMeasurements.chest} unit="cm" />
            <MeasurementChip label="دور باسن" value={bodyMeasurements.hip} unit="cm" />
          </div>
        )}
      </Card>

      {/* Checkup section — periodic checkups with AI analysis */}
      <CheckupSection />

      {/* Before/After comparison slider */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Camera className="w-4 h-4 text-primary" />
          <h3 className="font-bold text-sm">مقایسه تصاویر پیشرفت</h3>
        </div>
        <ImageComparisonSlider
          beforeUrl="/hero-fitness.png"
          afterUrl="/hero-app.png"
          beforeLabel="قبل"
          afterLabel="بعد"
        />
        <p className="text-[11px] text-muted-foreground text-center mt-2">
          برای مقایسه، روی اسلایدر بکشید 👈
        </p>
      </Card>

      {/* Log weight modal */}
      <Dialog open={showLogModal} onOpenChange={setShowLogModal}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>ثبت وزن جدید</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="mb-2 block">وزن (کیلوگرم)</Label>
              <Input
                type="number"
                value={newWeight}
                onChange={(e) => setNewWeight(e.target.value)}
                placeholder="مثلاً ۷۵"
                className="h-12 rounded-xl text-center text-lg"
                inputMode="decimal"
              />
            </div>
            <div>
              <Label className="mb-2 block">یادداشت (اختیاری)</Label>
              <Input
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="مثلاً: بعد از تمرین"
                className="rounded-xl"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLogModal(false)}>
              انصراف
            </Button>
            <Button onClick={logWeight} disabled={!newWeight || saving}>
              {saving ? "در حال ثبت..." : "ثبت"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const SUMMARY_COLORS: Record<string, string> = {
  emerald: "text-emerald-500 bg-emerald-500/10",
  orange: "text-orange-500 bg-orange-500/10",
  violet: "text-violet-500 bg-violet-500/10",
};

function SummaryCard({
  icon: Icon,
  label,
  value,
  unit,
  color,
}: {
  icon: any;
  label: string;
  value: string | null;
  unit: string;
  color: string;
}) {
  return (
    <Card className="p-3 text-center">
      <div className={`w-8 h-8 rounded-lg ${SUMMARY_COLORS[color]} flex items-center justify-center mx-auto mb-1.5`}>
        <Icon className="w-4 h-4" />
      </div>
      {value === null ? (
        <Skeleton className="h-5 w-12 mx-auto mb-1" />
      ) : (
        <p className="text-base font-black">{value}</p>
      )}
      <p className="text-[10px] text-muted-foreground">{label}</p>
      {value !== null && <p className="text-[9px] text-muted-foreground/70">{unit}</p>}
    </Card>
  );
}

function MeasurementChip({ label, value, unit }: { label: string; value?: number; unit: string }) {
  return (
    <div className="p-2.5 rounded-xl bg-muted/40 text-center">
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="font-bold text-sm">{value ? toPersianDigits(value) : "—"}</p>
      {value && <p className="text-[9px] text-muted-foreground/70">{unit}</p>}
    </div>
  );
}

function BodyMeasurementsForm({
  values,
  onSave,
}: {
  values: { waist?: number; arm?: number; chest?: number; hip?: number };
  onSave: (m: { waist?: number; arm?: number; chest?: number; hip?: number }) => void;
}) {
  const [waist, setWaist] = useState(values.waist?.toString() ?? "");
  const [arm, setArm] = useState(values.arm?.toString() ?? "");
  const [chest, setChest] = useState(values.chest?.toString() ?? "");
  const [hip, setHip] = useState(values.hip?.toString() ?? "");

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="mb-1 block text-xs">دور کمر (cm)</Label>
          <Input dir="ltr" type="number" value={waist} onChange={(e) => setWaist(e.target.value)} className="rounded-lg text-center text-sm h-9" />
        </div>
        <div>
          <Label className="mb-1 block text-xs">دور بازو (cm)</Label>
          <Input dir="ltr" type="number" value={arm} onChange={(e) => setArm(e.target.value)} className="rounded-lg text-center text-sm h-9" />
        </div>
        <div>
          <Label className="mb-1 block text-xs">دور سینه (cm)</Label>
          <Input dir="ltr" type="number" value={chest} onChange={(e) => setChest(e.target.value)} className="rounded-lg text-center text-sm h-9" />
        </div>
        <div>
          <Label className="mb-1 block text-xs">دور باسن (cm)</Label>
          <Input dir="ltr" type="number" value={hip} onChange={(e) => setHip(e.target.value)} className="rounded-lg text-center text-sm h-9" />
        </div>
      </div>
      <Button
        size="sm"
        className="w-full rounded-xl"
        onClick={() =>
          onSave({
            waist: waist ? Number(waist) : undefined,
            arm: arm ? Number(arm) : undefined,
            chest: chest ? Number(chest) : undefined,
            hip: hip ? Number(hip) : undefined,
          })
        }
      >
        ذخیره اندازه‌ها
      </Button>
    </div>
  );
}
