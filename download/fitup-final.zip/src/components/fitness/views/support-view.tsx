"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Headphones,
  Plus,
  ChevronLeft,
  Send,
  Loader2,
  MessageSquare,
  XCircle,
  Inbox,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits } from "@/lib/fitness/types";
import { toast } from "sonner";

// ---------- Types ----------
interface TicketReplyDto {
  id: string;
  role: string; // user | admin
  message: string;
  createdAt: string;
  user: { id: string; name: string | null; mobile: string };
}

interface TicketDto {
  id: string;
  subject: string;
  category: string;
  priority: string;
  status: string; // open | answered | closed
  message: string;
  adminReply: string | null;
  createdAt: string;
  updatedAt: string;
  repliedAt: string | null;
  userId: string;
  user: { id: string; name: string | null; mobile: string; planName: string | null };
  replies: TicketReplyDto[];
}

// ---------- Constants ----------
const CATEGORY_LABELS: Record<string, string> = {
  general: "عمومی",
  technical: "فنی",
  payment: "پرداخت",
  program: "برنامه",
  bug: "باگ",
};

const PRIORITY_LABELS: Record<string, string> = {
  low: "کم",
  normal: "معمولی",
  high: "مهم",
  urgent: "فوری",
};

const PRIORITY_COLORS: Record<string, string> = {
  low: "bg-slate-100 text-slate-700",
  normal: "bg-cyan-100 text-cyan-700",
  high: "bg-amber-100 text-amber-700",
  urgent: "bg-red-100 text-red-700",
};

const STATUS_LABELS: Record<string, string> = {
  open: "باز",
  answered: "پاسخ داده شد",
  closed: "بسته شد",
};

const STATUS_COLORS: Record<string, string> = {
  open: "bg-amber-100 text-amber-700",
  answered: "bg-emerald-100 text-emerald-700",
  closed: "bg-slate-100 text-slate-600",
};

function formatJalali(iso: string): string {
  try {
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
      day: "numeric",
      month: "long",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(iso));
  } catch {
    return new Date(iso).toLocaleString("fa-IR");
  }
}

// ---------- Main view ----------
export function SupportView() {
  const [tickets, setTickets] = useState<TicketDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<TicketDto | null>(null);
  const [showNew, setShowNew] = useState(false);

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/support/tickets", { cache: "no-store" });
      const data = await res.json();
      if (Array.isArray(data.tickets)) setTickets(data.tickets);
    } catch {
      toast.error("خطا در دریافت تیکت‌ها");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchTickets();
  }, [fetchTickets]);

  function handleCreated(t: TicketDto) {
    setTickets((prev) => [t, ...prev]);
    setShowNew(false);
    setSelected(t);
    toast.success("تیکت شما ثبت شد ✅");
  }

  function handleTicketUpdated(t: TicketDto) {
    setTickets((prev) => prev.map((x) => (x.id === t.id ? t : x)));
    setSelected(t);
  }

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-orange-500/20"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-black text-slate-900">پشتیبانی</h1>
            <p className="text-xs text-slate-500">
              سوالات، مشکلات و بازخوردهای خود را با ما در میان بگذارید
            </p>
          </div>
        </div>
        <Button
          onClick={() => setShowNew(true)}
          className="rounded-xl gap-1.5"
          style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">تیکت جدید</span>
        </Button>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {selected ? (
          <motion.div
            key="detail"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
          >
            <TicketDetail
              ticket={selected}
              onBack={() => setSelected(null)}
              onUpdated={handleTicketUpdated}
            />
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
          >
            <TicketList
              tickets={tickets}
              loading={loading}
              onOpen={(t) => setSelected(t)}
              onRetry={fetchTickets}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* New ticket dialog */}
      {showNew && (
        <NewTicketDialog
          onClose={() => setShowNew(false)}
          onCreated={handleCreated}
        />
      )}
    </div>
  );
}

// ---------- Ticket list ----------
function TicketList({
  tickets,
  loading,
  onOpen,
  onRetry,
}: {
  tickets: TicketDto[];
  loading: boolean;
  onOpen: (t: TicketDto) => void;
  onRetry: () => void;
}) {
  if (loading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <Card className="p-10 text-center glass">
        <div className="mx-auto w-16 h-16 rounded-2xl bg-orange-50 flex items-center justify-center mb-3">
          <Inbox className="w-8 h-8 text-orange-400" />
        </div>
        <p className="text-slate-700 font-bold mb-1">هنوز تیکتی ثبت نکرده‌اید</p>
        <p className="text-xs text-slate-500 mb-4">
          اگر سوال یا مشکلی دارید، اولین تیکت خود را ثبت کنید
        </p>
        <Button onClick={onRetry} variant="outline" size="sm" className="rounded-xl">
          تلاش مجدد
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {tickets.map((t) => (
        <button
          key={t.id}
          onClick={() => onOpen(t)}
          className="w-full text-right"
        >
          <Card className="p-3.5 glass hover:border-orange-300 transition-all hover:shadow-md hover:shadow-orange-500/10">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5 min-w-0 flex-1">
                <div className="w-9 h-9 rounded-xl bg-orange-100 flex items-center justify-center shrink-0 mt-0.5">
                  <MessageSquare className="w-4 h-4 text-orange-600" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-sm text-slate-900 truncate">{t.subject}</p>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">
                    {t.message}
                  </p>
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <Badge className={`text-[10px] ${STATUS_COLORS[t.status] || "bg-slate-100"}`}>
                      {STATUS_LABELS[t.status] || t.status}
                    </Badge>
                    <Badge className={`text-[10px] ${PRIORITY_COLORS[t.priority] || "bg-slate-100"}`}>
                      {PRIORITY_LABELS[t.priority] || t.priority}
                    </Badge>
                    <Badge variant="outline" className="text-[10px]">
                      {CATEGORY_LABELS[t.category] || t.category}
                    </Badge>
                    {t.replies.length > 0 && (
                      <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                        <MessageSquare className="w-3 h-3" />
                        {toPersianDigits(t.replies.length)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <ChevronLeft className="w-4 h-4 text-slate-400" />
                <span className="text-[10px] text-slate-400 whitespace-nowrap">
                  {formatJalali(t.updatedAt)}
                </span>
              </div>
            </div>
          </Card>
        </button>
      ))}
    </div>
  );
}

// ---------- Ticket detail ----------
function TicketDetail({
  ticket,
  onBack,
  onUpdated,
}: {
  ticket: TicketDto;
  onBack: () => void;
  onUpdated: (t: TicketDto) => void;
}) {
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Refresh ticket on mount to ensure replies are up-to-date
  useEffect(() => {
    void (async () => {
      try {
        setRefreshing(true);
        const res = await fetch(`/api/support/tickets/${ticket.id}`, { cache: "no-store" });
        if (res.ok) {
          const data = await res.json();
          if (data.ticket) onUpdated(data.ticket);
        }
      } catch {} finally {
        setRefreshing(false);
      }
    })();
  }, [ticket.id, onUpdated]);

  // Auto-scroll to bottom when replies change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [ticket.replies.length]);

  async function sendReply(e?: React.FormEvent) {
    e?.preventDefault();
    if (!reply.trim()) return;
    if (ticket.status === "closed") {
      toast.error("این تیکت بسته شده است. ابتدا آن را باز کنید.");
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`/api/support/tickets/${ticket.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: reply.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "خطا در ارسال پاسخ");
      onUpdated(data.ticket);
      setReply("");
      toast.success("پاسخ شما ارسال شد");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطای ناشناخته");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="space-y-3">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900 transition"
      >
        <ChevronLeft className="w-4 h-4 rotate-180" />
        بازگشت به لیست تیکت‌ها
      </button>

      {/* Ticket header card */}
      <Card className="p-4 glass">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-start gap-2.5 min-w-0 flex-1">
            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5 text-orange-600" />
            </div>
            <div className="min-w-0">
              <h2 className="font-bold text-slate-900 truncate">{ticket.subject}</h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {formatJalali(ticket.createdAt)}
              </p>
            </div>
          </div>
          <Badge className={`text-[10px] ${STATUS_COLORS[ticket.status] || "bg-slate-100"}`}>
            {STATUS_LABELS[ticket.status] || ticket.status}
          </Badge>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <Badge variant="outline" className="text-[10px]">
            {CATEGORY_LABELS[ticket.category] || ticket.category}
          </Badge>
          <Badge className={`text-[10px] ${PRIORITY_COLORS[ticket.priority] || "bg-slate-100"}`}>
            اولویت: {PRIORITY_LABELS[ticket.priority] || ticket.priority}
          </Badge>
        </div>
        <p className="text-sm text-slate-700 leading-relaxed mt-3 whitespace-pre-wrap">
          {ticket.message}
        </p>
      </Card>

      {/* Replies thread */}
      <Card className="p-3 glass">
        <div className="flex items-center justify-between mb-2 px-1">
          <h3 className="text-xs font-bold text-slate-700">گفتگو</h3>
          {refreshing && (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-400" />
          )}
        </div>

        <div
          ref={scrollRef}
          className="max-h-[40vh] overflow-y-auto custom-scrollbar space-y-2.5 pr-1"
        >
          {ticket.replies.length === 0 && (
            <div className="text-center py-6 text-xs text-slate-500">
              هنوز پاسخی ثبت نشده است. اولین نفر باشید!
            </div>
          )}
          {ticket.replies.map((r) => (
            <ReplyBubble key={r.id} reply={r} />
          ))}
        </div>
      </Card>

      {/* Reply input */}
      <Card className="p-3 glass">
        {ticket.status === "closed" ? (
          <div className="text-center py-3 text-xs text-slate-500 flex items-center justify-center gap-1.5">
            <XCircle className="w-4 h-4 text-slate-400" />
            این تیکت بسته شده است.
          </div>
        ) : (
          <form onSubmit={sendReply} className="space-y-2">
            <Label className="text-xs text-slate-700">پاسخ شما</Label>
            <Textarea
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              placeholder="متن پاسخ خود را بنویسید..."
              rows={3}
              className="rounded-xl resize-none"
              dir="rtl"
            />
            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={sending || !reply.trim()}
                className="rounded-xl gap-1.5"
                style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
              >
                {sending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                ارسال پاسخ
              </Button>
            </div>
          </form>
        )}
      </Card>
    </div>
  );
}

// ---------- Reply bubble ----------
function ReplyBubble({ reply }: { reply: TicketReplyDto }) {
  const isAdmin = reply.role === "admin";
  return (
    <div className={`flex ${isAdmin ? "justify-start" : "justify-end"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 ${
          isAdmin
            ? "bg-orange-50 border border-orange-200 text-slate-800 rounded-bl-md"
            : "bg-slate-100 text-slate-800 rounded-br-md"
        }`}
      >
        <div className="flex items-center gap-1.5 mb-1">
          {isAdmin ? (
            <Badge className="text-[9px] bg-orange-500 text-white">پشتیبانی</Badge>
          ) : (
            <span className="text-[10px] font-bold text-slate-600">شما</span>
          )}
          <span className="text-[9px] text-slate-400">{formatJalali(reply.createdAt)}</span>
        </div>
        <p className="text-sm whitespace-pre-wrap leading-relaxed">{reply.message}</p>
      </div>
    </div>
  );
}

// ---------- New ticket dialog ----------
function NewTicketDialog({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (t: TicketDto) => void;
}) {
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("general");
  const [priority, setPriority] = useState("normal");
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    if (subject.trim().length < 3) {
      toast.error("موضوع باید حداقل ۳ کاراکتر باشد");
      return;
    }
    if (message.trim().length < 5) {
      toast.error("متن پیام باید حداقل ۵ کاراکتر باشد");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/support/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: subject.trim(),
          category,
          priority,
          message: message.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "خطا در ثبت تیکت");
      onCreated(data.ticket);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطای ناشناخته");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-primary" />
            تیکت جدید
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">موضوع</Label>
            <Input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="مثلاً: مشکل در ورود به حساب کاربری"
              className="rounded-xl"
              maxLength={120}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-xs">دسته‌بندی</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">عمومی</SelectItem>
                  <SelectItem value="technical">فنی</SelectItem>
                  <SelectItem value="payment">پرداخت</SelectItem>
                  <SelectItem value="program">برنامه</SelectItem>
                  <SelectItem value="bug">باگ</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">اولویت</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">کم</SelectItem>
                  <SelectItem value="normal">معمولی</SelectItem>
                  <SelectItem value="high">مهم</SelectItem>
                  <SelectItem value="urgent">فوری</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">متن پیام</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="مشکل یا سوال خود را با جزئیات شرح دهید..."
              rows={5}
              className="rounded-xl resize-none"
              dir="rtl"
            />
          </div>

          <DialogFooter>
            <Button type="button" onClick={onClose} variant="outline" className="rounded-xl">
              انصراف
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="rounded-xl gap-1.5"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              ثبت تیکت
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
