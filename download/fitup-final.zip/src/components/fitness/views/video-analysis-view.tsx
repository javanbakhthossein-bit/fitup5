"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Video,
  Upload,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Camera,
  Clock,
  FileVideo,
  Maximize,
  Lightbulb,
  Shirt,
  Eye,
  type LucideIcon,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/fitness/types";
import { toast } from "sonner";

const GUIDE_ITEMS: { icon: LucideIcon; title: string; desc: string; color: string }[] = [
  { icon: Shirt, title: "لباس مناسب", desc: "لباس تنگ یا ورزشی که فرم بدن مشخص باشد", color: "#f59e0b" },
  { icon: Camera, title: "زاویه دوربین", desc: "از روبرو، پهلو و پشت — سه زاویه", color: "#f97316" },
  { icon: Clock, title: "مدت زمان", desc: "۳۰ ثانیه تا ۱ دقیقه برای هر زاویه", color: "#10b981" },
  { icon: FileVideo, title: "فرمت فایل", desc: "MP4، MOV یا WebM", color: "#06b6d4" },
  { icon: Maximize, title: "حداکثر حجم", desc: "حداکثر ۱۰ مگابایت", color: "#8b5cf6" },
  { icon: Lightbulb, title: "نور محیط", desc: "نور کافی و یکنواخت", color: "#eab308" },
  { icon: Eye, title: "نکته ضبط", desc: "بدون کفش، روی سطح صاف بایستید", color: "#ec4899" },
];

export function VideoAnalysisView() {
  const { setOverlay, user } = useAppStore();
  const [file, setFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const usedCount = 0; // would come from DB
  const limit = 10;

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("video/")) {
      toast.error("فقط فایل ویدیویی مجاز است");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      toast.error("حجم ویدیو باید کمتر از ۱۰ مگابایت باشد");
      return;
    }
    setFile(f);
    setVideoUrl(URL.createObjectURL(f));
    setResult(null);
  }

  async function analyze() {
    if (!file) return;
    setAnalyzing(true);
    try {
      // Convert file to base64
      const arrayBuffer = await file.arrayBuffer();
      const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
      const res = await fetch("/api/coach/analyze-video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          base64Video: base64,
          mimeType: file.type,
          userContext: "تحلیل فرم بدن و تکنیک حرکات ورزشی",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در تحلیل ویدیو");
      setResult(data);
      toast.success("آنالیز ویدیویی کامل شد! 🎯");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در تحلیل");
    } finally {
      setAnalyzing(false);
    }
  }

  function reset() {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setFile(null);
    setVideoUrl("");
    setResult(null);
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-strong">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <Video className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-sm">آنالیز ویدیویی بدن</h2>
            <p className="text-[10px] text-muted-foreground">پلن حرفه‌ای — {toPersianDigits(usedCount)}/{toPersianDigits(limit)} استفاده</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setOverlay(null)} className="rounded-full">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4 max-w-2xl mx-auto w-full">
        <div className="glass-yellow rounded-2xl p-4 text-sm text-center">
          <Sparkles className="w-5 h-5 text-primary mx-auto mb-1" />
          ویدیوی تمرینت رو آپلود کن تا هوش مصنوعی فرم بدن، تقارن و تکنیکت رو آنالیز کنه
        </div>

        {/* Recording guide */}
        <div className="bg-white rounded-2xl border-2 border-orange-200 overflow-hidden">
          <div
            className="flex items-center gap-2 px-4 py-3 text-white"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            <Camera className="w-4 h-4" />
            <h3 className="font-bold text-sm">راهنمای ضبط ویدیو</h3>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {GUIDE_ITEMS.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.06 }}
                className="flex items-start gap-2.5 p-2.5 rounded-xl bg-orange-50/40"
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ background: `${item.color}1a` }}
                >
                  <item.icon className="w-4 h-4" style={{ color: item.color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900">{item.title}</p>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="px-4 pb-3">
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-2.5 flex items-start gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-[11px] text-amber-700 leading-relaxed">
                ویدیوی باکیفیت‌تر، آنالیز دقیق‌تری به شما می‌دهد. هر سه زاویه را در یک فایل یا فایل‌های جداگانه آپلود کنید.
              </p>
            </div>
          </div>
        </div>

        {!file && (
          <label className="block">
            <div className="glass rounded-3xl border-2 border-dashed border-border hover:border-primary/50 transition p-10 text-center cursor-pointer">
              <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 2, repeat: Infinity }} className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-primary" />
              </motion.div>
              <p className="font-bold mb-1">ویدیو را اینجا بکش یا کلیک کن</p>
              <p className="text-xs text-muted-foreground">فرمت: MP4, MOV, WebM — حداکثر ۱۰ مگابایت</p>
            </div>
            <input type="file" accept="video/*" className="hidden" onChange={handleFile} />
          </label>
        )}

        {file && !result && (
          <div className="space-y-3">
            <div className="glass rounded-2xl overflow-hidden">
              <video src={videoUrl} controls className="w-full max-h-64" />
              <div className="p-3 flex items-center justify-between">
                <p className="text-xs text-muted-foreground truncate">{file.name}</p>
                <button onClick={reset} className="text-xs text-destructive flex items-center gap-1">
                  <RefreshCw className="w-3.5 h-3.5" /> تغییر
                </button>
              </div>
            </div>
            <Button onClick={analyze} disabled={analyzing} className="w-full rounded-xl h-12 font-bold">
              {analyzing ? (
                <span className="flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> در حال آنالیز هوشمند...</span>
              ) : (
                <span className="flex items-center gap-2"><Sparkles className="w-4 h-4" /> شروع آنالیز ویدیو</span>
              )}
            </Button>
          </div>
        )}

        {analyzing && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
            <div className="space-y-2">
              {["بررسی فرم بدن...", "آنالیز تقارن...", "بررسی تکنیک حرکت...", "تولید توصیه‌ها..."].map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.7 }}
                  className="flex items-center gap-2 text-sm"
                >
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  {s}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {result && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            {/* Score */}
            <div className="glass rounded-2xl p-5 text-center">
              <p className="text-xs text-muted-foreground mb-2">امتیاز فرم بدن</p>
              <div className="relative w-24 h-24 mx-auto mb-2">
                <svg className="w-24 h-24 -rotate-90" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="15" fill="none" stroke="currentColor" strokeWidth="3" className="text-muted/30" />
                  <motion.circle cx="18" cy="18" r="15" fill="none" stroke="#F4C542" strokeWidth="3"
                    strokeDasharray={`${(result.score / 100) * 94.2} 94.2`} strokeLinecap="round"
                    initial={{ strokeDasharray: "0 94.2" }} animate={{ strokeDasharray: `${(result.score / 100) * 94.2} 94.2` }}
                    style={{ filter: "drop-shadow(0 0 4px #F4C54280)" }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-2xl font-black gradient-text">{toPersianDigits(result.score)}</div>
              </div>
              <p className="text-sm font-bold">وضعیت فرم: {result.posture}</p>
              <p className="text-xs text-muted-foreground">تقارن بدن: {toPersianDigits(result.symmetry)}٪</p>
            </div>

            {/* Issues */}
            <div className="glass rounded-2xl p-4">
              <h4 className="font-bold text-sm flex items-center gap-2 mb-2"><AlertCircle className="w-4 h-4 text-amber-500" /> نقاط قابل بهبود</h4>
              <ul className="space-y-1.5">
                {result.issues.map((issue: string, i: number) => (
                  <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" /> {issue}
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommendations */}
            <div className="glass rounded-2xl p-4">
              <h4 className="font-bold text-sm flex items-center gap-2 mb-2"><Sparkles className="w-4 h-4 text-primary" /> توصیه‌های تخصصی</h4>
              <ul className="space-y-1.5">
                {result.recommendations.map((rec: string, i: number) => (
                  <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" /> {rec}
                  </li>
                ))}
              </ul>
            </div>

            <Button onClick={reset} variant="outline" className="w-full rounded-xl">
              <RefreshCw className="w-4 h-4" /> آنالیز ویدیوی جدید
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
