import { db } from "@/lib/db";

/**
 * HeadCodeInjector — Server Component
 *
 * Fetches active HeadCode entries from the DB directly (server-side) and renders
 * the raw HTML/script tags via `dangerouslySetInnerHTML` at the requested placement.
 *
 * Used inside the root layout's `<head>`, at the start of `<body>`, and at the end
 * of `<body>` to inject analytics tags (GA4, Search Console, Meta Pixel, etc.)
 * server-side for SEO and performance.
 *
 * @prop placement — "head" | "body_start" | "body_end"
 */
export async function HeadCodeInjector({
  placement,
}: {
  placement: "head" | "body_start" | "body_end";
}) {
  // Fetch data outside of any try/catch so we never construct JSX inside one.
  let codes: { code: string }[] = [];
  try {
    codes = await db.headCode.findMany({
      where: { isActive: true, placement },
      orderBy: [{ createdAt: "asc" }],
      select: { code: true },
    });
  } catch {
    // Never crash the layout for analytics code — render nothing on failure.
    return null;
  }

  if (codes.length === 0) return null;

  // Concatenate all code blocks for this placement with safe separators.
  const combined = codes.map((c) => c.code).join("\n");

  return (
    <div
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: combined }}
      suppressHydrationWarning
    />
  );
}
