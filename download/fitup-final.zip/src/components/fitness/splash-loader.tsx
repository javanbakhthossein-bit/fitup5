"use client";

import { motion } from "framer-motion";
import { Dumbbell } from "lucide-react";

export function SplashLoader() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 1.5, repeat: Infinity }}
        className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center shadow-2xl glow-primary mb-6"
      >
        <Dumbbell className="w-10 h-10 text-white" strokeWidth={2.5} />
      </motion.div>
      <div className="flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="typing-dot w-2.5 h-2.5 rounded-full bg-primary"
          />
        ))}
      </div>
    </div>
  );
}
