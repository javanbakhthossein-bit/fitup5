"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Dumbbell, Sparkles, ChevronLeft, TrendingUp, Target,
  Activity, AlertCircle, CheckCircle2, Crown,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  toPersianDigits, GOAL_LABELS, ACTIVITY_LABELS,
  GENDER_LABELS, PLAN_LABELS, SUBSCRIPTION_PLANS,
  formatToman, type OnboardingData,
} from "@/lib/fitness/types";
import { toast } from "sonner";

export function AnalysisScreen() {
  const { user, setScreen, setMainTab } = useAppStore();
  const [analysis, setAnalysis] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [bmi, setBmi] = useState<number>(0);
  const [bmr, setBmr] = useState<number>(0);
  const [tdee, setTdee] = useState<number>(0);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/onboarding/analysis");
        const data = await res.json();
        if (data.analysis) {
          setAnalysis(data.analysis);
          setBmi(data.bmi || 0);
          setBmr(data.bmr || 0);
          setTdee(data.tdee || 0);
        }
      } catch (e) {
        // Fallback analysis
        setAnalysis("تحلیل در حال آماده‌سازی است...");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const bmiCategory = bmi < 18.5 ? "کم‌وزن" : bmi < 25 ? "وزن نرمال" : bmi < 30 ? "اضافه‌وزن" : "چاق";
  const bmiColor = bmi < 18.5 ? "text-cyan-500" : bmi < 25 ? "text-emerald-500" : bmi < 30 ? "text-amber-500" : "text-red-500";

  return (
    <div className="min-h-screen bg-white overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur-lg border-b border-orange-100 px-4 py-3 flex items-center justify-between">
        <button onClick={() => setScreen("landing")} className="p-2 rounded-lg hover:bg-orange-50">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Dumbbell className="w-4 h-4 text-white" />
          </div>
          <span className="font-black text-slate-900">فیتاپ</span>
        </div>
        <div className="w-9" />
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 mb-2">
            تحلیل اختصاصی شما
          </h1>
          <p className="text-sm text-slate-500">
            {user?.name ? `${user.name} عزیز، ` : ""}فیتاپ هوشمند اطلاعات شما را تحلیل کرد
          </p>
        </motion.div>

        {/* Biometric cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-3"
        >
          <Card className="p-4 text-center border-2 border-orange-100">
            <p className="text-[10px] text-slate-500">شاخص BMI</p>
            <p className={`text-2xl font-black font-stat ${bmiColor}`}>{toPersianDigits(bmi.toFixed(1))}</p>
            <p className={`text-[10px] font-bold ${bmiColor}`}>{bmiCategory}</p>
          </Card>
          <Card className="p-4 text-center border-2 border-orange-100">
            <p className="text-[10px] text-slate-500">متابولیسم (BMR)</p>
            <p className="text-2xl font-black font-stat text-slate-900">{toPersianDigits(bmr)}</p>
            <p className="text-[10px] text-slate-400">کیلوکالری</p>
          </Card>
          <Card className="p-4 text-center border-2 border-orange-100">
            <p className="text-[10px] text-slate-500">کالری روزانه (TDEE)</p>
            <p className="text-2xl font-black font-stat text-slate-900">{toPersianDigits(tdee)}</p>
            <p className="text-[10px] text-slate-400">کیلوکالری</p>
          </Card>
        </motion.div>

        {/* AI Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-5 border-2 border-orange-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <h3 className="font-bold text-slate-900">تحلیل فیتاپ هوشمند</h3>
            </div>
            {loading ? (
              <div className="space-y-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="h-3 bg-orange-100 rounded animate-pulse" style={{ width: `${90 - i * 10}%` }} />
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">{analysis}</p>
            )}
          </Card>
        </motion.div>

        {/* Action buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3 pt-2"
        >
          <p className="text-center text-sm font-bold text-slate-700">مسیر بعدی شما؟</p>

          {/* Buy plan */}
          <button
            onClick={() => { setMainTab("plans"); setScreen("main"); }}
            className="w-full p-5 rounded-2xl text-white shadow-lg transition hover:scale-[1.02] flex items-center gap-4"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Crown className="w-6 h-6" />
            </div>
            <div className="flex-1 text-right">
              <p className="font-black text-base">انتخاب و خرید پلن</p>
              <p className="text-xs opacity-90">برای دریافت برنامه اختصاصی، پلن مناسب خود را انتخاب کنید</p>
            </div>
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Go to dashboard */}
          <button
            onClick={() => { setMainTab("dashboard"); setScreen("main"); }}
            className="w-full p-5 rounded-2xl border-2 border-orange-200 bg-white text-slate-700 shadow-sm transition hover:scale-[1.02] hover:border-orange-300 flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-orange-50 flex items-center justify-center shrink-0">
              <TrendingUp className="w-6 h-6 text-orange-500" />
            </div>
            <div className="flex-1 text-right">
              <p className="font-black text-base">رفتن به داشبورد</p>
              <p className="text-xs text-slate-500">از ابزارهای رایگان و امکانات پنل استفاده کنید</p>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-400" />
          </button>
        </motion.div>
      </div>
    </div>
  );
}
