"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Search, Calendar, Clock, Eye, ArrowLeft, Sparkles, TrendingUp } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits } from "@/lib/fitness/types";
import { NikaWidget } from "../nika-widget";

interface ArticleListItem {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  category: string;
  tags: string;
  status: string;
  authorName: string;
  coverImage: string;
  views: number;
  createdAt: string;
}

const CATEGORIES = [
  { value: "", label: "همه" },
  { value: "training", label: "تمرین" },
  { value: "nutrition", label: "تغذیه" },
  { value: "motivation", label: "انگیزشی" },
  { value: "general", label: "عمومی" },
];

const CATEGORY_COLORS: Record<string, string> = {
  general: "bg-slate-100 text-slate-600",
  nutrition: "bg-emerald-100 text-emerald-700",
  training: "bg-orange-100 text-orange-700",
  motivation: "bg-purple-100 text-purple-700",
  news: "bg-blue-100 text-blue-700",
};

export function ArticlesPage() {
  const { setScreen, setArticleSlug } = useAppStore();
  const [articles, setArticles] = useState<ArticleListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams({ pageSize: "12", page: String(page) });
        if (category) params.set("category", category);
        if (search) params.set("search", search);
        const res = await fetch(`/api/articles?${params}`);
        const data = await res.json();
        setArticles(data.articles || []);
        setTotal(data.total || 0);
        setTotalPages(data.totalPages || 1);
      } catch {} finally { setLoading(false); }
    })();
  }, [search, category, page]);

  function openArticle(slug: string) {
    setArticleSlug(slug);
    setScreen("article");
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <button onClick={() => setScreen("landing")} className="flex items-center gap-1 text-sm text-slate-600 hover:text-orange-600 transition">
            <ArrowLeft className="w-4 h-4" />
            صفحه اصلی
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
              <span className="text-white font-black text-xs">ف</span>
            </div>
            <span className="font-black text-sm text-slate-900">مجله فیتاپ</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="relative overflow-hidden border-b border-orange-100">
        <div className="absolute -top-20 -left-20 w-64 h-64 rounded-full bg-orange-100 blur-3xl opacity-50" />
        <div className="absolute -bottom-20 -right-20 w-64 h-64 rounded-full bg-amber-100 blur-3xl opacity-50" />
        <div className="max-w-5xl mx-auto px-4 py-10 relative">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <span className="inline-flex items-center gap-1.5 text-[11px] px-3 py-1 rounded-full bg-orange-100 text-orange-600 font-bold mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              مجله تخصصی فیتاپ
            </span>
            <h1 className="text-3xl md:text-4xl font-black text-slate-900 mb-2">
              مقالات تخصصی <span style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent" }}>بدنسازی و تغذیه</span>
            </h1>
            <p className="text-sm text-slate-500 max-w-xl mx-auto">
              جامع‌ترین مرجع برنامه بدنسازی، برنامه تغذیه، مکمل‌های ورزشی و کاهش وزن به زبان فارسی — توسط مربیان هوشمند فیتاپ
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Search + filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="جستجو در مقالات..."
              className="pr-10 rounded-xl"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {CATEGORIES.map((c) => (
              <button
                key={c.value}
                onClick={() => { setCategory(c.value); setPage(1); }}
                className={`shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition ${
                  category === c.value
                    ? "text-white shadow-md"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
                style={category === c.value ? { background: "linear-gradient(135deg, #f59e0b, #f97316)" } : {}}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results count */}
        <div className="text-xs text-slate-500 mb-4 flex items-center gap-1">
          <TrendingUp className="w-3.5 h-3.5" />
          {toPersianDigits(total)} مقاله یافت شد
        </div>

        {/* Articles grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-72 rounded-2xl" />
            ))}
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-3">
              <Search className="w-8 h-8 text-slate-400" />
            </div>
            <p className="text-slate-500">مقاله‌ای یافت نشد</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {articles.map((a, i) => (
              <motion.button
                key={a.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => openArticle(a.slug)}
                className="text-right group"
              >
                <Card className="overflow-hidden border-2 border-slate-100 hover:border-orange-300 transition-all hover:shadow-xl h-full flex flex-col">
                  {a.coverImage ? (
                    <div className="h-44 overflow-hidden relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={a.coverImage} alt={a.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <span className={`absolute top-2 right-2 text-[10px] px-2 py-1 rounded-full font-bold ${CATEGORY_COLORS[a.category] || CATEGORY_COLORS.general}`}>
                        {CATEGORIES.find((c) => c.value === a.category)?.label || a.category}
                      </span>
                    </div>
                  ) : (
                    <div className="h-44 bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center">
                      <Sparkles className="w-10 h-10 text-orange-300" />
                    </div>
                  )}
                  <div className="p-4 flex-1 flex flex-col">
                    <h3 className="font-bold text-slate-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition">
                      {a.title}
                    </h3>
                    {a.excerpt && (
                      <p className="text-xs text-slate-500 line-clamp-2 mb-3 flex-1">{a.excerpt}</p>
                    )}
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-50">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(a.createdAt).toLocaleDateString("fa-IR")}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {toPersianDigits(a.views)}
                      </span>
                    </div>
                  </div>
                </Card>
              </motion.button>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8">
            <Button
              variant="outline"
              size="sm"
              disabled={page === 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="rounded-xl"
            >
              قبلی
            </Button>
            <span className="text-sm text-slate-600 px-3">
              {toPersianDigits(page)} از {toPersianDigits(totalPages)}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page === totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="rounded-xl"
            >
              بعدی
            </Button>
          </div>
        )}
      </div>

      <NikaWidget />
    </div>
  );
}
