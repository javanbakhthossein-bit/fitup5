"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Clock, Eye, Calendar, Share2, ChevronLeft, Sparkles } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits } from "@/lib/fitness/types";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { NikaWidget } from "../nika-widget";

interface ArticleData {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  status: string;
  authorName: string;
  coverImage: string;
  views: number;
  readingMinutes: number;
  seoTitle?: string;
  seoDescription?: string;
  metaKeywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  robots?: string;
  createdAt: string;
  updatedAt: string;
}

const CATEGORY_LABELS: Record<string, string> = {
  general: "عمومی",
  nutrition: "تغذیه",
  training: "تمرین",
  motivation: "انگیزشی",
  news: "اخبار",
};

const CATEGORY_COLORS: Record<string, string> = {
  general: "bg-slate-100 text-slate-600",
  nutrition: "bg-emerald-100 text-emerald-700",
  training: "bg-orange-100 text-orange-700",
  motivation: "bg-purple-100 text-purple-700",
  news: "bg-blue-100 text-blue-700",
};

export function ArticlePage() {
  const { articleSlug, setScreen, setArticleSlug } = useAppStore();
  const [article, setArticle] = useState<ArticleData | null>(null);
  const [related, setRelated] = useState<ArticleData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!articleSlug) {
      setScreen("articles");
      return;
    }
    (async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/articles/${articleSlug}`);
        const data = await res.json();
        if (res.ok && data.article) {
          setArticle(data.article);
          // fetch related articles (same category)
          const relRes = await fetch(`/api/articles?pageSize=4&category=${data.article.category}`);
          const relData = await relRes.json();
          setRelated((relData.articles || []).filter((a: ArticleData) => a.slug !== articleSlug).slice(0, 3));
          // --- SEO: dynamically set meta tags ---
          const a = data.article;
          document.title = (a.seoTitle || a.title) + " | فیتاپ";
          setMetaTag("description", a.seoDescription || a.excerpt || "");
          setMetaTag("keywords", a.metaKeywords || a.tags || "");
          setMetaTag("robots", a.robots || "index,follow");
          if (a.canonicalUrl) setLinkTag("canonical", a.canonicalUrl);
          // Open Graph
          setMetaProp("og:title", a.seoTitle || a.title);
          setMetaProp("og:description", a.seoDescription || a.excerpt || "");
          setMetaProp("og:type", "article");
          setMetaProp("og:image", a.ogImage || a.coverImage || "");
          // Twitter Card
          setMetaProp("twitter:card", "summary_large_image");
          setMetaProp("twitter:title", a.seoTitle || a.title);
          setMetaProp("twitter:description", a.seoDescription || a.excerpt || "");
          setMetaProp("twitter:image", a.ogImage || a.coverImage || "");
          // JSON-LD Article schema
          setJsonLd("article-schema", {
            "@context": "https://schema.org",
            "@type": "Article",
            headline: a.title,
            description: a.seoDescription || a.excerpt || "",
            image: a.ogImage || a.coverImage || "",
            datePublished: a.createdAt,
            dateModified: a.updatedAt,
            author: { "@type": "Organization", name: a.authorName || "فیتاپ" },
            publisher: { "@type": "Organization", name: "فیتاپ" },
          });
        } else {
          toast.error("مقاله یافت نشد");
          setScreen("articles");
        }
      } catch {
        toast.error("خطا در بارگذاری مقاله");
        setScreen("articles");
      } finally {
        setLoading(false);
      }
    })();
    // scroll to top on article change
    window.scrollTo({ top: 0, behavior: "smooth" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [articleSlug]);

  // Helper: set meta tag by name
  function setMetaTag(name: string, content: string) {
    if (!content) return;
    let el = document.querySelector(`meta[name="${name}"]`);
    if (!el) {
      el = document.createElement("meta");
      el.setAttribute("name", name);
      document.head.appendChild(el);
    }
    el.setAttribute("content", content);
  }
  // Helper: set meta tag by property (og:*, twitter:*)
  function setMetaProp(prop: string, content: string) {
    if (!content) return;
    let el = document.querySelector(`meta[property="${prop}"]`);
    if (!el) {
      el = document.createElement("meta");
      el.setAttribute("property", prop);
      document.head.appendChild(el);
    }
    el.setAttribute("content", content);
  }
  // Helper: set link tag (canonical)
  function setLinkTag(rel: string, href: string) {
    let el = document.querySelector(`link[rel="${rel}"]`);
    if (!el) {
      el = document.createElement("link");
      el.setAttribute("rel", rel);
      document.head.appendChild(el);
    }
    el.setAttribute("href", href);
  }
  // Helper: set JSON-LD structured data
  function setJsonLd(id: string, data: any) {
    let el = document.getElementById(id) as HTMLScriptElement | null;
    if (!el) {
      el = document.createElement("script");
      el.id = id;
      el.type = "application/ld+json";
      document.head.appendChild(el);
    }
    el.textContent = JSON.stringify(data);
  }

  function goBack() {
    setArticleSlug(null);
    setScreen("articles");
  }

  function openArticle(slug: string) {
    setArticleSlug(slug);
  }

  function shareArticle() {
    if (!article) return;
    const url = `${window.location.origin}/?article=${article.slug}`;
    if (navigator.share) {
      navigator.share({ title: article.title, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url);
      toast.success("لینک مقاله کپی شد ✓");
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <ArticleTopNav onBack={goBack} />
        <div className="max-w-3xl mx-auto px-4 py-8">
          <Skeleton className="h-8 rounded-xl mb-4" />
          <Skeleton className="h-64 rounded-2xl mb-6" />
          <Skeleton className="h-4 rounded mb-3" />
          <Skeleton className="h-4 rounded mb-3" />
          <Skeleton className="h-4 rounded mb-3" />
        </div>
      </div>
    );
  }

  if (!article) return null;

  return (
    <div className="min-h-screen bg-white">
      <ArticleTopNav onBack={goBack} />

      <article className="max-w-3xl mx-auto px-4 py-6">
        {/* Category + meta */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <span className={`text-[11px] px-3 py-1 rounded-full font-bold ${CATEGORY_COLORS[article.category] || CATEGORY_COLORS.general}`}>
            {CATEGORY_LABELS[article.category] || article.category}
          </span>
          <span className="flex items-center gap-1 text-[11px] text-slate-500">
            <Calendar className="w-3.5 h-3.5" />
            {new Date(article.createdAt).toLocaleDateString("fa-IR")}
          </span>
          <span className="flex items-center gap-1 text-[11px] text-slate-500">
            <Clock className="w-3.5 h-3.5" />
            {toPersianDigits(article.readingMinutes || 3)} دقیقه مطالعه
          </span>
          <span className="flex items-center gap-1 text-[11px] text-slate-500">
            <Eye className="w-3.5 h-3.5" />
            {toPersianDigits(article.views)} بازدید
          </span>
        </div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-black text-slate-900 mb-3 leading-tight"
        >
          {article.title}
        </motion.h1>

        {/* Excerpt */}
        {article.excerpt && (
          <p className="text-base text-slate-600 mb-6 leading-relaxed">{article.excerpt}</p>
        )}

        {/* Cover image */}
        {article.coverImage && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-2xl overflow-hidden mb-6 shadow-lg"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={article.coverImage} alt={article.title} className="w-full h-64 md:h-80 object-cover" />
          </motion.div>
        )}

        {/* Author + share */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-orange-50/50 border border-orange-100 mb-6">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
              {article.authorName?.charAt(0) || "ف"}
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">{article.authorName}</p>
              <p className="text-[10px] text-slate-500">نویسنده فیتاپ</p>
            </div>
          </div>
          <Button size="sm" variant="ghost" onClick={shareArticle} className="rounded-xl gap-1.5 text-xs">
            <Share2 className="w-4 h-4" />
            اشتراک‌گذاری
          </Button>
        </div>

        {/* Content — internal links render as buttons that navigate */}
        <div className="prose prose-slate max-w-none article-content">
          <ReactMarkdown
            components={{
              h1: ({ ...p }) => <h2 className="text-2xl font-black text-slate-900 mt-8 mb-4" {...p} />,
              h2: ({ ...p }) => <h2 className="text-xl font-black text-slate-900 mt-7 mb-3" {...p} />,
              h3: ({ ...p }) => <h3 className="text-lg font-bold text-slate-900 mt-6 mb-2" {...p} />,
              p: ({ ...p }) => <p className="text-slate-700 leading-8 mb-4 text-[15px]" {...p} />,
              ul: ({ ...p }) => <ul className="list-disc pr-6 mb-4 space-y-1.5 text-slate-700" {...p} />,
              ol: ({ ...p }) => <ol className="list-decimal pr-6 mb-4 space-y-1.5 text-slate-700" {...p} />,
              li: ({ ...p }) => <li className="text-[15px] leading-7" {...p} />,
              blockquote: ({ ...p }) => <blockquote className="border-r-4 border-orange-400 bg-orange-50/50 p-4 rounded-l-xl my-4 text-slate-700 italic" {...p} />,
              a: ({ href, children }) => {
                // internal link like /article/slug or /auth
                if (href && href.startsWith("/article/")) {
                  const slug = href.replace("/article/", "");
                  return (
                    <button
                      onClick={() => openArticle(slug)}
                      className="text-orange-600 underline hover:text-orange-700 font-medium"
                    >
                      {children}
                    </button>
                  );
                }
                if (href === "/auth") {
                  return (
                    <button
                      onClick={() => setScreen("auth")}
                      className="text-orange-600 underline hover:text-orange-700 font-medium"
                    >
                      {children}
                    </button>
                  );
                }
                return <a href={href} className="text-orange-600 underline hover:text-orange-700 font-medium" target="_blank" rel="noopener noreferrer">{children}</a>;
              },
              strong: ({ ...p }) => <strong className="font-bold text-slate-900" {...p} />,
              code: ({ ...p }) => <code className="bg-slate-100 text-orange-600 px-1.5 py-0.5 rounded text-sm font-mono" {...p} />,
              pre: ({ ...p }) => <pre className="bg-slate-900 text-slate-100 p-4 rounded-xl overflow-x-auto my-4 text-sm" {...p} />,
              table: ({ ...p }) => <table className="w-full border-collapse my-4 text-sm" {...p} />,
              th: ({ ...p }) => <th className="border border-slate-200 p-2 bg-slate-50 font-bold" {...p} />,
              td: ({ ...p }) => <td className="border border-slate-200 p-2" {...p} />,
              img: ({ src, alt }) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={typeof src === "string" ? src : ""} alt={alt || ""} className="rounded-xl my-4 w-full" />
              ),
            }}
          >
            {article.content}
          </ReactMarkdown>
        </div>

        {/* Tags */}
        {article.tags && (
          <div className="flex items-center gap-2 flex-wrap mt-8 pt-6 border-t border-slate-100">
            <span className="text-xs text-slate-400">تگ‌ها:</span>
            {article.tags.split(",").map((t, i) => (
              <span key={i} className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">#{t.trim()}</span>
            ))}
          </div>
        )}

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-8 p-6 rounded-2xl text-center text-white relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
        >
          <div className="absolute -top-8 -left-8 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
          <Sparkles className="w-8 h-8 mx-auto mb-2" />
          <h3 className="text-xl font-black mb-1">آماده‌ای شروع کنی؟</h3>
          <p className="text-sm text-white/90 mb-4">برنامه تمرینی و غذایی اختصاصی خودت را با فیتاپ هوشمند بساز</p>
          <Button
            onClick={() => setScreen("auth")}
            className="bg-white text-orange-600 hover:bg-white/90 rounded-xl font-bold"
          >
            شروع رایگان
          </Button>
        </motion.div>

        {/* Related articles */}
        {related.length > 0 && (
          <div className="mt-12">
            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-orange-500" />
              مقالات مرتبط
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {related.map((r) => (
                <button
                  key={r.id}
                  onClick={() => openArticle(r.slug)}
                  className="text-right group"
                >
                  <Card className="overflow-hidden border-2 border-orange-100 hover:border-orange-300 transition-all hover:shadow-lg">
                    {r.coverImage && (
                      <div className="h-32 overflow-hidden">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={r.coverImage} alt={r.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      </div>
                    )}
                    <div className="p-3">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${CATEGORY_COLORS[r.category]}`}>{CATEGORY_LABELS[r.category]}</span>
                      <h4 className="text-sm font-bold text-slate-900 mt-1.5 line-clamp-2 group-hover:text-orange-600 transition">{r.title}</h4>
                    </div>
                  </Card>
                </button>
              ))}
            </div>
          </div>
        )}
      </article>

      <NikaWidget />
    </div>
  );
}

function ArticleTopNav({ onBack }: { onBack: () => void }) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b">
      <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-slate-600 hover:text-orange-600 transition">
          <ChevronLeft className="w-4 h-4" />
          بازگشت به مقالات
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <span className="text-white font-black text-xs">ف</span>
          </div>
          <span className="font-black text-sm text-slate-900">مجله فیتاپ</span>
        </div>
      </div>
    </header>
  );
}
