"use client";

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Dumbbell,
  Apple,
  TrendingUp,
  MessageCircle,
  Crown,
  ClipboardList,
  Gift,
  Headphones,
} from "lucide-react";
import { useAppStore, type MainTab } from "@/lib/fitness/store";
import { DashboardView } from "@/components/fitness/views/dashboard-view";
import { ProgramsView } from "@/components/fitness/views/programs-view";
import { WorkoutsView } from "@/components/fitness/views/workouts-view";
import { NutritionView } from "@/components/fitness/views/nutrition-view";
import { ProgressView } from "@/components/fitness/views/progress-view";
import { ChatView } from "@/components/fitness/views/chat-view";
import { PlansView } from "@/components/fitness/views/plans-view";
import { ReferralView } from "@/components/fitness/views/referral-view";
import { SupportView } from "@/components/fitness/views/support-view";
import { ActiveWorkoutSession } from "@/components/fitness/views/active-workout-session";
import { GymModeView } from "@/components/fitness/views/gym-mode-view";
import { VideoAnalysisView } from "@/components/fitness/views/video-analysis-view";
import { BloodTestView } from "@/components/fitness/views/blood-test-view";
import { NotificationsOverlay } from "@/components/fitness/views/notifications-overlay";
import { ProfileOverlay } from "@/components/fitness/views/profile-overlay";
import { AdminOverlay } from "@/components/fitness/views/admin-overlay";
import { ExerciseDetailOverlay } from "@/components/fitness/views/exercise-detail-overlay";
import { TopBar } from "@/components/fitness/top-bar";
import { Sidebar } from "@/components/fitness/sidebar";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";

const NAV_ITEMS: { id: MainTab; label: string; icon: any }[] = [
  { id: "dashboard", label: "داشبورد", icon: LayoutDashboard },
  { id: "programs", label: "برنامه‌ها", icon: ClipboardList },
  { id: "workouts", label: "تمرینات", icon: Dumbbell },
  { id: "nutrition", label: "دستیار تغذیه", icon: Apple },
  { id: "progress", label: "پیشرفت", icon: TrendingUp },
  { id: "chat", label: "چت مربی", icon: MessageCircle },
  { id: "referral", label: "معرفی به دوست", icon: Gift },
  { id: "support", label: "پشتیبانی", icon: Headphones },
  { id: "plans", label: "اشتراک", icon: Crown },
];

export function MainApp() {
  const {
    mainTab,
    setMainTab,
    overlay,
    setOverlay,
    unreadCount,
    notifications,
    setNotifications,
    activeSession,
  } = useAppStore();

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/notifications");
        const data = await res.json();
        setNotifications(data.notifications || []);
      } catch {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="min-h-screen bg-white flex">
      {/* Desktop Sidebar */}
      <Sidebar navItems={NAV_ITEMS} />

      {/* Main column */}
      <div className="flex-1 flex flex-col min-w-0 lg:mr-72 bg-white">
        <TopBar />

        <main className="flex-1 overflow-hidden pb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={mainTab}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="h-full"
            >
              {mainTab === "dashboard" && <DashboardView />}
              {mainTab === "programs" && <ProgramsView />}
              {mainTab === "workouts" && <WorkoutsView />}
              {mainTab === "nutrition" && <NutritionView />}
              {mainTab === "progress" && <ProgressView />}
              {mainTab === "chat" && <ChatView />}
              {mainTab === "referral" && <ReferralView />}
              {mainTab === "support" && <SupportView />}
              {mainTab === "plans" && <PlansView />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Active workout session overlay (full-screen) */}
      <AnimatePresence>
        {activeSession && <ActiveWorkoutSession />}
      </AnimatePresence>

      {/* Sheet overlays */}
      <Sheet open={overlay === "notifications"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[85vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">اعلان‌ها</SheetTitle>
          <NotificationsOverlay />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "profile"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[90vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">پروفایل</SheetTitle>
          <ProfileOverlay />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "admin"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[95vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">پنل مدیریت</SheetTitle>
          <AdminOverlay />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "exerciseDetail"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[85vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">جزئیات حرکت</SheetTitle>
          <ExerciseDetailOverlay />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "gymMode"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[95vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">حالت باشگاه</SheetTitle>
          <GymModeView />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "videoAnalysis"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[90vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">تحلیل ویدیو</SheetTitle>
          <VideoAnalysisView />
        </SheetContent>
      </Sheet>
      <Sheet open={overlay === "bloodTest"} onOpenChange={(o) => !o && setOverlay(null)}>
        <SheetContent side="bottom" className="h-[90vh] p-0" dir="rtl">
          <SheetTitle className="sr-only">تست خون</SheetTitle>
          <BloodTestView />
        </SheetContent>
      </Sheet>
    </div>
  );
}
