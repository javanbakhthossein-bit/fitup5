"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calculator, Flame, Beef, Wheat, Droplet, Save, RefreshCw, Target, Activity } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toPersianDigits, GENDER_LABELS } from "@/lib/fitness/types";
import { toast } from "sonner";

type Gender = "male" | "female";
type ActivityLevel = "sedentary" | "light" | "moderate" | "active" | "very_active";
type Goal = "fast_loss" | "slow_loss" | "maintain" | "gain";

const ACTIVITY_FACTORS: Record<ActivityLevel, number> = {
  sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very_active: 1.9,
};

const ACTIVITY_LABELS: Record<ActivityLevel, string> = {
  sedentary: "بی‌تحرک (کار پشت میز)", light: "کم‌تحرک (۱-۳ روز ورزش)", moderate: "متوسط (۳-۵ روز ورزش)", active: "فعال (۶-۷ روز ورزش)", very_active: "بسیار فعال (ورزشکار حرفه‌ای)",
};

const GOAL_ADJUST: Record<Goal, number> = {
  fast_loss: -500, slow_loss: -250, maintain: 0, gain: 400,
};

const GOAL_LABELS: Record<Goal, string> = {
  fast_loss: "کاهش وزن سریع", slow_loss: "کاهش وزن آهسته", maintain: "تثبیت وزن", gain: "افزایش وزن",
};

const GOAL_MACROS: Record<Goal, { protein: number; carbs: number; fat: number }> = {
  fast_loss: { protein: 0.40, carbs: 0.30, fat: 0.30 },
  slow_loss: { protein: 0.35, carbs: 0.35, fat: 0.30 },
  maintain: { protein: 0.30, carbs: 0.40, fat: 0.30 },
  gain: { protein: 0.30, carbs: 0.45, fat: 0.25 },
};

// BMI categories — Persian label + color (Tailwind text color)
function getBmiCategory(bmi: number): { label: string; hexColor: string; bg: string } {
  if (bmi < 18.5) return { label: "کم‌وزن", hexColor: "#06b6d4", bg: "rgba(6,182,212,0.12)" };
  if (bmi < 25) return { label: "وزن نرمال", hexColor: "#10b981", bg: "rgba(16,185,129,0.12)" };
  if (bmi < 30) return { label: "اضافه‌وزن", hexColor: "#f59e0b", bg: "rgba(245,158,11,0.12)" };
  return { label: "چاق", hexColor: "#ef4444", bg: "rgba(239,68,68,0.12)" };
}

export function TdeeCalculator() {
  // Initialize state from localStorage using lazy initializers
  const savedData = typeof window !== "undefined" ? (() => {
    try {
      const saved = localStorage.getItem("fitap_tdee_data");
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  })() : null;

  const [age, setAge] = useState(savedData?.age || "");
  const [height, setHeight] = useState(savedData?.height || "");
  const [weight, setWeight] = useState(savedData?.weight || "");
  const [gender, setGender] = useState<Gender>(savedData?.gender || "male");
  const [activity, setActivity] = useState<ActivityLevel>(savedData?.activity || "moderate");
  const [goal, setGoal] = useState<Goal>(savedData?.goal || "maintain");
  const [result, setResult] = useState<{ bmr: number; tdee: number; targetCal: number; protein: number; carbs: number; fat: number; bmi: number } | null>(null);

  function calculate() {
    const a = Number(age), h = Number(height), w = Number(weight);
    if (!a || !h || !w || a < 10 || a > 100 || h < 100 || h > 250 || w < 30 || w > 300) {
      toast.error("لطفاً اطلاعات معتبر وارد کنید");
      return;
    }

    // Harris-Benedict formula
    let bmr: number;
    if (gender === "male") {
      bmr = 88.362 + (13.397 * w) + (4.799 * h) - (5.677 * a);
    } else {
      bmr = 447.593 + (9.247 * w) + (3.098 * h) - (4.330 * a);
    }

    const tdee = Math.round(bmr * ACTIVITY_FACTORS[activity]);
    const targetCal = Math.round(tdee + GOAL_ADJUST[goal]);
    const macros = GOAL_MACROS[goal];
    const protein = Math.round((targetCal * macros.protein) / 4);
    const carbs = Math.round((targetCal * macros.carbs) / 4);
    const fat = Math.round((targetCal * macros.fat) / 9);

    // BMI: weight (kg) / (height (m))^2
    const heightM = h / 100;
    const bmi = Math.round((w / (heightM * heightM)) * 10) / 10;

    setResult({ bmr: Math.round(bmr), tdee, targetCal, protein, carbs, fat, bmi });

    // Save to localStorage
    localStorage.setItem("fitap_tdee_data", JSON.stringify({ age, height, weight, gender, activity, goal }));
    toast.success("محاسبه انجام شد! 💪");
  }

  function reset() {
    setAge(""); setHeight(""); setWeight(""); setResult(null);
    localStorage.removeItem("fitap_tdee_data");
  }

  return (
    <div className="min-h-screen bg-white pt-20 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Calculator className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 mb-2">محاسبه‌گر کالری و TDEE</h1>
          <p className="text-sm text-slate-500">با فرمول علمی هریس-بندیکت، کالری روزانه، درشت‌مغذی‌ها و شاخص BMI خود را محاسبه کن</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Form */}
          <Card className="p-5 bg-white border-2" style={{ borderColor: "#fed7aa" }}>
            <h2 className="font-bold text-slate-900 mb-4">اطلاعات خود را وارد کنید</h2>
            <div className="space-y-4">
              {/* Gender */}
              <div>
                <Label className="mb-2 block text-slate-700">جنسیت</Label>
                <div className="grid grid-cols-2 gap-2">
                  {(["male", "female"] as const).map(g => (
                    <button key={g} onClick={() => setGender(g)} className={`p-3 rounded-xl border-2 transition font-bold text-sm ${gender === g ? "border-orange-500 bg-orange-50 text-orange-600" : "border-slate-200 text-slate-600"}`}>
                      {g === "male" ? "👨 آقا" : "👩 خانم"}
                    </button>
                  ))}
                </div>
              </div>
              {/* Age */}
              <div>
                <Label className="mb-2 block text-slate-700">سن (سال)</Label>
                <Input type="number" value={age} onChange={e => setAge(e.target.value)} placeholder="۲۵" className="rounded-xl text-center font-stat text-lg" />
              </div>
              {/* Height + Weight */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="mb-2 block text-slate-700">قد (cm)</Label>
                  <Input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="۱۷۵" className="rounded-xl text-center font-stat text-lg" />
                </div>
                <div>
                  <Label className="mb-2 block text-slate-700">وزن (kg)</Label>
                  <Input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="۷۵" className="rounded-xl text-center font-stat text-lg" />
                </div>
              </div>
              {/* Activity */}
              <div>
                <Label className="mb-2 block text-slate-700">سطح فعالیت روزانه</Label>
                <div className="space-y-1.5">
                  {(Object.keys(ACTIVITY_LABELS) as ActivityLevel[]).map(a => (
                    <button key={a} onClick={() => setActivity(a)} className={`w-full p-2.5 rounded-xl border-2 text-xs text-right transition ${activity === a ? "border-orange-500 bg-orange-50" : "border-slate-200"}`}>
                      <span className="font-bold text-slate-900">{ACTIVITY_LABELS[a]}</span>
                      <span className="text-slate-400 mr-2">×{ACTIVITY_FACTORS[a]}</span>
                    </button>
                  ))}
                </div>
              </div>
              {/* Goal */}
              <div>
                <Label className="mb-2 block text-slate-700">هدف</Label>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(GOAL_LABELS) as Goal[]).map(g => (
                    <button key={g} onClick={() => setGoal(g)} className={`p-2.5 rounded-xl border-2 text-xs font-bold transition ${goal === g ? "border-orange-500 bg-orange-50 text-orange-600" : "border-slate-200 text-slate-600"}`}>
                      {GOAL_LABELS[g]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={calculate} className="flex-1 rounded-xl text-white font-bold" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                  <Flame className="w-4 h-4" /> محاسبه
                </Button>
                <Button onClick={reset} variant="outline" className="rounded-xl">
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>

          {/* Results */}
          <div>
            <AnimatePresence mode="wait">
              {result ? (
                <motion.div key="result" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                  {/* Target calories */}
                  <Card className="p-5 text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                    <div className="flex items-center gap-2 mb-2"><Flame className="w-5 h-5" /><span className="text-sm">کالری هدف روزانه</span></div>
                    <p className="text-4xl font-black font-stat">{toPersianDigits(result.targetCal.toLocaleString("en-US"))}</p>
                    <p className="text-xs opacity-80 mt-1">کیلوکالری در روز</p>
                  </Card>

                  {/* BMR + TDEE */}
                  <div className="grid grid-cols-2 gap-3">
                    <Card className="p-4 bg-white border-2" style={{ borderColor: "#fed7aa" }}>
                      <p className="text-[10px] text-slate-500">BMR (متابولیسم پایه)</p>
                      <p className="text-2xl font-black font-stat text-slate-900">{toPersianDigits(result.bmr.toLocaleString("en-US"))}</p>
                      <p className="text-[10px] text-slate-400">کیلوکالری</p>
                    </Card>
                    <Card className="p-4 bg-white border-2" style={{ borderColor: "#fed7aa" }}>
                      <p className="text-[10px] text-slate-500">TDEE (مصرف کل)</p>
                      <p className="text-2xl font-black font-stat text-slate-900">{toPersianDigits(result.tdee.toLocaleString("en-US"))}</p>
                      <p className="text-[10px] text-slate-400">کیلوکالری</p>
                    </Card>
                  </div>

                  {/* BMI */}
                  <Card className="p-5 bg-white border-2" style={{ borderColor: "#fed7aa" }}>
                    <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-orange-500" /> شاخص توده بدنی (BMI)
                    </h3>
                    <BmiDisplay bmi={result.bmi} />
                  </Card>

                  {/* Macros */}
                  <Card className="p-5 bg-white border-2" style={{ borderColor: "#fed7aa" }}>
                    <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2"><Target className="w-4 h-4 text-orange-500" /> درشت‌مغذی‌ها</h3>
                    <div className="space-y-3">
                      <MacroBar icon={Beef} label="پروتئین" grams={result.protein} calories={result.protein * 4} total={result.targetCal} color="#f59e0b" />
                      <MacroBar icon={Wheat} label="کربوهیدرات" grams={result.carbs} calories={result.carbs * 4} total={result.targetCal} color="#06b6d4" />
                      <MacroBar icon={Droplet} label="چربی" grams={result.fat} calories={result.fat * 9} total={result.targetCal} color="#a855f7" />
                    </div>
                  </Card>

                  <div className="flex items-center gap-2 text-xs text-slate-400 p-2">
                    <Save className="w-3.5 h-3.5" />
                    اطلاعات شما در مرورگر ذخیره شد
                  </div>
                </motion.div>
              ) : (
                <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center h-full min-h-[300px] text-center">
                  <Flame className="w-16 h-16 text-slate-200 mb-3" />
                  <p className="text-sm text-slate-400">اطلاعات خود را وارد کن و روی «محاسبه» کلیک کن</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

function BmiDisplay({ bmi }: { bmi: number }) {
  const cat = getBmiCategory(bmi);
  // BMI scale: 15 to 40 mapped to 0-100%
  const scalePct = Math.max(0, Math.min(100, ((bmi - 15) / (40 - 15)) * 100));
  return (
    <div>
      <div className="flex items-end justify-between mb-3">
        <div>
          <p className="text-3xl font-black font-stat text-slate-900">{toPersianDigits(bmi.toFixed(1))}</p>
          <p className="text-[10px] text-slate-400">kg/m²</p>
        </div>
        <div
          className="px-3 py-1.5 rounded-full text-xs font-bold"
          style={{ background: cat.bg, color: cat.hexColor }}
        >
          {cat.label}
        </div>
      </div>
      {/* BMI scale bar */}
      <div className="relative h-2.5 rounded-full overflow-hidden" style={{
        background: "linear-gradient(to left, #06b6d4 0%, #06b6d4 14%, #10b981 14%, #10b981 40%, #f59e0b 40%, #f59e0b 60%, #ef4444 60%, #ef4444 100%)"
      }}>
        {/* Marker for current BMI */}
        <motion.div
          initial={{ left: "0%" }}
          animate={{ left: `${scalePct}%` }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-white border-2 border-slate-800 shadow-md"
        />
      </div>
      <div className="flex justify-between text-[10px] text-slate-400 mt-2">
        <span>کم‌وزن &lt; ۱۸.۵</span>
        <span>نرمال ۱۸.۵-۲۵</span>
        <span>اضافه‌وزن ۲۵-۳۰</span>
        <span>چاق &gt; ۳۰</span>
      </div>
    </div>
  );
}

function MacroBar({ icon: Icon, label, grams, calories, total, color }: { icon: any; label: string; grams: number; calories: number; total: number; color: string }) {
  const pct = Math.round((calories / total) * 100);
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <Icon className="w-4 h-4" style={{ color }} />
          <span className="text-sm font-bold text-slate-700">{label}</span>
        </div>
        <div className="text-left">
          <span className="text-sm font-black font-stat text-slate-900">{toPersianDigits(grams)}g</span>
          <span className="text-[10px] text-slate-400 mr-1">({toPersianDigits(pct)}٪)</span>
        </div>
      </div>
      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
        <motion.div className="h-full rounded-full" style={{ background: color, width: `${pct}%` }} initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.6 }} />
      </div>
    </div>
  );
}
