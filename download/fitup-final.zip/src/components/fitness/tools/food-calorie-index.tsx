"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Flame, Beef, Wheat, Droplet, Apple } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits } from "@/lib/fitness/types";

interface Food {
  id: string; name: string; category: string;
  calories: number; protein: number; carbs: number; fat: number;
  servingSize: string;
}

const FOOD_GROUPS = [
  { id: "all", label: "همه", icon: "🍽️" },
  { id: "breakfast", label: "صبحانه", icon: "🍳" },
  { id: "lunch", label: "ناهار", icon: "🍱" },
  { id: "dinner", label: "شام", icon: "🍽️" },
  { id: "snack", label: "میان‌وعده", icon: "🍎" },
];

export function FoodCalorieIndex() {
  const [foods, setFoods] = useState<Food[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [selected, setSelected] = useState<Food | null>(null);
  const [weight, setWeight] = useState(100);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (search) params.set("search", search);
        if (category !== "all") params.set("category", category);
        const res = await fetch(`/api/foods?${params}`);
        const data = await res.json();
        setFoods(data.foods || []);
      } catch {} finally { setLoading(false); }
    })();
  }, [search, category]);

  return (
    <div className="min-h-screen bg-white pt-20 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Apple className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 mb-2">جدول کالری غذاها</h1>
          <p className="text-sm text-slate-500">جستجو در بانک مواد غذایی با محاسبه‌گر داینامیک ارزش غذایی</p>
        </div>

        {/* Search + groups */}
        <div className="space-y-3 mb-6">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی غذا..." className="pr-10 rounded-xl border-2" style={{ borderColor: "#fed7aa" }} />
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {FOOD_GROUPS.map(g => (
              <button key={g.id} onClick={() => setCategory(g.id)} className={`shrink-0 px-4 py-2 rounded-xl text-sm font-bold transition ${category === g.id ? "text-white shadow-md" : "bg-slate-100 text-slate-600"}`} style={category === g.id ? { background: "linear-gradient(135deg, #f59e0b, #f97316)" } : {}}>
                <span className="ml-1">{g.icon}</span>{g.label}
              </button>
            ))}
          </div>
        </div>

        <p className="text-xs text-slate-400 mb-3">{toPersianDigits(foods.length)} ماده غذایی یافت شد</p>

        {/* Food list */}
        {loading ? (
          <div className="space-y-2">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
        ) : foods.length === 0 ? (
          <div className="text-center py-12">
            <Apple className="w-16 h-16 mx-auto mb-3 text-slate-200" />
            <p className="text-sm text-slate-400">ماده غذایی یافت نشد</p>
          </div>
        ) : (
          <div className="space-y-2">
            {foods.map((food, i) => (
              <motion.button
                key={food.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                onClick={() => { setSelected(food); setWeight(100); }}
                className="w-full flex items-center justify-between p-3 rounded-xl border-2 hover:shadow-md transition text-right"
                style={{ borderColor: "#fed7aa", background: "#fff" }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(245,158,11,0.1)" }}>
                    <Apple className="w-5 h-5 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-bold text-sm text-slate-900">{food.name}</p>
                    <p className="text-[10px] text-slate-400">{food.servingSize}</p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-black font-stat text-slate-900">{toPersianDigits(food.calories)}</p>
                  <p className="text-[10px] text-slate-400">کالری/۱۰۰گ</p>
                </div>
              </motion.button>
            ))}
          </div>
        )}

        {/* Detail modal with dynamic calculator */}
        <AnimatePresence>
          {selected && (
            <FoodDetailModal food={selected} weight={weight} setWeight={setWeight} onClose={() => setSelected(null)} />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function FoodDetailModal({ food, weight, setWeight, onClose }: { food: Food; weight: number; setWeight: (n: number) => void; onClose: () => void }) {
  const ratio = weight / 100;
  const calories = Math.round(food.calories * ratio);
  const protein = (food.protein * ratio).toFixed(1);
  const carbs = (food.carbs * ratio).toFixed(1);
  const fat = (food.fat * ratio).toFixed(1);

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[90] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden"
        style={{ border: "2px solid #fed7aa" }}
      >
        {/* Header */}
        <div className="p-5 text-center text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
          <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center mx-auto mb-2">
            <Apple className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-black">{food.name}</h2>
          <p className="text-xs opacity-80">{food.servingSize}</p>
        </div>

        <div className="p-5 space-y-4">
          {/* Weight slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-slate-700">وزن ماده غذایی</label>
              <span className="font-black font-stat text-orange-600 text-lg">{toPersianDigits(weight)} گرم</span>
            </div>
            <input
              type="range" min="10" max="500" step="10" value={weight}
              onChange={e => setWeight(Number(e.target.value))}
              className="w-full accent-orange-500"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>۱۰گ</span><span>۲۵۰گ</span><span>۵۰۰گ</span>
            </div>
          </div>

          {/* Calories */}
          <div className="p-4 rounded-2xl text-center" style={{ background: "rgba(245,158,11,0.08)" }}>
            <div className="flex items-center justify-center gap-1.5 mb-1"><Flame className="w-4 h-4 text-orange-500" /><span className="text-xs text-slate-600">کالری</span></div>
            <p className="text-3xl font-black font-stat text-slate-900">{toPersianDigits(calories)}</p>
            <p className="text-[10px] text-slate-400">کیلوکالری</p>
          </div>

          {/* Macros */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 rounded-xl text-center" style={{ background: "rgba(245,158,11,0.08)" }}>
              <Beef className="w-4 h-4 mx-auto mb-1 text-orange-500" />
              <p className="font-black font-stat text-slate-900">{toPersianDigits(protein)}</p>
              <p className="text-[9px] text-slate-400">پروتئین (g)</p>
            </div>
            <div className="p-3 rounded-xl text-center" style={{ background: "rgba(6,182,212,0.08)" }}>
              <Wheat className="w-4 h-4 mx-auto mb-1 text-cyan-500" />
              <p className="font-black font-stat text-slate-900">{toPersianDigits(carbs)}</p>
              <p className="text-[9px] text-slate-400">کربو (g)</p>
            </div>
            <div className="p-3 rounded-xl text-center" style={{ background: "rgba(168,85,247,0.08)" }}>
              <Droplet className="w-4 h-4 mx-auto mb-1 text-purple-500" />
              <p className="font-black font-stat text-slate-900">{toPersianDigits(fat)}</p>
              <p className="text-[9px] text-slate-400">چربی (g)</p>
            </div>
          </div>

          <p className="text-[10px] text-slate-400 text-center">ارزش غذایی بر اساس {toPersianDigits(weight)} گرم محاسبه شده است</p>
        </div>
      </motion.div>
    </motion.div>
  );
}
