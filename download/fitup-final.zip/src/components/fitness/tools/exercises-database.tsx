"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dumbbell, Search, Filter, X, AlertTriangle, Info, Check, Youtube } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits } from "@/lib/fitness/types";

interface Exercise {
  id: string; name: string; muscle: string; category: string;
  equipment: string; description: string; tips: string;
  mediaUrl: string; youtubeUrl?: string; difficulty: string;
}

const MUSCLE_GROUPS = [
  { id: "all", label: "همه", icon: "💪" },
  { id: "سینه", label: "سینه", icon: "🏋️" },
  { id: "پشت", label: "پشت", icon: "🤸" },
  { id: "پا", label: "پا", icon: "🦵" },
  { id: "پا و باسن", label: "پا و باسن", icon: "🏃" },
  { id: "سرشانه", label: "سرشانه", icon: "🤾" },
  { id: "بازو", label: "بازو", icon: "💪" },
  { id: "زیربغل", label: "زیربغل", icon: "🏊" },
  { id: "شکم", label: "شکم", icon: "🧘" },
  { id: "کمر و پشت", label: "کمر و پشت", icon: "🦴" },
  { id: "جلو ران", label: "جلو ران", icon: "🦵" },
  { id: "پشت ران", label: "پشت ران", icon: "🦵" },
  { id: "سینه و دست", label: "سینه و دست", icon: "💪" },
];

const EQUIPMENT_FILTERS = [
  { id: "all", label: "همه تجهیزات" },
  { id: "dumbbell", label: "دمبل" },
  { id: "barbell", label: "هالتر" },
  { id: "machine", label: "دستگاه" },
  { id: "bodyweight", label: "وزن بدن" },
];

const DIFFICULTY_LABELS: Record<string, string> = { beginner: "مبتدی", intermediate: "متوسط", advanced: "پیشرفته" };
const DIFFICULTY_COLORS: Record<string, string> = { beginner: "bg-emerald-100 text-emerald-700", intermediate: "bg-amber-100 text-amber-700", advanced: "bg-red-100 text-red-700" };

export function ExercisesDatabase() {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [muscle, setMuscle] = useState("all");
  const [equipment, setEquipment] = useState("all");
  const [selected, setSelected] = useState<Exercise | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (search) params.set("search", search);
        if (muscle !== "all") params.set("muscle", muscle);
        if (equipment !== "all") params.set("equipment", equipment);
        const res = await fetch(`/api/exercises?${params}`);
        const data = await res.json();
        setExercises(data.exercises || []);
      } catch {} finally { setLoading(false); }
    })();
  }, [search, muscle, equipment]);

  return (
    <div className="min-h-screen bg-white pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Dumbbell className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 mb-2">بانک حرکات ورزشی</h1>
          <p className="text-sm text-slate-500">جستجو و فیلتر در میان حرکات ورزشی با آموزش گام‌به‌گام و نکات ایمنی</p>
        </div>

        {/* Search + filters */}
        <div className="space-y-3 mb-6">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی حرکات..." className="pr-10 rounded-xl border-2" style={{ borderColor: "#fed7aa" }} />
          </div>

          {/* Muscle groups */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {MUSCLE_GROUPS.map(m => (
              <button key={m.id} onClick={() => setMuscle(m.id)} className={`shrink-0 px-4 py-2 rounded-xl text-sm font-bold transition ${muscle === m.id ? "text-white shadow-md" : "bg-slate-100 text-slate-600"}`} style={muscle === m.id ? { background: "linear-gradient(135deg, #f59e0b, #f97316)" } : {}}>
                <span className="ml-1">{m.icon}</span>{m.label}
              </button>
            ))}
          </div>

          {/* Equipment filter */}
          <div className="flex gap-2 flex-wrap">
            {EQUIPMENT_FILTERS.map(e => (
              <button key={e.id} onClick={() => setEquipment(e.id)} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${equipment === e.id ? "bg-orange-100 text-orange-600 border border-orange-300" : "bg-slate-50 text-slate-500 border border-slate-200"}`}>
                <Filter className="w-3 h-3 inline ml-1" />{e.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results count */}
        <p className="text-xs text-slate-400 mb-3">{toPersianDigits(exercises.length)} حرکت یافت شد</p>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-40 rounded-2xl" />)}
          </div>
        ) : exercises.length === 0 ? (
          <div className="text-center py-12">
            <Dumbbell className="w-16 h-16 mx-auto mb-3 text-slate-200" />
            <p className="text-sm text-slate-400">حرکتی با این فیلتر یافت نشد</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {exercises.map((ex, i) => (
              <motion.button
                key={ex.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                whileHover={{ y: -4 }}
                onClick={() => setSelected(ex)}
                className="text-right bg-white rounded-2xl border-2 p-4 transition hover:shadow-lg relative"
                style={{ borderColor: "#fed7aa" }}
              >
                {/* YouTube badge if video available */}
                {ex.youtubeUrl && ex.youtubeUrl.trim() !== "" && (
                  <span className="absolute top-2 left-2 z-10 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-50 border border-red-200 text-[9px] font-bold text-red-600">
                    <Youtube className="w-3 h-3" />
                    ویدیو
                  </span>
                )}
                <div className="flex items-start justify-between mb-2">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                    <Dumbbell className="w-5 h-5 text-white" />
                  </div>
                  <Badge className={`text-[9px] ${DIFFICULTY_COLORS[ex.difficulty] || "bg-slate-100 text-slate-600"}`}>
                    {DIFFICULTY_LABELS[ex.difficulty] || ex.difficulty}
                  </Badge>
                </div>
                <h3 className="font-bold text-sm text-slate-900 mb-1">{ex.name}</h3>
                <p className="text-[11px] text-slate-500 mb-2">{ex.muscle}</p>
                {ex.equipment && (
                  <div className="flex flex-wrap gap-1">
                    {ex.equipment.split(",").slice(0, 3).map((eq, j) => (
                      <span key={j} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">{eq.trim()}</span>
                    ))}
                  </div>
                )}
              </motion.button>
            ))}
          </div>
        )}

        {/* Detail modal */}
        <AnimatePresence>
          {selected && (
            <ExerciseDetailModal exercise={selected} onClose={() => setSelected(null)} />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function ExerciseDetailModal({ exercise, onClose }: { exercise: Exercise; onClose: () => void }) {
  const hasYoutube = !!exercise.youtubeUrl && exercise.youtubeUrl.trim() !== "";
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[90] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="bg-white rounded-3xl w-full max-w-lg max-h-[85vh] overflow-y-auto custom-scrollbar"
        style={{ border: "2px solid #fed7aa" }}
      >
        {/* Header / Video area */}
        {hasYoutube ? (
          <div className="relative">
            <div className="aspect-video w-full bg-black overflow-hidden rounded-t-3xl">
              <iframe
                src={exercise.youtubeUrl}
                title={`ویدیو آموزشی ${exercise.name}`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="w-full h-full"
                referrerPolicy="strict-origin-when-cross-origin"
              />
            </div>
            {/* YouTube disclaimer banner */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-amber-50 border-b border-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
              <p className="text-[11px] text-amber-700 font-medium">
                ⚠️ این ویدیو متعلق به سایت یوتیوب می‌باشد
              </p>
            </div>
            <button onClick={onClose} className="absolute top-3 left-3 p-2 rounded-full bg-white/90 hover:bg-white shadow-md z-10">
              <X className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        ) : (
          <div className="relative h-32 flex items-center justify-center" style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)" }}>
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
              <Dumbbell className="w-8 h-8 text-white" />
            </div>
            <button onClick={onClose} className="absolute top-3 left-3 p-2 rounded-full bg-white/80 hover:bg-white">
              <X className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        )}

        <div className="p-5 space-y-4">
          <div>
            <h2 className="text-xl font-black text-slate-900 mb-1">{exercise.name}</h2>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className="bg-orange-100 text-orange-700 text-[10px]">{exercise.muscle}</Badge>
              <Badge className={`text-[10px] ${DIFFICULTY_COLORS[exercise.difficulty] || "bg-slate-100 text-slate-600"}`}>{DIFFICULTY_LABELS[exercise.difficulty] || exercise.difficulty}</Badge>
              {exercise.equipment && exercise.equipment.split(",").map((eq, j) => (
                <Badge key={j} className="bg-slate-100 text-slate-600 text-[10px]">{eq.trim()}</Badge>
              ))}
            </div>
          </div>

          {/* Description */}
          {exercise.description && (
            <div>
              <h3 className="font-bold text-sm text-slate-900 mb-2 flex items-center gap-1.5"><Info className="w-4 h-4 text-orange-500" /> آموزش اجرای حرکت</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{exercise.description}</p>
            </div>
          )}

          {/* Tips */}
          {exercise.tips && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
              <h3 className="font-bold text-sm text-amber-700 mb-2 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> نکات ایمنی</h3>
              <p className="text-sm text-amber-600 leading-relaxed">{exercise.tips}</p>
            </div>
          )}

          <Button onClick={onClose} className="w-full rounded-xl text-white" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
            <Check className="w-4 h-4" /> متوجه شدم
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}
