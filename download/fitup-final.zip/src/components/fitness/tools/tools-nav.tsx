"use client";

import { Dumbbell, Calculator, Apple, Home } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";

const TOOLS = [
  { id: "tool-tdee", label: "محاسبه‌گر کالری", icon: Calculator },
  { id: "tool-exercises", label: "بانک حرکات", icon: Dumbbell },
  { id: "tool-foods", label: "کالری غذاها", icon: Apple },
] as const;

export function ToolsNav() {
  const { screen, setScreen } = useAppStore();

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-white/90 backdrop-blur-xl border-b shadow-sm" style={{ borderColor: "#fed7aa" }}>
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Right: logo + home */}
          <div className="flex items-center gap-2.5">
            <button onClick={() => setScreen("landing")} className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md" style={{ background: "linear-gradient(135deg, #fb923c, #f97316)" }}>
                <Dumbbell className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-black text-base text-slate-900">فیتاپ</span>
            </button>
          </div>

          {/* Center: tool links */}
          <nav className="hidden sm:flex items-center gap-1">
            {TOOLS.map(t => (
              <button
                key={t.id}
                onClick={() => setScreen(t.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-bold transition ${
                  screen === t.id ? "text-white" : "text-slate-600 hover:bg-slate-100"
                }`}
                style={screen === t.id ? { background: "linear-gradient(135deg, #f59e0b, #f97316)" } : {}}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
              </button>
            ))}
          </nav>

          {/* Left: home */}
          <button onClick={() => setScreen("landing")} className="p-2 rounded-lg hover:bg-slate-100 transition">
            <Home className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Mobile tool links */}
        <div className="flex sm:hidden items-center gap-1 pb-2 overflow-x-auto no-scrollbar">
          {TOOLS.map(t => (
            <button
              key={t.id}
              onClick={() => setScreen(t.id)}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                screen === t.id ? "text-white" : "text-slate-600 bg-slate-100"
              }`}
              style={screen === t.id ? { background: "linear-gradient(135deg, #f59e0b, #f97316)" } : {}}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
