"use client";

import { Dumbbell, ShieldCheck, ExternalLink } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";

export function LandingFooter() {
  const { setScreen } = useAppStore();

  return (
    <footer className="border-t border-orange-100 bg-white mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-2">
            <div className="flex items-center gap-2.5 mb-3">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md"
                style={{ background: "linear-gradient(135deg, #fb923c, #f97316)" }}
              >
                <Dumbbell className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-black text-lg text-slate-900">فیتاپ</span>
            </div>
            <p className="text-sm text-slate-500 max-w-xs leading-relaxed">
              اپلیکیشن جامع تناسب اندام با هوش مصنوعی. هر بدنی فیتاپ میخواد — برنامه تمرینی و غذایی کاملاً شخصی‌سازی‌شده، بدون مربی انسانی.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-sm mb-3 text-slate-900">دسترسی سریع</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><button onClick={() => setScreen("auth")} className="hover:text-orange-600 transition">ورود / ثبت‌نام</button></li>
              <li><a href="#features" className="hover:text-orange-600 transition">امکانات</a></li>
              <li><a href="#tools" className="hover:text-orange-600 transition">ابزارهای رایگان</a></li>
              <li><a href="#pricing" className="hover:text-orange-600 transition">اشتراک‌ها</a></li>
              <li><a href="#faq" className="hover:text-orange-600 transition">سوالات متداول</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sm mb-3 text-slate-900">قوانین و پشتیبانی</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li>
                <button
                  onClick={() => setScreen("terms")}
                  className="flex items-center gap-1.5 hover:text-orange-600 transition font-medium"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-orange-500" />
                  شرایط و قوانین
                  <ExternalLink className="w-3 h-3 opacity-50" />
                </button>
              </li>
              <li>
                <button onClick={() => setScreen("terms")} className="hover:text-orange-600 transition">
                  حریم خصوصی
                </button>
              </li>
              <li><a href="#" className="hover:text-orange-600 transition">پشتیبانی</a></li>
              <li><a href="#" className="hover:text-orange-600 transition">تماس با ما</a></li>
            </ul>
          </div>
        </div>

        {/* Prominent T&C banner */}
        <div
          className="rounded-2xl px-5 py-4 mb-8 flex flex-col sm:flex-row items-center justify-between gap-3"
          style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)", border: "1px solid #fed7aa" }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-slate-900">شرایط و قوانین فیتاپ را مطالعه کنید</p>
              <p className="text-xs text-slate-600">قبل از ثبت‌نام، حتماً قوانین و حریم خصوصی را بررسی کنید</p>
            </div>
          </div>
          <button
            onClick={() => setScreen("terms")}
            className="shrink-0 rounded-xl px-5 py-2.5 text-sm font-bold text-white transition hover:scale-[1.02] shadow-md"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            مشاهده قوانین
          </button>
        </div>

        <div className="pt-8 border-t border-orange-100 flex flex-col items-center gap-2">
          <p className="text-xs text-slate-500 text-center">
            © ۱۴۰۵ فیتاپ
          </p>
          <p className="text-xs font-bold text-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            هر بدنی فیتاپ میخواد
          </p>
        </div>
      </div>
    </footer>
  );
}
