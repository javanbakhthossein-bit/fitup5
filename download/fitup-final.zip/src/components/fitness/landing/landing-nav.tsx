"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dumbbell, Menu, X, ChevronDown, Calculator, Apple, Sparkles } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Button } from "@/components/ui/button";

const NAV_LINKS = [
  { href: "#features", label: "امکانات" },
  { href: "#ai-coach", label: "مربی هوشمند" },
  { href: "#pricing", label: "اشتراک‌ها" },
  { href: "#articles", label: "مقالات" },
  { href: "#faq", label: "سوالات" },
];

const TOOL_LINKS = [
  { screen: "tool-tdee" as const, label: "محاسبه‌گر کالری", icon: Calculator },
  { screen: "tool-exercises" as const, label: "بانک حرکات", icon: Dumbbell },
  { screen: "tool-foods" as const, label: "کالری غذاها", icon: Apple },
];

export function LandingNav({ scrolled }: { scrolled: boolean }) {
  const { setScreen } = useAppStore();
  const [mobileOpen, setMobileOpen] = useState(false);

  function scrollTo(href: string) {
    setMobileOpen(false);
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/90 backdrop-blur-xl border-b shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* راست: منوی موبایل + لوگو */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setMobileOpen((v) => !v)}
              className="md:hidden p-2 rounded-lg hover:bg-slate-100 transition"
              aria-label="منو"
            >
              {mobileOpen ? <X className="w-5 h-5 text-slate-900" /> : <Menu className="w-5 h-5 text-slate-900" />}
            </button>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="flex items-center gap-2.5"
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md" style={{ background: "linear-gradient(135deg, #fb923c, #f97316)" }}>
                <Dumbbell className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-black text-lg text-slate-900">
                  فیتاپ
                </span>
                <span className="text-[9px] text-slate-500 mt-0.5">هر بدنی فیتاپ میخواد</span>
              </div>
            </button>
          </div>

          {/* Desktop nav — وسط */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollTo(link.href)}
                className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition"
              >
                {link.label}
              </button>
            ))}
            {/* ابزارهای رایگان در منوی دسکتاپ */}
            <div className="relative group">
              <button className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition flex items-center gap-1">
                ابزارهای رایگان
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <div className="absolute top-full right-0 mt-1 w-56 bg-white rounded-xl shadow-xl border border-orange-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all p-1.5 z-50">
                <button
                  onClick={() => scrollTo("#tools")}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-bold text-orange-600 hover:bg-orange-50 transition border-b border-orange-100 mb-1"
                >
                  <Sparkles className="w-4 h-4" />
                  مشاهده همه ابزارها
                </button>
                {TOOL_LINKS.map((tool) => (
                  <button
                    key={tool.screen}
                    onClick={() => setScreen(tool.screen)}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-orange-50 hover:text-orange-600 transition"
                  >
                    {tool.icon && <tool.icon className="w-4 h-4" />}
                    {tool.label}
                  </button>
                ))}
              </div>
            </div>
          </nav>

          {/* چپ: اکشن‌ها */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setScreen("auth")}
              className="hidden sm:inline-flex rounded-xl text-slate-700"
            >
              ورود
            </Button>
            <Button
              size="sm"
              onClick={() => setScreen("auth")}
              className="rounded-xl shadow-md text-white"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              شروع رایگان
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden bg-white border-b"
          >
            <div className="px-4 py-3 space-y-1">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.href}
                  onClick={() => scrollTo(link.href)}
                  className="block w-full text-right px-4 py-3 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 transition"
                >
                  {link.label}
                </button>
              ))}
              <div className="pt-2 mt-2 border-t border-slate-100">
                <button
                  onClick={() => scrollTo("#tools")}
                  className="block w-full text-right px-4 py-3 rounded-lg text-sm font-bold text-orange-600 hover:bg-orange-50 transition flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  ابزارهای رایگان
                </button>
                {TOOL_LINKS.map((tool) => (
                  <button
                    key={tool.screen}
                    onClick={() => { setMobileOpen(false); setScreen(tool.screen); }}
                    className="block w-full text-right px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-orange-50 hover:text-orange-600 transition flex items-center gap-2"
                  >
                    {tool.icon && <tool.icon className="w-4 h-4 text-orange-500" />}
                    {tool.label}
                  </button>
                ))}
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
