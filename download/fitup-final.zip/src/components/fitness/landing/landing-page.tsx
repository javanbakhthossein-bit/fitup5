"use client";

import { useState } from "react";
import { useScroll, useMotionValueEvent } from "framer-motion";
import { LandingNav } from "./landing-nav";
import { HeroSection } from "./sections/hero-section";
import { TrustBar } from "./sections/trust-bar";
import { FeaturesSection } from "./sections/features-section";
import { ToolsSection } from "./sections/tools-section";
import { AiCoachSection } from "./sections/ai-coach-section";
import { PricingSection } from "./sections/pricing-section";
import { TestimonialsSection } from "./sections/testimonials-section";
import { FaqSection } from "./sections/faq-section";
import { CtaSection } from "./sections/cta-section";
import { ArticlesSliderSection } from "./sections/articles-slider-section";
import { AppInstallSection } from "./sections/app-install-section";
import { LandingFooter } from "./landing-footer";

export function LandingPage() {
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (v) => {
    setScrolled(v > 20);
  });

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <LandingNav scrolled={scrolled} />
      <main>
        <HeroSection />
        <TrustBar />
        <FeaturesSection />
        <ToolsSection />
        <AiCoachSection />
        <PricingSection />
        <ArticlesSliderSection />
        <TestimonialsSection />
        <FaqSection />
        <AppInstallSection />
        <CtaSection />
      </main>
      <LandingFooter />
    </div>
  );
}
