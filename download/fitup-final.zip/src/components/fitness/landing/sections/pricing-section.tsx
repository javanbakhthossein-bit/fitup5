"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Crown, Check, Sparkles, Wallet, ShieldCheck, Info, Star, Zap } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import {
  SUBSCRIPTION_PLANS,
  toPersianDigits,
  formatToman,
  type SubscriptionPlan,
} from "@/lib/fitness/types";
import { getFeatureDescription } from "@/lib/fitness/feature-descriptions";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { PurchaseModal } from "./purchase-modal";

// جدول مقایسه قابلیت‌ها بین ۴ پلن (اقتصادی/استاندارد/پیشرفته/حرفه‌ای)
const COMPARISON_ROWS: { category: string; label: string; values: boolean[] }[] = [
  // امکانات عمومی (۵ ردیف) — همه پلن‌ها
  { category: "امکانات عمومی", label: "آنالیز کامل پروفایل ورزشی", values: [true, true, true, true] },
  { category: "امکانات عمومی", label: "برنامه تمرینی اختصاصی (۴۵ روزه)", values: [true, true, true, true] },
  { category: "امکانات عمومی", label: "برنامه تغذیه اختصاصی", values: [true, true, true, true] },
  { category: "امکانات عمومی", label: "پیگیری پیشرفت وزن", values: [true, true, true, true] },
  { category: "امکانات عمومی", label: "گالری تصاویر پیشرفت", values: [true, true, true, true] },
  // امکانات استاندارد (۳ ردیف) — از استاندارد به بعد
  { category: "امکانات استاندارد", label: "برنامه مکمل‌های ورزشی اختصاصی", values: [false, true, true, true] },
  { category: "امکانات استاندارد", label: "۳ چکاپ دوره‌ای برای رصد پیشرفت", values: [false, true, true, true] },
  { category: "امکانات استاندارد", label: "داشبورد پیشرفته با تاریخچه و سوابق", values: [false, true, true, true] },
  // هوش مصنوعی (۶ ردیف) — از پیشرفته به بعد
  { category: "هوش مصنوعی", label: "چت بی‌نهایت با مربی هوشمند", values: [false, false, true, true] },
  { category: "هوش مصنوعی", label: "آنالیز عکس وعده‌های غذایی", values: [false, false, true, true] },
  { category: "هوش مصنوعی", label: "آنالیز عکس بدن", values: [false, false, true, true] },
  { category: "هوش مصنوعی", label: "حالت باشگاه (Gym Mode)", values: [false, false, true, true] },
  { category: "هوش مصنوعی", label: "دستیار تغذیه (Nutrition Companion)", values: [false, false, true, true] },
  { category: "هوش مصنوعی", label: "دسترسی کامل به کتابخانه متحرک حرکات", values: [false, false, true, true] },
  // امکانات حرفه‌ای (۳ ردیف) — فقط حرفه‌ای
  { category: "امکانات حرفه‌ای", label: "ارسال ویدیو در چت با مربی", values: [false, false, false, true] },
  { category: "امکانات حرفه‌ای", label: "آنالیز ویدیویی بدن قبل از طراحی برنامه", values: [false, false, false, true] },
  { category: "امکانات حرفه‌ای", label: "اصلاح تکنیک حرکات با ارسال ویدیو", values: [false, false, false, true] },
];

const CATEGORY_LABELS = ["امکانات عمومی", "امکانات استاندارد", "هوش مصنوعی", "امکانات حرفه‌ای"];

export function PricingSection() {
  const { setScreen } = useAppStore();
  const [purchasePlan, setPurchasePlan] = useState<SubscriptionPlan | null>(null);

  return (
    <section id="pricing" className="py-20 sm:py-28 bg-white relative overflow-hidden">
      {/* subtle background */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className="absolute top-20 right-0 w-96 h-96 rounded-full bg-amber-100/40 blur-3xl" />
        <div className="absolute bottom-20 left-0 w-80 h-80 rounded-full bg-orange-100/40 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium mb-4"
            style={{ background: "#fff7ed", border: "1px solid #fed7aa", color: "#ea580c" }}
          >
            <Crown className="w-4 h-4" />
            ۴ پلن اشتراک — هر بدنی فیتاپ میخواد
          </div>
          <h2 className="text-3xl sm:text-4xl font-black mb-4 text-slate-900">
            پلن متناسب با{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #f59e0b, #f97316)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              هدف و بودجه
            </span>{" "}
            خودت را انتخاب کن
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            از پلن اقتصادی شروع کن یا با پلن حرفه‌ای، آنالیز ویدیویی و آزمایش خون را تجربه کن. همه پلن‌ها ۴۵ روزه و شامل ۱ فاز تمرینی هستند.
          </p>
        </motion.div>

        {/* ۴ کارت قیمت‌گذاری — سفید با حاشیه طلایی پررنگ */}
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6 mb-12 max-w-6xl mx-auto items-stretch">
          {SUBSCRIPTION_PLANS.map((plan, i) => (
            <PlanCard
              key={plan.id}
              plan={plan}
              index={i}
              onSelect={() => setPurchasePlan(plan)}
            />
          ))}
        </div>

        {/* لینک برجسته‌تر به جدول مقایسه */}
        <div className="max-w-5xl mx-auto mb-6">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-center gap-2 text-center"
          >
            <a
              href="#comparison-table"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-orange-50 to-amber-50 border-2 border-orange-200 text-orange-700 text-sm font-bold hover:border-orange-400 hover:shadow-lg hover:shadow-orange-500/10 transition-all"
            >
              <Info className="w-4 h-4" />
              مقایسه کامل ۴ پلن را ببینید
              <span className="text-orange-400">↓</span>
            </a>
          </motion.div>
        </div>

        {/* جدول مقایسه تاشو */}
        <div id="comparison-table">
          <ComparisonTable />
        </div>

        {/* نشانه‌های اعتماد */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="flex flex-wrap items-center justify-center gap-6 mt-12 text-sm text-slate-500"
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-orange-500" />
            پرداخت امن زرین‌پال
          </div>
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-orange-500" />
            پرداخت با کیف پول
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-orange-500" />
            ۴۵ روز دسترسی کامل به پلتفرم
          </div>
        </motion.div>
      </div>

      {purchasePlan && (
        <PurchaseModal
          plan={purchasePlan}
          onClose={() => setPurchasePlan(null)}
          onNeedLogin={() => {
            setPurchasePlan(null);
            setScreen("auth");
          }}
        />
      )}
    </section>
  );
}

function PlanCard({
  plan,
  index,
  onSelect,
}: {
  plan: SubscriptionPlan;
  index: number;
  onSelect: () => void;
}) {
  const isUltimate = plan.id === "ultimate";
  const isAdvanced = plan.id === "advanced";
  const price = plan.price;

  // Border styles: 3px thick gold gradient for Advanced/Ultimate, lighter for others
  const borderStyle: React.CSSProperties = isUltimate
    ? {
        background:
          "linear-gradient(135deg, #f59e0b 0%, #f97316 35%, #fbbf24 65%, #f59e0b 100%)",
        padding: "3px",
        boxShadow:
          "0 25px 50px -12px rgba(249, 115, 22, 0.45), 0 0 0 1px rgba(245, 158, 11, 0.2)",
      }
    : isAdvanced
    ? {
        background:
          "linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #f97316 100%)",
        padding: "3px",
        boxShadow:
          "0 20px 40px -12px rgba(245, 158, 11, 0.4), 0 0 0 1px rgba(245, 158, 11, 0.15)",
      }
    : plan.id === "standard"
    ? {
        background:
          "linear-gradient(135deg, #fcd34d, #fbbf24)",
        padding: "2px",
        boxShadow: "0 10px 25px -10px rgba(251, 191, 36, 0.35)",
      }
    : {
        background:
          "linear-gradient(135deg, #e5e7eb, #d1d5db)",
        padding: "2px",
        boxShadow: "0 10px 25px -10px rgba(0, 0, 0, 0.1)",
      };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.08 }}
      whileHover={{ y: -10 }}
      style={borderStyle}
      className="relative rounded-[1.75rem] transition-all"
    >
      <div className="relative h-full rounded-[1.65rem] bg-white flex flex-col text-slate-900 overflow-hidden">
        {/* shimmer overlay for premium plans */}
        {(isAdvanced || isUltimate) && (
          <div className="absolute inset-0 pointer-events-none opacity-0 hover:opacity-100 transition-opacity">
            <div
              className="absolute -inset-x-20 top-0 h-32 blur-2xl"
              style={{
                background:
                  "linear-gradient(110deg, transparent 30%, rgba(245, 158, 11, 0.25) 50%, transparent 70%)",
                backgroundSize: "200% 100%",
                animation: "gold-shimmer 3s infinite linear",
              }}
            />
          </div>
        )}

        {/* Prominent Ribbon for Advanced (پیشنهاد ویژه) */}
        {isAdvanced && (
          <div className="absolute top-0 right-0 z-10">
            <div
              className="relative inline-flex items-center gap-1.5 text-xs font-black px-4 py-2 text-white shadow-xl rounded-bl-2xl rounded-tr-[1.55rem]"
              style={{
                background:
                  "linear-gradient(135deg, #f59e0b, #f97316)",
              }}
            >
              <Star className="w-3.5 h-3.5 fill-white" />
              پیشنهاد ویژه
              <Sparkles className="w-3 h-3" />
            </div>
          </div>
        )}

        {/* Ultimate badge */}
        {isUltimate && (
          <div className="absolute top-0 left-0 z-10">
            <div
              className="inline-flex items-center gap-1 text-[10px] font-bold px-3 py-1 text-white shadow-lg rounded-br-2xl rounded-tl-[1.55rem]"
              style={{
                background: "linear-gradient(135deg, #1f2937, #111827)",
              }}
            >
              <Crown className="w-3 h-3 text-amber-400" />
              کامل‌ترین
            </div>
          </div>
        )}

        <div className="p-6 pt-8 flex flex-col h-full flex-1">
          {/* Header */}
          <div className="text-center mb-4 mt-2">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3 shadow-lg"
              style={{
                background: isUltimate
                  ? "linear-gradient(135deg, #1f2937, #111827)"
                  : isAdvanced
                  ? "linear-gradient(135deg, #f59e0b, #f97316)"
                  : plan.id === "standard"
                  ? "linear-gradient(135deg, #fbbf24, #f59e0b)"
                  : "linear-gradient(135deg, #f3f4f6, #e5e7eb)",
                boxShadow: isAdvanced
                  ? "0 10px 25px -6px rgba(245, 158, 11, 0.5)"
                  : isUltimate
                  ? "0 10px 25px -6px rgba(17, 24, 39, 0.4)"
                  : "0 8px 18px -6px rgba(0, 0, 0, 0.15)",
              }}
            >
              <span className={isUltimate ? "filter drop-shadow(0 0 6px rgba(245,158,11,0.6))" : ""}>
                {plan.icon}
              </span>
            </div>
            <h3 className="font-black text-xl text-slate-900">{plan.label}</h3>
            <p className="text-xs text-slate-500 mt-1 min-h-[2.5rem] flex items-center justify-center px-2">
              {plan.tagline}
            </p>
          </div>

          {/* Price section — large with gradient text */}
          <div className="text-center mb-5 py-4 border-y border-slate-100">
            <div className="flex items-end justify-center gap-1">
              <span
                className="text-4xl font-black leading-none"
                style={{
                  background: "linear-gradient(135deg, #f59e0b, #f97316)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  filter: isAdvanced || isUltimate ? "drop-shadow(0 2px 6px rgba(249,115,22,0.25))" : "none",
                }}
              >
                {toPersianDigits(formatToman(price))}
              </span>
              <span className="text-sm text-slate-500 mb-1">تومان</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5 font-medium">
              {toPersianDigits(plan.durationDays)} روزه — {toPersianDigits(plan.phases)} فاز تمرینی
            </p>
          </div>

          {/* Features */}
          <div className="space-y-2 mb-5 flex-1">
            {plan.features.map((f, j) => (
              <FeatureItemLanding key={j} text={f} />
            ))}
          </div>

          {/* Button — larger, more prominent with glow */}
          <button
            onClick={onSelect}
            className="w-full rounded-2xl h-14 font-bold text-sm text-white transition-all hover:scale-[1.03] flex items-center justify-center gap-2 shadow-xl"
            style={{
              background: "linear-gradient(135deg, #f59e0b, #f97316)",
              boxShadow: isAdvanced
                ? "0 14px 30px -8px rgba(249, 115, 22, 0.55)"
                : "0 10px 24px -8px rgba(249, 115, 22, 0.4)",
            }}
          >
            <Crown className="w-4 h-4" />
            انتخاب پلن {plan.label}
            <Zap className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function ComparisonTable() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="rounded-3xl border-2 border-orange-100 bg-white overflow-hidden max-w-5xl mx-auto shadow-lg shadow-orange-500/5"
    >
      <Accordion type="single" collapsible>
        <AccordionItem value="comparison" className="border-0">
          <AccordionTrigger className="text-base font-bold py-5 px-5 hover:no-underline text-slate-900">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-orange-500" />
              مقایسه کامل امکانات ۴ پلن
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-y bg-orange-50">
                    <th className="text-right p-3 font-bold text-slate-900 sticky right-0 bg-orange-50 min-w-[160px]">قابلیت</th>
                    {SUBSCRIPTION_PLANS.map((p) => (
                      <th key={p.id} className="text-center p-3 font-bold min-w-[90px] text-slate-900">
                        <div className="flex flex-col items-center gap-1">
                          <span className="text-base">{p.icon}</span>
                          <span className="text-xs">{p.label}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {CATEGORY_LABELS.map((cat) => (
                    <React.Fragment key={cat}>
                      <tr className="bg-orange-50">
                        <td colSpan={5} className="p-2.5 text-xs font-bold text-orange-700">{cat}</td>
                      </tr>
                      {COMPARISON_ROWS.filter((r) => r.category === cat).map((row, i) => (
                        <tr key={`${cat}-${i}`} className="border-b last:border-0 hover:bg-orange-50/50">
                          <td className="text-right p-3 text-xs text-slate-700 sticky right-0 bg-white">{row.label}</td>
                          {row.values.map((v, j) => (
                            <td key={j} className="text-center p-3">
                              {v ? (
                                <Check className="w-4 h-4 text-orange-500 mx-auto" strokeWidth={3} />
                              ) : (
                                <span className="text-slate-300">—</span>
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </motion.div>
  );
}

function FeatureItemLanding({ text }: { text: string }) {
  const [showTip, setShowTip] = useState(false);
  const desc = getFeatureDescription(text);
  return (
    <div
      className="relative flex items-start gap-2.5 group p-1.5 rounded-lg hover:bg-orange-50 transition-colors"
      onMouseEnter={() => setShowTip(true)}
      onMouseLeave={() => setShowTip(false)}
    >
      <div
        className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 shadow-sm"
        style={{
          background: "linear-gradient(135deg, #f59e0b, #f97316)",
          boxShadow: "0 3px 8px -2px rgba(249, 115, 22, 0.5)",
        }}
      >
        <Check className="w-3 h-3 text-white" strokeWidth={3.5} />
      </div>
      <span className="text-xs text-slate-700 leading-relaxed flex-1 group-hover:text-slate-900 transition-colors font-medium">{text}</span>
      {desc && (
        <Info className="w-3.5 h-3.5 text-slate-300 shrink-0 mt-0.5 group-hover:text-orange-500 transition" />
      )}
      {showTip && desc && (
        <motion.div
          initial={{ opacity: 0, y: 5, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="absolute bottom-full right-0 mb-2 z-30 w-56 p-3 rounded-xl text-[11px] leading-relaxed shadow-2xl bg-white"
          style={{ border: "1px solid #fed7aa" }}
        >
          <p className="font-bold mb-1 flex items-center gap-1 text-orange-600">
            <Info className="w-3.5 h-3.5" /> توضیح قابلیت
          </p>
          <p className="text-slate-600">{desc}</p>
        </motion.div>
      )}
    </div>
  );
}
