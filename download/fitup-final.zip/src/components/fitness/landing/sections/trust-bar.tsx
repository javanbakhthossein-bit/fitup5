"use client";

import { motion } from "framer-motion";
import { Users, Dumbbell, Salad, Star } from "lucide-react";

const STATS = [
  {
    icon: Users,
    value: "۱۰,۰۰۰+",
    label: "کاربر فعال",
    subtitle: "ورزشکاران ایرانی",
    grad: "from-amber-500 to-orange-500",
  },
  {
    icon: Dumbbell,
    value: "۲۵۰+",
    label: "حرکت ورزشی",
    subtitle: "با آموزش گام‌به‌گام",
    grad: "from-orange-500 to-red-500",
  },
  {
    icon: Salad,
    value: "۵۰۰+",
    label: "غذای سالم",
    subtitle: "بانک مواد غذایی",
    grad: "from-yellow-500 to-amber-500",
  },
  {
    icon: Star,
    value: "۴.۹",
    label: "امتیاز کاربران",
    subtitle: "از ۱۰ هزار نظر",
    grad: "from-amber-400 to-orange-400",
  },
];

export function TrustBar() {
  return (
    <section className="py-10 sm:py-12 bg-white border-y border-orange-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Desktop: 4-column grid */}
        <div className="hidden md:grid grid-cols-4 gap-4 sm:gap-6">
          {STATS.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -4 }}
              className="relative bg-white rounded-3xl border border-orange-100 shadow-sm hover:shadow-xl transition-all p-5 text-center overflow-hidden"
            >
              {/* Decorative gradient blob */}
              <div
                className={`absolute -top-8 -left-8 w-24 h-24 rounded-full opacity-10 blur-2xl bg-gradient-to-br ${stat.grad}`}
              />
              <div
                className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${stat.grad} flex items-center justify-center mx-auto mb-3 shadow-lg`}
              >
                <stat.icon className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <p
                className="text-2xl sm:text-3xl font-black mb-0.5"
                style={{
                  background: "linear-gradient(135deg, #f59e0b, #f97316)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                {stat.value}
              </p>
              <p className="text-sm font-bold text-slate-900">{stat.label}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">{stat.subtitle}</p>
            </motion.div>
          ))}
        </div>

        {/* Mobile: horizontal scrolling carousel */}
        <div className="md:hidden -mx-4 px-4">
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 snap-x snap-mandatory">
            {STATS.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="shrink-0 w-40 snap-center bg-white rounded-2xl border border-orange-100 shadow-sm p-4 text-center"
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.grad} flex items-center justify-center mx-auto mb-2 shadow-md`}
                >
                  <stat.icon className="w-6 h-6 text-white" strokeWidth={2.5} />
                </div>
                <p
                  className="text-2xl font-black mb-0.5"
                  style={{
                    background: "linear-gradient(135deg, #f59e0b, #f97316)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {stat.value}
                </p>
                <p className="text-xs font-bold text-slate-900">{stat.label}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">{stat.subtitle}</p>
              </motion.div>
            ))}
          </div>
          <p className="text-center text-[10px] text-slate-400 mt-1">← برای مشاهده بیشتر بکشید →</p>
        </div>
      </div>
    </section>
  );
}
