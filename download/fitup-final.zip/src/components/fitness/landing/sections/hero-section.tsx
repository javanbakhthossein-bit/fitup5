"use client";

import { motion } from "framer-motion";
import { Sparkles, Play, ChevronLeft, Star, Zap } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { toPersianDigits } from "@/lib/fitness/types";

export function HeroSection() {
  const { setScreen } = useAppStore();

  return (
    <section className="relative pt-24 pb-20 sm:pt-32 sm:pb-24 overflow-hidden bg-white min-h-[88vh] sm:min-h-[auto] flex items-center">
      {/* Background effects */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 right-1/4 w-96 h-96 rounded-full bg-amber-200/40 blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 rounded-full bg-orange-200/40 blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "radial-gradient(circle, currentColor 1px, transparent 1px)",
            backgroundSize: "32px 32px",
            color: "#f59e0b",
          }}
        />
        {/* Floating emoji stickers — mobile only */}
        <motion.div
          animate={{ y: [0, -12, 0], rotate: [0, 8, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-32 left-6 text-3xl opacity-50 sm:hidden"
        >
          💪
        </motion.div>
        <motion.div
          animate={{ y: [0, 12, 0], rotate: [0, -8, 0] }}
          transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          className="absolute top-44 right-6 text-3xl opacity-50 sm:hidden"
        >
          🔥
        </motion.div>
        <motion.div
          animate={{ y: [0, -10, 0], rotate: [0, 6, 0] }}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-32 right-8 text-3xl opacity-50 sm:hidden"
        >
          ⚡
        </motion.div>
        <motion.div
          animate={{ y: [0, 10, 0], rotate: [0, -6, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
          className="absolute bottom-44 left-8 text-3xl opacity-50 sm:hidden"
        >
          🎯
        </motion.div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text */}
          <div className="text-center lg:text-right">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium mb-5"
              style={{ background: "#fff7ed", border: "1px solid #fed7aa", color: "#ea580c" }}
            >
              <Sparkles className="w-4 h-4" />
              هر بدنی فیتاپ میخواد — با هوش مصنوعی
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight mb-4 text-slate-900"
            >
              <span
                style={{
                  background: "linear-gradient(135deg, #f59e0b, #f97316)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                برنامه بدنسازی
              </span>{" "}
              هوشمند
              <br />
              با فیتاپ بساز
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-base sm:text-lg text-slate-600 leading-relaxed mb-6 max-w-xl mx-auto lg:mx-0"
            >
              مربی هوشمند همیشه کنارت است — برنامه تمرینی و تغذیه شخصی‌سازی‌شده،
              تحلیل هوشمند غذا و بدن، چت ۲۴ ساعته و پیگیری پیشرفت. همه چیز برای
              رسیدن به بدن ایده‌آلت، در یک پلتفرم کامل.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start mb-8"
            >
              <button
                onClick={() => setScreen("auth")}
                className="rounded-2xl h-14 px-8 text-base font-bold flex items-center justify-center gap-2 text-white shadow-xl transition hover:scale-[1.02]"
                style={{
                  background: "linear-gradient(135deg, #f59e0b, #f97316)",
                  boxShadow: "0 12px 30px -8px rgba(249, 115, 22, 0.5)",
                }}
              >
                <Zap className="w-5 h-5" />
                شروع رایگان
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => document.querySelector("#how")?.scrollIntoView({ behavior: "smooth" })}
                className="rounded-2xl h-14 px-8 text-base font-bold bg-white border-2 border-orange-200 text-slate-700 hover:border-orange-400 hover:bg-orange-50 transition flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 text-orange-500" />
                چطور کار می‌کند؟
              </button>
            </motion.div>

            {/* Rating */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="flex items-center gap-3 justify-center lg:justify-start"
            >
              <div className="flex">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <div className="text-sm text-slate-600">
                <span className="font-bold text-slate-900">{toPersianDigits("۴.۹")}</span>
                <span> از {toPersianDigits("۱۰,۰۰۰+")} کاربر</span>
              </div>
            </motion.div>
          </div>

          {/* Visual — hero image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, x: 30 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            transition={{ delay: 0.3, type: "spring" }}
            className="relative"
          >
            <div className="relative mx-auto max-w-lg">
              {/* Glow */}
              <div
                className="absolute inset-0 blur-3xl rounded-full opacity-60"
                style={{ background: "linear-gradient(135deg, #f59e0b40, #f9731640)" }}
              />

              {/* Hero image card */}
              <div className="relative rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white">
                <img
                  src="/hero-fitup-v3.png"
                  alt="فیتاپ - اپلیکیشن تناسب اندام با هوش مصنوعی"
                  className="w-full h-auto block"
                />
                {/* Subtle gradient overlay at edges */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background:
                      "linear-gradient(to top, rgba(0,0,0,0.25), transparent 30%, transparent 70%, rgba(0,0,0,0.15))",
                  }}
                />
              </div>

              {/* Floating cards */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-4 -right-4 sm:-right-8 bg-white rounded-2xl shadow-xl border border-orange-100 p-3 max-w-[180px]"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #fef3c7, #fed7aa)" }}
                  >
                    <Zap className="w-4 h-4 text-orange-500" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">برنامه آماده!</p>
                    <p className="text-[10px] text-slate-500">ساخت هوش مصنوعی</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute -bottom-4 -left-4 sm:-left-8 bg-white rounded-2xl shadow-xl border border-orange-100 p-3 max-w-[200px]"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #fef3c7, #fed7aa)" }}
                  >
                    <Sparkles className="w-4 h-4 text-orange-500" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">چت با مربی AI</p>
                    <p className="text-[10px] text-slate-500">۲۴ ساعته پاسخگو</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
