"use client";

import { motion } from "framer-motion";
import { Bell, Dumbbell, Shield, Menu, X } from "lucide-react";
import { UserCircle } from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { toPersianDigits, PLAN_LABELS } from "@/lib/fitness/types";
import { useState } from "react";
import {
  LayoutDashboard,
  ClipboardList,
  TrendingUp,
  MessageCircle,
  Crown,
  Apple,
  Gift,
  Headphones,
  LogOut,
} from "lucide-react";
import type { MainTab } from "@/lib/fitness/store";
import { toast } from "sonner";

const goldGradient = "linear-gradient(135deg, #f59e0b, #f97316)";

const NAV_ITEMS: { id: MainTab; label: string; icon: any; badge?: string }[] = [
  { id: "dashboard", label: "داشبورد", icon: LayoutDashboard },
  { id: "programs", label: "برنامه‌ها", icon: ClipboardList },
  { id: "workouts", label: "تمرینات", icon: Dumbbell },
  { id: "nutrition", label: "دستیار تغذیه", icon: Apple },
  { id: "progress", label: "پیشرفت", icon: TrendingUp },
  { id: "chat", label: "چت مربی", icon: MessageCircle },
  { id: "referral", label: "معرفی به دوست", icon: Gift },
  { id: "support", label: "پشتیبانی", icon: Headphones },
  { id: "plans", label: "اشتراک", icon: Crown },
];

export function TopBar() {
  const { overlay, setOverlay, unreadCount, user, mainTab, setMainTab, reset } = useAppStore();
  const [menuOpen, setMenuOpen] = useState(false);

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      reset();
      toast.success("با موفقیت خارج شدید");
    } catch {
      toast.error("خطا در خروج");
    }
  }

  function handleNav(tab: MainTab) {
    setMainTab(tab);
    setMenuOpen(false);
  }

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-orange-100">
        <div className="flex items-center justify-between px-4 sm:px-6 h-16">
          {/* Mobile: hamburger menu (right) + brand (left) */}
          <div className="flex items-center gap-2.5 lg:hidden">
            <button
              onClick={() => setMenuOpen(true)}
              className="p-2 rounded-xl hover:bg-orange-50 transition"
              aria-label="منو"
            >
              <Menu className="w-6 h-6 text-slate-700" />
            </button>
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md"
              style={{ background: goldGradient }}
            >
              <Dumbbell className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex flex-col leading-none">
              <h1
                className="font-black text-base"
                style={{
                  background: goldGradient,
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                فیتاپ
              </h1>
              <span className="text-[9px] text-slate-500 mt-0.5">هر بدنی فیتاپ میخواد</span>
            </div>
          </div>

          {/* Desktop greeting */}
          <div className="hidden lg:block">
            <p className="text-sm text-slate-600">
              {user?.name ? `سلام ${user.name} 👋` : "به فیتاپ خوش آمدی"}
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1.5">
            {user?.role === "ADMIN" && (
              <button
                onClick={() => setOverlay("admin")}
                className="p-2.5 rounded-xl hover:bg-orange-50 transition relative"
                title="پنل مدیریت"
              >
                <Shield className="w-5 h-5 text-orange-500" />
              </button>
            )}
            <button
              onClick={() => setOverlay(overlay === "notifications" ? null : "notifications")}
              className="p-2.5 rounded-xl hover:bg-orange-50 transition relative text-slate-600"
              title="اعلان‌ها"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute top-1.5 left-1.5 min-w-[18px] h-[18px] px-1 rounded-full text-white text-[10px] font-bold flex items-center justify-center"
                  style={{ background: goldGradient }}
                >
                  {toPersianDigits(unreadCount)}
                </motion.span>
              )}
            </button>
            <button
              onClick={() => setOverlay("profile")}
              className="w-9 h-9 rounded-full flex items-center justify-center text-orange-500 hover:text-orange-600 transition"
              title="پروفایل"
            >
              <UserCircle className="w-7 h-7" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile slide-out menu (from right) */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setMenuOpen(false)}
          />
          {/* Drawer — slides from right */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute right-0 top-0 h-full w-80 max-w-[85vw] bg-white shadow-2xl flex flex-col"
            dir="rtl"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-orange-100" style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)" }}>
              <div className="flex items-center gap-2.5">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md"
                  style={{ background: goldGradient }}
                >
                  <Dumbbell className="w-5 h-5 text-white" strokeWidth={2.5} />
                </div>
                <div>
                  <h2 className="font-black text-base text-slate-900">فیتاپ</h2>
                  <p className="text-[10px] text-slate-500">{user?.name || "ورزشکار"}</p>
                </div>
              </div>
              <button
                onClick={() => setMenuOpen(false)}
                className="p-2 rounded-xl hover:bg-white/60 transition"
                aria-label="بستن منو"
              >
                <X className="w-5 h-5 text-slate-600" />
              </button>
            </div>

            {/* Plan badge */}
            {user?.planName && (
              <div className="px-4 py-2.5 border-b border-orange-50 bg-orange-50/50">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">پلن فعلی</span>
                  <span
                    className="text-[11px] font-bold px-2.5 py-1 rounded-full text-white"
                    style={{ background: goldGradient }}
                  >
                    {PLAN_LABELS[user.planName as keyof typeof PLAN_LABELS] || user.planName}
                  </span>
                </div>
              </div>
            )}

            {/* Navigation items */}
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const isActive = mainTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNav(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition text-right ${
                      isActive
                        ? "text-white shadow-md"
                        : "text-slate-700 hover:bg-orange-50"
                    }`}
                    style={isActive ? { background: goldGradient } : {}}
                  >
                    <item.icon className="w-5 h-5 shrink-0" />
                    <span className="text-sm font-medium flex-1">{item.label}</span>
                    {isActive && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </button>
                );
              })}
            </nav>

            {/* Footer — logout */}
            <div className="p-3 border-t border-orange-100">
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition text-right"
              >
                <LogOut className="w-5 h-5 shrink-0" />
                <span className="text-sm font-medium">خروج از حساب</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}
