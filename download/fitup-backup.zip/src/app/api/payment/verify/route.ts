import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, apiError, buildUserDto } from "@/lib/fitness/auth";
import { SUBSCRIPTION_PLANS, toPersianDigits } from "@/lib/fitness/types";
import { zarinpalVerify, isZarinpalConfigured } from "@/lib/fitness/zarinpal";
import { processReferralReward } from "@/lib/fitness/referral";

interface VerifyBody {
  paymentId: string;
  status: "OK" | "NOK" | "CANCELLED";
  /** برای callback زرین‌پال: authority واقعی که از URL برمی‌گردد */
  authority?: string;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const body = (await req.json()) as VerifyBody;

    const payment = await db.payment.findFirst({
      where: { id: body.paymentId, userId: user.id },
    });
    if (!payment) {
      return Response.json({ error: "پرداخت یافت نشد." }, { status: 404 });
    }
    if (payment.status !== "pending") {
      return Response.json(
        { error: "این پرداخت قبلاً پردازش شده است." },
        { status: 400 }
      );
    }

    // --- انصراف کاربر ---
    if (body.status === "CANCELLED") {
      await db.payment.update({
        where: { id: payment.id },
        data: { status: "cancelled", verifiedAt: new Date() },
      });
      return Response.json({
        success: false,
        status: "cancelled",
        message: "پرداخت لغو شد.",
      });
    }

    // --- پرداخت ناموفق ---
    if (body.status === "NOK") {
      await db.payment.update({
        where: { id: payment.id },
        data: { status: "failed", verifiedAt: new Date() },
      });
      return Response.json({
        success: false,
        status: "failed",
        message: "پرداخت ناموفق بود.",
      });
    }

    // --- پرداخت موفق ---
    const plan = SUBSCRIPTION_PLANS.find((p) => p.id === payment.plan);
    if (!plan) {
      return Response.json({ error: "پلن نامعتبر است." }, { status: 400 });
    }

    // تعیین refId:
    // - اگر paymentMethod === "wallet" → تایید آنی (نیازی به زرین‌پال نیست)
    // - اگر gateway و کلید واقعی زرین‌پال پیکربندی شده → verify API واقعی را صدا بزن
    // - در غیر این صورت (شبیه‌سازی) → refId محلی تولید کن
    let refId = `${Date.now()}${Math.floor(Math.random() * 10000)}`;
    let verifyError: string | null = null;

    if (payment.paymentMethod === "gateway" && isZarinpalConfigured()) {
      const authorityToVerify = body.authority ?? payment.authority;
      const zRes = await zarinpalVerify({
        authority: authorityToVerify,
        amount: payment.amount, // Tomans
      });

      if (zRes.ok) {
        if (zRes.refId) refId = zRes.refId;
      } else {
        // تایید ناموفق — اما اگر کلید تست باشد، احتمالاً زرین‌پال رد می‌کند؛ در حالت شبیه‌سازی به کاربر اجازه ادامه بده
        verifyError = zRes.error ?? "Zarinpal verify failed";
        // ثبت ناموفق
        await db.payment.update({
          where: { id: payment.id },
          data: {
            status: "failed",
            verifiedAt: new Date(),
            refId: zRes.refId ?? null,
          },
        });
        return Response.json({
          success: false,
          status: "failed",
          message: `تأیید پرداخت توسط زرین‌پال ناموفق بود: ${verifyError}`,
          refId: zRes.refId,
        });
      }
    }

    const now = new Date();

    // اگر پرداخت از کیف پول، مبلغ را از موجودی کسر و تراکنش ثبت کن
    let newBalance = 0;
    if (payment.paymentMethod === "wallet") {
      const freshUser = await db.user.findUnique({ where: { id: user.id } });
      const balance = freshUser?.walletBalance ?? 0;
      if (balance < payment.amount) {
        await db.payment.update({
          where: { id: payment.id },
          data: { status: "failed", verifiedAt: now },
        });
        return Response.json({
          success: false,
          status: "failed",
          message: "موجودی کیف پول در زمان تایید کافی نبود.",
        });
      }
      newBalance = balance - payment.amount;
      await db.user.update({
        where: { id: user.id },
        data: { walletBalance: newBalance },
      });
      await db.walletTransaction.create({
        data: {
          userId: user.id,
          type: "purchase",
          amount: -payment.amount,
          balance: newBalance,
          description: `خرید پلن ${plan.label}`,
          refId: payment.id,
        },
      });
    }

    // آپدیت وضعیت پرداخت به success
    await db.payment.update({
      where: { id: payment.id },
      data: {
        status: "success",
        refId,
        verifiedAt: now,
      },
    });

    // محاسبه تاریخ انقضا بر اساس durationDays پلن
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);

    // غیرفعال کردن اشتراک‌های قبلی فعال
    await db.subscription.updateMany({
      where: { userId: user.id, status: "active" },
      data: { status: "expired" },
    });

    // ایجاد اشتراک جدید
    await db.subscription.create({
      data: {
        userId: user.id,
        plan: plan.id,
        status: "active",
        startDate: now,
        endDate,
        durationDays: plan.durationDays,
        pricePaid: payment.amount,
        discountCode: payment.discountCode,
      },
    });

    // آپدیت فیلدهای پلن روی User (برای دسترسی سریع)
    await db.user.update({
      where: { id: user.id },
      data: {
        planName: plan.id,
        planExpiresAt: endDate,
        planStartedAt: now,
        // ریست شمارنده‌های استفاده هوش مصنوعی
        videoAnalysisUsed: 0,
        bloodTestUsed: 0,
      },
    });

    // ایجاد درخواست برنامه جدید با وضعیت "در حال تولید"
    const progReq = await db.programRequest.create({
      data: {
        userId: user.id,
        plan: plan.id,
        billingPeriod: "monthly",
        status: "generating",
        paymentId: payment.id,
      },
    });

    // اگر کد تخفیف استفاده شده، شمارش استفاده را افزایش بده
    if (payment.discountCode) {
      // اول در جدول کدهای اختصاصی کاربر بررسی کن
      const udc = await db.userDiscountCode.findUnique({ where: { code: payment.discountCode } });
      if (udc) {
        await db.userDiscountCode.update({
          where: { id: udc.id },
          data: { isUsed: true },
        });
      } else {
        // در غیر این صورت کد عمومی است
        await db.discountCode.updateMany({
          where: { code: payment.discountCode },
          data: { usedCount: { increment: 1 } },
        });
      }
    }

    // --- پردازش تولید برنامه بر اساس پلن ---
    // • Basic / Standard: تولید خودکار برنامه بلافاصله انجام می‌شود.
    // • Advanced: نیازمند عکس بدن قبل از تولید برنامه — وضعیت pending_body_photo
    // • Ultimate: نیازمند عکس بدن + ویدیو قبل از تولید برنامه — وضعیت pending_body_media
    const needsBodyPhoto = plan.id === "advanced" || plan.id === "ultimate";
    const needsBodyVideo = plan.id === "ultimate";

    let planGenerationOk = false;

    if (needsBodyPhoto) {
      // بدون تولید برنامه — منتظر ارسال مدیای بدن توسط کاربر
      const initialStatus = needsBodyVideo ? "pending_body_media" : "pending_body_photo";
      await db.programRequest.update({
        where: { id: progReq.id },
        data: { status: initialStatus },
      });

      const noticeBody = needsBodyVideo
        ? "برای دریافت برنامه اختصاصی، ابتدا عکس‌های بدن (۴ زاویه) و یک ویدیوی کوتاه از فرم حرکات خود را ارسال کنید. سپس فیتاپ هوشمند برنامه شما را طراحی می‌کند."
        : "برای دریافت برنامه اختصاصی، ابتدا عکس‌های بدن خود (۴ زاویه) را ارسال کنید. سپس فیتاپ هوشمند برنامه شما را طراحی می‌کند.";

      await db.notification.create({
        data: {
          userId: user.id,
          type: "system",
          title: needsBodyVideo ? "ارسال عکس و ویدیو بدن الزامی است 📸🎬" : "ارسال عکس بدن الزامی است 📸",
          body: noticeBody,
          link: "?tab=home",
          read: false,
        },
      });
    } else {
      // --- تولید خودکار برنامه تمرینی + غذایی توسط فیتاپ هوشمند ---
      // این کار را بلافاصله پس از خرید موفق انجام می‌دهیم تا کاربر برنامه‌اش را ببیند.
      try {
        const profile = await db.onboardingProfile.findUnique({ where: { userId: user.id } });
        if (profile) {
          // ساخت OnboardingData از پروفایل ذخیره‌شده
          const { generateWorkoutPlan, generateMealPlan } = await import("@/lib/fitness/ai");

          // local parsers (same as in onboarding route)
          const parseEquip = (raw: string | null | undefined): string[] => {
            if (!raw) return [];
            const t = raw.trim();
            if (!t) return [];
            try {
              const p = JSON.parse(t);
              if (Array.isArray(p)) return p.map((x) => String(x));
              if (typeof p === "string") return p.split(",").map((s) => s.trim()).filter(Boolean);
              return [];
            } catch {
              return t.split(",").map((s) => s.trim()).filter(Boolean);
            }
          };
          const parseList = (raw: string | null | undefined): string[] => {
            if (!raw) return [];
            const t = raw.trim();
            if (!t) return [];
            try {
              const p = JSON.parse(t);
              return Array.isArray(p) ? p.map((x) => String(x)) : [];
            } catch {
              return t.split(",").map((s) => s.trim()).filter(Boolean);
            }
          };

          const planData = {
            gender: profile.gender as any,
            age: profile.age,
            height: profile.height,
            weight: profile.weight,
            targetWeight: profile.targetWeight ?? undefined,
            goal: profile.goal as any,
            activityLevel: profile.activityLevel as any,
            workoutDays: profile.workoutDays,
            workoutDaysList: parseList(profile.workoutDaysList),
            workoutPlace: profile.workoutPlace as any,
            equipment: parseEquip(profile.equipment),
            diseases: profile.diseases,
            injuries: profile.injuries,
            allergies: profile.allergies,
            dietType: profile.dietType as any,
            trainingExperience: (profile.trainingExperience ?? undefined) as any,
            previousTrainingType: profile.previousTrainingType ?? undefined,
            drugAllergies: profile.drugAllergies ?? undefined,
            currentMedications: profile.currentMedications ?? undefined,
            maxLifts: profile.maxLifts ?? undefined,
          };

          // غیرفعال‌سازی برنامه‌های قبلی
          await db.workoutPlan.updateMany({ where: { userId: user.id }, data: { active: false } });
          await db.mealPlan.updateMany({ where: { userId: user.id }, data: { active: false } });

          // تولید موازی
          const [workout, meal] = await Promise.all([
            generateWorkoutPlan(planData, plan.id as any),
            generateMealPlan(planData, plan.id as any),
          ]);

          await db.workoutPlan.create({
            data: { userId: user.id, content: JSON.stringify(workout), active: true },
          });
          await db.mealPlan.create({
            data: { userId: user.id, content: JSON.stringify(meal), totalCal: meal.totalCalories, active: true },
          });

          // به‌روزرسانی وضعیت درخواست برنامه به "ready"
          await db.programRequest.update({
            where: { id: progReq.id },
            data: { status: "ready" },
          });

          planGenerationOk = true;

          // نوتیفیکیشن آماده شدن برنامه
          await db.notification.create({
            data: {
              userId: user.id,
              type: "achievement",
              title: "برنامه شما آماده شد! 🎯",
              body: "برنامه تمرینی و غذایی شخصی‌سازی‌شده شما توسط فیتاپ هوشمند ساخته شد. از بخش «تمرینات» و «تغذیه» مشاهده کنید.",
              link: "?tab=workouts",
              read: false,
            },
          });
        }
      } catch (genErr) {
        console.error("[payment/verify] plan generation failed:", genErr);
        // علامت‌گذاری درخواست به عنوان ناموفق ولی خرید موفق است
        await db.programRequest.update({
          where: { id: progReq.id },
          data: { status: "failed" },
        });
      }
    }

    // نوتیفیکیشن خرید موفق
    await db.notification.create({
      data: {
        userId: user.id,
        type: "subscription",
        title: "پلن شما فعال شد! ✅",
        body: `پلن ${plan.label} با موفقیت خریداری شد. تا ${endDate.toLocaleDateString("fa-IR")} فعال است.${planGenerationOk ? "" : " برنامه شما در حال آماده‌سازی است — در صورت تأخیر از بخش اشتراک دوباره تولید کنید."}`,
        link: "?tab=workouts",
        meta: JSON.stringify({ planId: plan.id, refId }),
        read: false,
      },
    });

    // --- پردازش پاداش معرفی به دوست‌دار ---
    // اگر کاربر با کد معرفی ثبت‌نام کرده و این اولین خرید پلن اوست،
    // به هر دو طرف (خریدار + معرف) ۱۵۰,۰۰۰ تومان پاداش داده می‌شود.
    try {
      await processReferralReward({
        buyerUserId: user.id,
        paymentId: payment.id,
      });
    } catch (refErr) {
      // خطا در پردازش پاداش نباید جلوی موفقیت خرید را بگیرد
      console.error("[payment/verify] referral reward failed:", refErr);
    }

    const updatedDto = await buildUserDto(user.id);

    return Response.json({
      success: true,
      status: "success",
      message: "پرداخت با موفقیت انجام شد.",
      refId,
      amount: payment.amount,
      originalAmount: payment.originalAmount,
      plan: plan.label,
      planId: plan.id,
      subscriptionEnd: endDate.toISOString(),
      walletBalance: newBalance,
      user: updatedDto,
    });
  } catch (e) {
    return apiError(e);
  }
}
