import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { createNotification, ensureRenewalDiscountCode } from "@/lib/fitness/notifications";

/**
 * GET /api/cron/behavioral?secret=CRON_SECRET
 *
 * Behavioral marketing cron endpoint. Runs three scenarios:
 *  1) Basic plan users → upgrade notification
 *  2) Plan expires within 3 days → renewal reminder (+ auto per-user discount code)
 *  3) Inactive for 5+ days → re-engagement notification
 *
 * Each scenario creates notifications in the DB (deduped by a per-scenario window).
 * The endpoint is protected by CRON_SECRET — must match the secret in the query string.
 *
 * Returns a JSON summary of how many notifications were created per scenario.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const secret = url.searchParams.get("secret");
  const expected = process.env.CRON_SECRET || "fitup-cron-secret-2025";

  if (secret !== expected) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const summary = {
    upgrade: 0,
    renewal: 0,
    reengagement: 0,
    total: 0,
    runAt: now.toISOString(),
  };

  // -------------------------------------------------------------------
  // Scenario 1: Users on basic plan → upgrade notification
  // Dedupe: don't send if they already got an "upgrade" notification in last 7 days
  // -------------------------------------------------------------------
  try {
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const basicUsers = await db.user.findMany({
      where: {
        planName: "basic",
        isBlocked: false,
      },
      select: { id: true },
    });
    for (const u of basicUsers) {
      const recent = await db.notification.findFirst({
        where: { userId: u.id, type: "upgrade", createdAt: { gt: sevenDaysAgo } },
        select: { id: true },
      });
      if (recent) continue;
      await createNotification(
        u.id,
        "upgrade",
        "ارتقای پلن — مسیر سریع‌تر به هدف! 🚀",
        "با پلن پیشرفته به چت نامحدود با مربی هوشمند، حالت باشگاه و آنالیز عکس غذا/بدن دسترسی پیدا کنید. همین حالا ارتقا دهید.",
        "?tab=plans",
        { scenario: "upgrade", fromPlan: "basic" }
      );
      summary.upgrade++;
    }
  } catch (err) {
    console.error("[cron/behavioral] upgrade scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 2: Plan expires within 3 days → renewal reminder
  // Also auto-generates a per-user 20% renewal discount code (if not exists).
  // Dedupe: don't send if they got a "renewal" notification in last 2 days.
  // -------------------------------------------------------------------
  try {
    const inThreeDays = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
    const twoDaysAgo = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);

    const expiringUsers = await db.user.findMany({
      where: {
        planExpiresAt: { gt: now, lt: inThreeDays },
        isBlocked: false,
      },
      select: { id: true, planName: true, mobile: true },
    });

    for (const u of expiringUsers) {
      const recent = await db.notification.findFirst({
        where: { userId: u.id, type: "renewal", createdAt: { gt: twoDaysAgo } },
        select: { id: true },
      });
      if (recent) continue;

      // Auto-generate per-user renewal discount code (FITAP15 = 15% off)
      const discount = await ensureRenewalDiscountCode(u.id, 15, 14);

      await createNotification(
        u.id,
        "renewal",
        "اشتراک شما به‌زودی منقضی می‌شود ⏰",
        discount
          ? `اشتراک ${u.planName ?? ""} شما در کمتر از ۳ روز منقضی می‌شود. با کد اختصاصی ${discount.code} (۱۵٪ تخفیف تمدید) همین حالا تمدید کنید.`
          : `اشتراک ${u.planName ?? ""} شما در کمتر از ۳ روز منقضی می‌شود. همین حالا تمدید کنید تا برنامه شما متوقف نشود.`,
        "?tab=plans",
        { scenario: "renewal", planName: u.planName, discountCode: discount?.code ?? null }
      );
      summary.renewal++;
    }
  } catch (err) {
    console.error("[cron/behavioral] renewal scenario failed:", err);
  }

  // -------------------------------------------------------------------
  // Scenario 3: Inactive for 5+ days → re-engagement notification
  // We use the most recent of: weight log, checkup, chat message, workout plan creation
  // to determine last activity. If no activity at all (or >5 days ago), send notification.
  // Dedupe: don't send if they got a "re_engagement" notification in last 7 days.
  // -------------------------------------------------------------------
  try {
    const fiveDaysAgo = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const candidates = await db.user.findMany({
      where: {
        isBlocked: false,
        onboardingDone: true,
        // Has any active or expired plan (engaged users)
        NOT: [{ planName: null }],
      },
      select: { id: true },
    });

    for (const u of candidates) {
      // Check for any recent notification to avoid spamming
      const recentNotif = await db.notification.findFirst({
        where: { userId: u.id, type: "re_engagement", createdAt: { gt: sevenDaysAgo } },
        select: { id: true },
      });
      if (recentNotif) continue;

      // Pull the most recent activity across multiple tables
      const [lastWeight, lastCheckup, lastChat, lastWorkoutPlan] = await Promise.all([
        db.weightLog.findFirst({
          where: { userId: u.id },
          orderBy: { loggedAt: "desc" },
          select: { loggedAt: true },
        }),
        db.checkup.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
        db.chatMessage.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
        db.workoutPlan.findFirst({
          where: { userId: u.id },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
      ]);

      const timestamps = [
        lastWeight?.loggedAt,
        lastCheckup?.createdAt,
        lastChat?.createdAt,
        lastWorkoutPlan?.createdAt,
      ]
        .filter(Boolean)
        .map((t) => new Date(t as Date).getTime());

      const lastActivity = timestamps.length ? Math.max(...timestamps) : 0;

      // If last activity is older than 5 days (or no activity at all), send re-engagement
      if (lastActivity === 0 || lastActivity < fiveDaysAgo.getTime()) {
        await createNotification(
          u.id,
          "re_engagement",
          "وقتشه برگردی به مسیر! 💪",
          "چند روزی نیستی فعال بودی. یه تمرین کوتاه همین امروز می‌تونه انگیزه‌ت رو برگردونه. مربی هوشمندت منتظره!",
          "?tab=workouts",
          { scenario: "re_engagement", daysSinceLastActivity: lastActivity ? Math.floor((now.getTime() - lastActivity) / (24 * 60 * 60 * 1000)) : null }
        );
        summary.reengagement++;
      }
    }
  } catch (err) {
    console.error("[cron/behavioral] re-engagement scenario failed:", err);
  }

  summary.total = summary.upgrade + summary.renewal + summary.reengagement;
  return Response.json({ ok: true, ...summary });
}
