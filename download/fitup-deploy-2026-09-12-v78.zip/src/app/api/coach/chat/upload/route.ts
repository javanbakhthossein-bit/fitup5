import { NextRequest } from "next/server";
import { unlink } from "fs/promises";
import { requirePlanCapability, apiError } from "@/lib/fitness/auth";
import { extractVideoFramesAsDataUrls } from "@/lib/fitness/ai";
import { rateLimit, rateLimitResponse } from "@/lib/fitness/rate-limit";
import { savePrivateMediaFile, absolutePathForUploadUrl } from "@/lib/fitness/private-media";
import { compressVideoFileInPlace, formatBytes } from "@/lib/fitness/media-compress";
import { checkQuota, incrementQuota } from "@/lib/fitness/quota";

/**
 * v70 — مسیر آپلود ویدیوی چت (Task 4-a) — قبلاً گمشده بود!
 *
 * کلاینت ویدیوهای ≥۱۲ مگابایت را به این مسیر می‌فرستد (uploadVideoWithProgress
 * در smart-coach-chat-view.tsx) و بعد از پاسخ، POST /api/coach/chat را با
 * videoUrl/videoFrames صدا می‌زند. تا امروز این route وجود نداشت → 404 →
 * کل مسیر ویدیوی بزرگ چت مربی شکسته بود (فقط ویدیوهای <۱۲MB کار می‌کردند).
 *
 * قرارداد (هم‌خوان با کلاینت):
 *   - POST multipart با فیلد «file»
 *   - پاسخ: { mediaUrl: string, frames: string[] } — فریم‌ها data URL تصویرند
 *
 * جریان: اعتبارسنجی پلن/سهمیه → ذخیرهٔ امن (الگوی نام chat-video-{uid}-… تا
 * validateChatVideoUrl در مسیر چت مالکیت را تأیید کند) → فشرده‌سازی درجا →
 * استخراج ۶ فریم با ffmpeg → مصرف سهمیه → پاسخ.
 *
 * نکته سهمیه: ثبت پیام ChatMessage فقط در POST /api/coach/chat انجام می‌شود
 * (اینجا ردیفی ساخته نمی‌شود تا اگر چت شکست خورد، پیام یتیم نسازد)؛ اما سهمیه
 * اینجا مصرف می‌شود چون پردازش سنگین (فشرده‌سازی+استخراج فریم) همین‌جا رخ می‌دهد.
 */

/**
 * گارد فنی حجم ویدیو (۲ گیگابایت) — دیرکتیو مالک: سقف کاربر-پسند حذف شد؛ کاربر
 * هر حجمی می‌فرستد و همین مسیر بعد از ذخیره با ffmpeg فشرده می‌کند و فقط نسخهٔ
 * فشرده نگه داشته می‌شود. این گارد فقط ضد درخواست‌های مخرب/OOM است (نادر).
 */
const MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024;
/** تعداد فریم کلیدی استخراج‌شده برای تحلیل چندوجهی */
const FRAME_COUNT = 6;

const EXT_BY_MIME: Record<string, string> = {
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/quicktime": "mov",
  "video/x-matroska": "mkv",
};

export async function POST(req: NextRequest) {
  try {
    // گیت پلن: ارسال ویدیو در چت فقط برای پلن حرفه‌ای (هم‌گام با مسیر چت)
    const { userId } = await requirePlanCapability("chatVideoUpload");

    // ─── محدودیت نرخ آپلود — ۱۰ آپلود در ۱۰ دقیقه (ضد سوءاستفاده) ───
    const rl = rateLimit(`coach-chat-upload:${userId}`, 10, 10 * 60_000);
    if (!rl.ok) {
      return rateLimitResponse(rl.retryAfterSec);
    }

    const form = await req.formData();
    const file = form.get("file");
    if (!file || !(file instanceof File)) {
      return Response.json(
        { error: "فایل ویدیویی پیدا نشد. لطفاً دوباره تلاش کن." },
        { status: 400 }
      );
    }

    // اعتبارسنجی نوع — فقط ویدیو
    const mime = file.type || "video/mp4";
    if (!mime.startsWith("video/")) {
      return Response.json(
        { error: "فقط فایل ویدیویی مجاز است." },
        { status: 400 }
      );
    }

    // گارد فنی حجم (نادر — پیام مهربان)
    if (file.size > MAX_UPLOAD_BYTES) {
      return Response.json(
        { error: "فایل بسیار بزرگ است. لطفاً ویدیوی کوتاه‌تری بفرستید." },
        { status: 413 }
      );
    }
    if (file.size === 0) {
      return Response.json(
        { error: "فایل ویدیو خالی است." },
        { status: 400 }
      );
    }

    // ─── سهمیهٔ ویدیوی حرکات — قبل از پردازش سنگین ───
    const quota = await checkQuota(userId, "movement_video");
    if (!quota.allowed) {
      return Response.json(
        { error: quota.messageFa ?? "سهمیهٔ ارسال ویدیو تمام شده است.", code: quota.code },
        { status: 429 }
      );
    }

    // ─── ذخیرهٔ امن فایل — الگوی نام حتماً chat-video-{uid}-… باشد ───
    // (مسیر چت با validateChatVideoUrl مالکیت را روی همین الگو تأیید می‌کند)
    const ext = EXT_BY_MIME[mime] || "mp4";
    const fileName = `chat-video-${userId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    const { url: videoUrl } = await savePrivateMediaFile("chat", fileName, buffer);
    const filePath = absolutePathForUploadUrl(videoUrl);

    // ─── فشرده‌سازی درجا (همیشه نسخهٔ کم‌حجم نگه داشته می‌شود — قانون مالک) ───
    // هرگز throw نمی‌کند؛ در شکست نسخهٔ اصلی می‌ماند.
    try {
      const cmp = await compressVideoFileInPlace(filePath);
      if (cmp.compressed) {
        console.log(`[chat-upload] video compressed: ${formatBytes(cmp.sizeBefore)} → ${formatBytes(cmp.sizeAfter)}`);
      }
    } catch (cmpErr) {
      console.error("[chat-upload] compression step failed (keeping original):", cmpErr);
    }

    // ─── استخراج ۶ فریم کلیدی برای تحلیل چندوجهی مربی ───
    let frames: string[] = [];
    try {
      frames = await extractVideoFramesAsDataUrls(filePath, FRAME_COUNT);
    } catch (frameErr) {
      console.error("[chat-upload] frame extraction failed:", frameErr);
    }

    if (frames.length === 0) {
      // بدون فریم، تحلیل چندوجهی بی‌معناست — پاک‌سازی فایل و رد
      try {
        await unlink(filePath);
      } catch {}
      return Response.json(
        { error: "پردازش ویدیو ناموفق بود. فرمت ویدیو را چک کن یا ویدیوی کوتاه‌تری بفرست." },
        { status: 400 }
      );
    }

    // مصرف سهمیه — فریم‌ها آماده شدند (فایل + فریم‌ها در مسیر چت استفاده می‌شوند)
    await incrementQuota(userId, "movement_video");

    // ثبت خلاصه در لاگ برای مانیتورینگ حجم آپلودها
    console.log(`[chat-upload] user=${userId} size=${formatBytes(buffer.length)} frames=${frames.length} url=${videoUrl}`);

    return Response.json({ mediaUrl: videoUrl, frames });
  } catch (e) {
    return apiError(e);
  }
}
