"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ClipboardCheck,
  Plus,
  Ruler,
  Scale,
  Activity,
  Sparkles,
  Loader2,
  TrendingUp,
  Brain,
  ChevronDown,
  ChevronUp,
  Award,
  Target,
  Moon,
  Utensils,
  Dumbbell,
  Lock,
  CheckCircle2,
  Clock,
  Hourglass,
} from "lucide-react";
import { useAppStore } from "@/lib/fitness/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  canAccess,
  toPersianDigits,
  PLAN_LABELS,
} from "@/lib/fitness/types";
import { toast } from "sonner";

interface AiAnalysis {
  bodyScore?: number;
  bodyFatStatus?: string;
  analysis?: string;
  recommendations?: string[];
  nextPhaseFocus?: string;
  // v73.2 — به‌روزرسانی برنامه با پیشرفت کاربر (تصمیم هوش مصنوعی چکاپ)
  programUpdateNeeded?: boolean;
  programUpdateNotes?: string;
}

interface CheckupDto {
  id: string;
  phaseNumber: number;
  isFinalCheckup: boolean;
  status: string;
  weight: number;
  chestMeasurement: number | null;
  armMeasurement: number | null;
  waistMeasurement: number | null;
  hipMeasurement: number | null;
  thighMeasurement: number | null;
  neckMeasurement: number | null;
  bodyFatPercent: number | null;
  leanBodyMass: number | null;
  fatigueLevel: number;
  sleepQuality: number;
  dietAdherence: number;
  workoutAdherence: number;
  phaseCompleted: boolean;
  notes: string;
  aiAnalysis: AiAnalysis | null;
  coachNotes: string | null;
  createdAt: string;
  updatedAt: string;
}

interface PhaseSchedule {
  phase: number;
  dueDays: number;
  dueAt: string | null;
  isDue: boolean;
  daysUntil: number | null;
  submitted: boolean;
}

interface CheckupSchedule {
  planStartedAt: string | null;
  phases: PhaseSchedule[];
  phase0: {
    exists: boolean;
    hasMeasurements: boolean;
    createdAt: string | null;
    weight: number | null;
  };
}

const PHASE_TITLE = ["", "اول", "دوم", "سوم (نهایی)"];

export function CheckupSection() {
  const { user } = useAppStore();
  const [checkups, setCheckups] = useState<CheckupDto[]>([]);
  const [schedule, setSchedule] = useState<CheckupSchedule | null>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showBaselineForm, setShowBaselineForm] = useState(false);
  // فازی که فرم چکاپ برایش باز شده (وقتی زمانش رسیده)
  const [formPhase, setFormPhase] = useState(1);

  const hasAccess = canAccess(user?.planName, "periodicCheckups");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/checkup", { cache: "no-store" });
      const data = await res.json();
      setCheckups(data.checkups || []);
      setSchedule(data.schedule || null);
    } catch {
    } finally {
      setLoading(false);
    }
  }

  // ─── v15: منطق زمان‌بندی ───
  // فاز صفر: «در انتظار وارد کردن اندازه‌های بدن» تا وقتی اندازه‌ها وارد شوند
  const phase0 = checkups.find((c) => c.phaseNumber === 0) ?? null;
  const phase0NeedsMeasurements = schedule
    ? !schedule.phase0.hasMeasurements
    : true;

  // اولین فازِ رسیده که هنوز ثبت نشده → دکمه «ثبت چکاپ» فقط برای آن فعال است
  const duePendingPhase = schedule?.phases.find((p) => p.isDue && !p.submitted) ?? null;

  const latestScore = checkups.find((c) => c.aiAnalysis)?.aiAnalysis?.bodyScore ?? null;
  const scoreTrend =
    checkups
      .filter((c) => c.aiAnalysis?.bodyScore != null)
      .slice(0, 2)
      .map((c) => c.aiAnalysis!.bodyScore!)
      .reverse() ?? [];

  return (
    <Card id="checkup-section" className="p-5 bg-white border-2 border-orange-200 shadow-sm scroll-mt-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            <ClipboardCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">چکاپ دوره‌ای</h3>
            <p className="text-[11px] text-slate-500">
              {hasAccess
                ? duePendingPhase
                  ? `چکاپ ${PHASE_TITLE[duePendingPhase.phase] ?? ""} رسیده — ثبتش کن`
                  : `فاز فعلی: ${toPersianDigits(Math.min(3, (schedule?.phases.filter((p) => p.submitted).length || 0) + 1))} از ${toPersianDigits(3)}`
                : "نیازمند پلن استاندارد یا بالاتر"}
            </p>
          </div>
        </div>
        {/* v15: دکمه «ثبت چکاپ» فقط وقتی زمانش رسیده فعال است (درخواست مالک:
            «دکمه ثبت چکاپ نباید همیشه فعال باشه و فقط وقتی نیازه و موقعش
            رسیده باید فعال باشه») */}
        {hasAccess && duePendingPhase && (
          <Button
            size="sm"
            onClick={() => {
              setFormPhase(duePendingPhase.phase);
              setShowForm(true);
            }}
            className="rounded-xl text-white animate-pulse shadow-md"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            <Plus className="w-4 h-4" />
            ثبت چکاپ
          </Button>
        )}
      </div>

      {!hasAccess ? (
        <div className="rounded-2xl p-4 text-center bg-orange-50 border border-orange-200">
          <LockMessage />
        </div>
      ) : loading ? (
        <div className="space-y-2">
          <Skeleton className="h-20 rounded-xl" />
          <Skeleton className="h-14 rounded-xl" />
        </div>
      ) : (
        <>
          {/* ═══ فاز صفر — اندازه‌های اولیه بدن ═══ */}
          {phase0NeedsMeasurements ? (
            /* حالت «در انتظار وارد کردن اندازه‌های بدن» — متن دقیق درخواست مالک */
            <div className="rounded-2xl p-4 mb-3 bg-amber-50 border-2 border-amber-300">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-amber-400/90 shrink-0">
                  <Ruler className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-amber-900">فاز صفر — اندازه‌های اولیه</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200/70 text-amber-800 font-bold flex items-center gap-1">
                      <Hourglass className="w-3 h-3" /> در انتظار وارد کردن اندازه‌های بدن
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed mt-1.5">
                    شما هنوز اندازه‌های بدن خود را وارد نکردید. با ثبت اندازه‌های اولیه، فاز صفر
                    تکمیل می‌شود و هوش مصنوعی تحلیل اولیه شما را می‌نویسد.
                  </p>
                  <Button
                    size="sm"
                    onClick={() => setShowBaselineForm(true)}
                    className="rounded-xl text-white mt-2.5 gap-1.5"
                    style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                  >
                    <Ruler className="w-3.5 h-3.5" /> وارد کردن اندازه‌های بدن
                  </Button>
                </div>
              </div>
            </div>
          ) : phase0 ? (
            /* اندازه‌ها وارد شده → کارت فاز صفر تکمیل‌شده + تحلیل AI (۲-۳ خط) */
            <div className="rounded-2xl p-4 mb-3 bg-emerald-50/70 border border-emerald-200">
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
                    <Ruler className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-xs font-bold text-slate-900">فاز صفر — اندازه‌های اولیه</p>
                </div>
                <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5" /> تکمیل شد
                </span>
              </div>
              {/* خلاصه اندازه‌ها */}
              <div className="grid grid-cols-4 gap-1.5 mb-2">
                <MiniStat label="وزن" value={`${toPersianDigits(phase0.weight)} kg`} />
                {phase0.bodyFatPercent != null && (
                  <MiniStat label="چربی" value={`${toPersianDigits(phase0.bodyFatPercent)}٪`} />
                )}
                {phase0.waistMeasurement != null && (
                  <MiniStat label="کمر" value={toPersianDigits(phase0.waistMeasurement)} />
                )}
                {phase0.armMeasurement != null && (
                  <MiniStat label="بازو" value={toPersianDigits(phase0.armMeasurement)} />
                )}
              </div>
              {/* تحلیل AI فاز صفر */}
              {phase0.aiAnalysis?.analysis ? (
                <div className="rounded-xl bg-white p-2.5 border border-orange-100">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Brain className="w-3.5 h-3.5 text-orange-500" />
                    <p className="text-[11px] font-bold text-slate-800">تحلیل هوش مصنوعی فاز صفر</p>
                  </div>
                  <p className="text-[11px] text-slate-700 leading-relaxed">
                    {phase0.aiAnalysis.analysis}
                  </p>
                  {(phase0.aiAnalysis.recommendations?.length ?? 0) > 0 && (
                    <ul className="space-y-0.5 mt-1.5">
                      {phase0.aiAnalysis.recommendations!.slice(0, 2).map((r, i) => (
                        <li key={i} className="text-[10px] text-slate-600 flex items-start gap-1">
                          <Sparkles className="w-2.5 h-2.5 text-orange-400 mt-0.5 shrink-0" />
                          {r}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <p className="text-[10px] text-slate-500 bg-white/60 rounded-lg p-2">
                  تحلیل هوش مصنوعی پس از ورود اندازه‌ها تولید می‌شود؛ اگر چند لحظه صبر کنی و
                  صفحه را رفرش کنی اینجا نمایش داده می‌شود.
                </p>
              )}
            </div>
          ) : null}

          {/* Body Score gauge */}
          {latestScore != null && (
            <div className="rounded-2xl p-4 mb-3 bg-gradient-to-l from-amber-50 to-orange-50 border border-orange-200">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-orange-500" />
                  <span className="text-xs font-bold text-slate-700">امتیاز بدن</span>
                </div>
                {scoreTrend.length === 2 && (
                  <span className="text-[11px] flex items-center gap-1 text-emerald-600">
                    <TrendingUp className="w-3 h-3" />
                    {toPersianDigits(scoreTrend[1] - scoreTrend[0] >= 0 ? "+" : "")}
                    {toPersianDigits(scoreTrend[1] - scoreTrend[0])}
                  </span>
                )}
              </div>
              <div className="flex items-end gap-2">
                <span
                  className="text-4xl font-black"
                  style={{
                    background: "linear-gradient(135deg, #f59e0b, #f97316)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {toPersianDigits(latestScore)}
                </span>
                <span className="text-sm text-slate-500 mb-1">از ۱۰۰</span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-orange-100 overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: "linear-gradient(to left, #f59e0b, #f97316)" }}
                  initial={{ width: 0 }}
                  animate={{ width: `${latestScore}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </div>
            </div>
          )}

          {/* ═══ خط زمانی فازهای ۱ تا ۳ — v15 ═══ */}
          {/* هر کارت: رسیده (فعال + دکمه) / ثبت‌شده / قفل با شمارش معکوس */}
          {schedule && (
            <div className="space-y-2 mb-3">
              {schedule.phases.map((p) => {
                if (p.submitted) {
                  const ck = checkups.find((c) => c.phaseNumber === p.phase);
                  if (ck) return <CheckupHistoryItem key={ck.id} checkup={ck} />;
                  return null;
                }
                if (p.isDue) {
                  /* زمانش رسیده — کارت فعال «در انتظار وارد کردن اندازه‌ها» */
                  return (
                    <div
                      key={p.phase}
                      className="rounded-2xl p-3.5 border-2 border-orange-400 bg-gradient-to-l from-orange-50 to-amber-50 shadow-sm"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0"
                            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                          >
                            <ClipboardCheck className="w-4.5 h-4.5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-900">
                              چکاپ {PHASE_TITLE[p.phase]} (فاز {toPersianDigits(p.phase)})
                            </p>
                            <p className="text-[10px] text-orange-700 font-medium">
                              زمان چکاپ رسیده — در انتظار وارد کردن اندازه‌های بدن
                            </p>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => {
                            setFormPhase(p.phase);
                            setShowForm(true);
                          }}
                          className="rounded-xl text-white shrink-0 gap-1"
                          style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                        >
                          <Ruler className="w-3.5 h-3.5" /> وارد کردن اندازه‌ها
                        </Button>
                      </div>
                    </div>
                  );
                }
                /* هنوز نرسیده — قفل با شمارش معکوس */
                const days = p.daysUntil ?? 0;
                return (
                  <div
                    key={p.phase}
                    className="rounded-2xl p-3 border border-dashed border-slate-200 bg-slate-50/70 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-500">
                          چکاپ {PHASE_TITLE[p.phase]} (فاز {toPersianDigits(p.phase)})
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {p.dueAt
                            ? `روز ${toPersianDigits(p.dueDays)} دوره • ${toPersianDigits(Math.max(0, days))} روز تا فعال‌شدن`
                            : "پس از فعال‌شدن پلن زمان‌بندی می‌شود"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-slate-400 shrink-0" aria-hidden>
                      <Clock className="w-4 h-4" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* چکاپ‌های ثبت‌شده قدیمی (فقط تاریخچه — بدون فاز ۰ که بالا رندر شد) */}
          {(() => {
            const history = checkups.filter((c) => c.phaseNumber > 0);
            if (!schedule) {
              // schedule در دسترس نیست (نسخه قدیمی سرور) — همان لیست ساده
              return history.length === 0 ? (
                <div className="rounded-2xl p-6 text-center bg-slate-50 border border-dashed border-slate-200">
                  <ClipboardCheck className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                  <p className="text-sm text-slate-500">هنوز چکاپی ثبت نشده</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    با ثبت چکاپ دوره‌ای، هوش مصنوعی پیشرفت شما را تحلیل می‌کند.
                  </p>
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto custom-scrollbar">
                  {history.map((c) => (
                    <CheckupHistoryItem key={c.id} checkup={c} />
                  ))}
                </div>
              );
            }
            return null;
          })()}
        </>
      )}

      {/* Submit form — چکاپ فاز ۱-۳ */}
      {showForm && (
        <CheckupFormDialog
          phaseNumber={formPhase}
          onClose={() => setShowForm(false)}
          onSubmitted={() => {
            setShowForm(false);
            load();
          }}
        />
      )}

      {/* v15: فرم اندازه‌های اولیه — فاز صفر */}
      {showBaselineForm && (
        <BaselineMeasurementsDialog
          onClose={() => setShowBaselineForm(false)}
          onSaved={() => {
            setShowBaselineForm(false);
            load();
            toast.success("فاز صفر تکمیل شد! تحلیل هوش مصنوعی برایش تولید شد ✨");
          }}
        />
      )}
    </Card>
  );
}

function LockMessage() {
  const { setMainTab } = useAppStore();
  return (
    <div className="space-y-2">
      <p className="text-sm text-slate-700 font-medium">
        قابلیت چکاپ دوره‌ای در پلن شما فعال نیست.
      </p>
      <p className="text-[11px] text-slate-500">
        برای رصد پیشرفت با تحلیل هوش مصنوعی، به پلن استاندارد یا بالاتر ارتقا دهید.
      </p>
      <Button
        size="sm"
        onClick={() => setMainTab("plans")}
        className="rounded-xl text-white mt-1"
        style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
      >
        ارتقا به پلن استاندارد
      </Button>
    </div>
  );
}

function CheckupHistoryItem({ checkup }: { checkup: CheckupDto }) {
  const [expanded, setExpanded] = useState(false);
  const date = new Date(checkup.createdAt).toLocaleDateString("fa-IR", {
    month: "short",
    day: "numeric",
  });
  return (
    <div className="rounded-xl border border-orange-200 bg-white overflow-hidden">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between p-3 hover:bg-orange-50 transition"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center">
            <span className="text-xs font-bold text-orange-600">{toPersianDigits(checkup.phaseNumber)}</span>
          </div>
          <div className="text-right">
            <p className="text-xs font-bold text-slate-900">
              فاز {toPersianDigits(checkup.phaseNumber)}
              {checkup.isFinalCheckup && " (نهایی)"}
            </p>
            <p className="text-[10px] text-slate-500">
              {date} • {toPersianDigits(checkup.weight)} kg
              {checkup.bodyFatPercent != null && ` • ${toPersianDigits(checkup.bodyFatPercent)}٪ چربی`}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {checkup.aiAnalysis && (
            <span
              className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
            >
              {toPersianDigits(checkup.aiAnalysis.bodyScore ?? 0)}/۱۰۰
            </span>
          )}
          {/* v15: وضعیت دقیق — نه «در انتظار مربی» برای همه */}
          {checkup.aiAnalysis ? (
            <span className="text-[10px] text-emerald-600 flex items-center gap-0.5">
              <CheckCircle2 className="w-3 h-3" /> تحلیل AI
            </span>
          ) : checkup.status === "completed" ? (
            <span className="text-[10px] text-emerald-600 flex items-center gap-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> تأیید مربی
            </span>
          ) : (
            <span className="text-[10px] text-amber-600">در انتظار تحلیل</span>
          )}
          {expanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-orange-100 bg-orange-50/30 p-3 space-y-3"
          >
            {/* Measurements */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <MiniStat label="وزن" value={`${toPersianDigits(checkup.weight)} kg`} />
              {checkup.bodyFatPercent != null && (
                <MiniStat label="چربی بدن" value={`${toPersianDigits(checkup.bodyFatPercent)}٪`} />
              )}
              {checkup.leanBodyMass != null && (
                <MiniStat label="جرم خالص" value={`${toPersianDigits(checkup.leanBodyMass)} kg`} />
              )}
              {checkup.waistMeasurement != null && (
                <MiniStat label="کمر" value={`${toPersianDigits(checkup.waistMeasurement)}`} />
              )}
              {checkup.neckMeasurement != null && (
                <MiniStat label="گردن" value={`${toPersianDigits(checkup.neckMeasurement)}`} />
              )}
              {checkup.armMeasurement != null && (
                <MiniStat label="بازو" value={`${toPersianDigits(checkup.armMeasurement)}`} />
              )}
              {checkup.chestMeasurement != null && (
                <MiniStat label="سینه" value={`${toPersianDigits(checkup.chestMeasurement)}`} />
              )}
              {checkup.hipMeasurement != null && (
                <MiniStat label="باسن" value={`${toPersianDigits(checkup.hipMeasurement)}`} />
              )}
              {checkup.thighMeasurement != null && (
                <MiniStat label="ران" value={`${toPersianDigits(checkup.thighMeasurement)}`} />
              )}
            </div>

            {/* Adherence bars */}
            <div className="space-y-1.5">
              <AdherenceBar icon={Dumbbell} label="پیروی از تمرین" value={checkup.workoutAdherence} />
              <AdherenceBar icon={Utensils} label="پیروی از رژیم" value={checkup.dietAdherence} />
              <AdherenceBar icon={Moon} label="کیفیت خواب" value={checkup.sleepQuality} />
              <AdherenceBar icon={Activity} label="سطح خستگی" value={checkup.fatigueLevel} />
            </div>

            {checkup.notes && (
              <div className="rounded-lg bg-white p-2 border border-orange-100">
                <p className="text-[11px] text-slate-600">{checkup.notes}</p>
              </div>
            )}

            {/* AI Analysis */}
            {checkup.aiAnalysis ? (
              <div className="rounded-xl bg-white p-3 border-2 border-orange-200">
                <div className="flex items-center gap-1.5 mb-2">
                  <div
                    className="w-6 h-6 rounded-lg flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
                  >
                    <Brain className="w-3.5 h-3.5 text-white" />
                  </div>
                  <p className="text-xs font-bold text-slate-900">تحلیل هوش مصنوعی</p>
                </div>
                <p className="text-[11px] text-slate-700 leading-relaxed mb-2">{checkup.aiAnalysis.analysis}</p>
                {(checkup.aiAnalysis.recommendations?.length ?? 0) > 0 && (
                  <ul className="space-y-1 mb-2">
                    {checkup.aiAnalysis.recommendations!.map((r, i) => (
                      <li key={i} className="text-[11px] text-slate-600 flex items-start gap-1">
                        <Sparkles className="w-3 h-3 text-orange-500 mt-0.5 shrink-0" />
                        {r}
                      </li>
                    ))}
                  </ul>
                )}
                {checkup.aiAnalysis.nextPhaseFocus && (
                  <div className="text-[10px] text-orange-600 font-medium bg-orange-50 rounded-md p-2">
                    🎯 تمرکز فاز بعد: {checkup.aiAnalysis.nextPhaseFocus}
                  </div>
                )}
                {/* v73.2 — به‌روزرسانی برنامه با پیشرفت شما (استاندارد+) */}
                {checkup.aiAnalysis.programUpdateNeeded ? (
                  <div className="mt-2 text-[10px] font-medium text-emerald-700 bg-emerald-50 rounded-md p-2">
                    🔄 به‌روزرسانی برنامه‌ها با پیشرفت شما: برنامه‌های تمرینی و غذایی شما بر اساس نتیجهٔ همین چکاپ به‌روزرسانی می‌شود{checkup.aiAnalysis.programUpdateNotes ? ` — ${checkup.aiAnalysis.programUpdateNotes}` : ""} (برنامهٔ جدید در جای برنامهٔ فعلی می‌نشیند و پلن و زمان اشتراک شما تغییری نمی‌کند).
                  </div>
                ) : (
                  <div className="mt-2 text-[10px] text-slate-500 bg-slate-50 rounded-md p-2">
                    ✅ برنامهٔ فعلی مناسب روند پیشرفت شما است — ادامه بده!
                  </div>
                )}
              </div>
            ) : (
              <div className="rounded-lg bg-amber-50 p-2 text-[11px] text-amber-700">
                تحلیل هوش مصنوعی هنوز آماده نشده است.
              </div>
            )}

            {/* Coach notes */}
            {checkup.coachNotes && (
              <div className="rounded-lg bg-emerald-50 p-2 border border-emerald-200">
                <p className="text-[10px] text-emerald-700 font-bold mb-1">یادداشت مربی</p>
                <p className="text-[11px] text-slate-700">{checkup.coachNotes}</p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white p-1.5 border border-orange-100">
      <p className="text-[9px] text-slate-500">{label}</p>
      <p className="text-xs font-bold text-slate-900">{value}</p>
    </div>
  );
}

function AdherenceBar({ icon: Icon, label, value }: { icon: any; label: string; value: number }) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="w-3 h-3 text-slate-400 shrink-0" />
      <span className="text-[10px] text-slate-600 w-20 shrink-0">{label}</span>
      <div className="flex-1 flex gap-0.5">
        {[1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className="h-1.5 flex-1 rounded-full"
            style={{
              background: i <= value
                ? "linear-gradient(to left, #f59e0b, #f97316)"
                : "rgba(245, 158, 11, 0.15)",
            }}
          />
        ))}
      </div>
      <span className="text-[10px] font-bold text-slate-700 w-4 text-center">{toPersianDigits(value)}</span>
    </div>
  );
}

/** ─── v15: فرم اندازه‌های اولیه — فاز صفر ─── */
function BaselineMeasurementsDialog({
  onClose,
  onSaved,
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const [weight, setWeight] = useState("");
  const [waist, setWaist] = useState("");
  const [neck, setNeck] = useState("");
  const [hip, setHip] = useState("");
  const [chest, setChest] = useState("");
  const [arm, setArm] = useState("");
  const [thigh, setThigh] = useState("");
  const [saving, setSaving] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);

  const hasAny = Boolean(weight || waist || neck || hip || chest || arm || thigh);

  async function submit() {
    if (!hasAny) {
      toast.error("حداقل وزن یا یکی از اندازه‌ها را وارد کنید");
      return;
    }
    setSaving(true);
    try {
      const payload: Record<string, number> = {};
      if (weight) payload.weight = Number(weight);
      if (waist) payload.waistMeasurement = Number(waist);
      if (neck) payload.neckMeasurement = Number(neck);
      if (hip) payload.hipMeasurement = Number(hip);
      if (chest) payload.chestMeasurement = Number(chest);
      if (arm) payload.armMeasurement = Number(arm);
      if (thigh) payload.thighMeasurement = Number(thigh);
      const res = await fetch("/api/checkup/baseline-measurements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در ذخیره اندازه‌ها");
      setAiResult(data?.aiAnalysis?.analysis || null);
      toast.success("اندازه‌های اولیه ثبت شد — فاز صفر تکمیل شد ✅");
      // اگر تحلیل AI آماده بود، لحظه‌ای نمایشش بده بعد ببند
      if (data?.aiAnalysis?.analysis) {
        setTimeout(() => onSaved(), 1200);
      } else {
        onSaved();
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ذخیره اندازه‌ها");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-md bg-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-slate-900">
            <Ruler className="w-5 h-5 text-orange-500" />
            اندازه‌های اولیه بدن (فاز صفر)
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
            <p className="text-[11px] text-amber-800 leading-relaxed">
              این اندازه‌ها نقطه شروع مسیر شما هستند؛ هوش مصنوعی با مقایسه چکاپ‌های بعدی با
              همین عدد‌ها پیشرفت شما را می‌سنجد. با ثبت، تحلیل اولیه فاز صفر نوشته می‌شود.
            </p>
          </div>

          {/* وزن */}
          <div>
            <Label className="mb-1.5 block text-sm text-slate-700 flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-orange-500" /> وزن (کیلوگرم)
            </Label>
            <Input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="مثلاً ۷۵"
              dir="ltr"
              className="rounded-xl text-center text-lg h-11"
              inputMode="decimal"
            />
          </div>

          <div>
            <Label className="mb-2 block text-sm text-slate-700 flex items-center gap-1">
              <Ruler className="w-3.5 h-3.5 text-orange-500" /> اندازه‌ها (cm)
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <MeasureInput label="دور کمر" value={waist} onChange={setWaist} />
              <MeasureInput label="دور گردن" value={neck} onChange={setNeck} />
              <MeasureInput label="دور باسن" value={hip} onChange={setHip} />
              <MeasureInput label="دور سینه" value={chest} onChange={setChest} />
              <MeasureInput label="دور بازو" value={arm} onChange={setArm} />
              <MeasureInput label="دور ران" value={thigh} onChange={setThigh} />
            </div>
          </div>

          {aiResult && (
            <div className="p-3 rounded-xl bg-orange-50 border border-orange-200">
              <p className="text-[11px] font-bold text-orange-700 mb-1 flex items-center gap-1">
                <Brain className="w-3.5 h-3.5" /> تحلیل هوش مصنوعی فاز صفر:
              </p>
              <p className="text-[11px] text-slate-700 leading-relaxed">{aiResult}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving} className="rounded-xl">
            انصراف
          </Button>
          <Button
            onClick={submit}
            disabled={saving || !hasAny}
            className="rounded-xl text-white"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            {saving ? (
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> ثبت و تحلیل...
              </span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> ثبت و تحلیل با AI
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CheckupFormDialog({
  phaseNumber,
  onClose,
  onSubmitted,
}: {
  phaseNumber: number;
  onClose: () => void;
  onSubmitted: () => void;
}) {
  const [weight, setWeight] = useState("");
  const [chest, setChest] = useState("");
  const [arm, setArm] = useState("");
  const [waist, setWaist] = useState("");
  const [hip, setHip] = useState("");
  const [thigh, setThigh] = useState("");
  const [neck, setNeck] = useState("");
  const [fatigue, setFatigue] = useState(3);
  const [sleep, setSleep] = useState(3);
  const [diet, setDiet] = useState(3);
  const [workout, setWorkout] = useState(3);
  const [phaseCompleted, setPhaseCompleted] = useState(false);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!weight) {
      toast.error("وزن را وارد کنید");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/checkup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          weight: Number(weight),
          phaseNumber,
          chestMeasurement: chest ? Number(chest) : undefined,
          armMeasurement: arm ? Number(arm) : undefined,
          waistMeasurement: waist ? Number(waist) : undefined,
          hipMeasurement: hip ? Number(hip) : undefined,
          thighMeasurement: thigh ? Number(thigh) : undefined,
          neckMeasurement: neck ? Number(neck) : undefined,
          fatigueLevel: fatigue,
          sleepQuality: sleep,
          dietAdherence: diet,
          workoutAdherence: workout,
          phaseCompleted,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast.success("چکاپ ثبت شد و توسط هوش مصنوعی تحلیل شد! 🎉");
      onSubmitted();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ثبت چکاپ");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent dir="rtl" className="max-w-md bg-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-slate-900">
            <ClipboardCheck className="w-5 h-5 text-orange-500" />
            ثبت چکاپ فاز {toPersianDigits(phaseNumber)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Weight */}
          <div>
            <Label className="mb-1.5 block text-sm text-slate-700 flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-orange-500" /> وزن (کیلوگرم) *
            </Label>
            <Input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="مثلاً ۷۵"
              dir="ltr"
              className="rounded-xl text-center text-lg h-11"
              inputMode="decimal"
            />
          </div>

          {/* Measurements */}
          <div>
            <Label className="mb-2 block text-sm text-slate-700 flex items-center gap-1">
              <Ruler className="w-3.5 h-3.5 text-orange-500" /> اندازه‌های بدن (cm) — اختیاری
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <MeasureInput label="دور سینه" value={chest} onChange={setChest} />
              <MeasureInput label="دور بازو" value={arm} onChange={setArm} />
              <MeasureInput label="دور کمر *" value={waist} onChange={setWaist} />
              <MeasureInput label="دور گردن *" value={neck} onChange={setNeck} />
              <MeasureInput label="دور باسن" value={hip} onChange={setHip} />
              <MeasureInput label="دور ران" value={thigh} onChange={setThigh} />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              برای محاسبه دقیق‌تر درصد چربی بدن با فرمول علمی US Navy، دور کمر و گردن (برای خانم‌ها دور باسن هم) را وارد کنید.
            </p>
          </div>

          {/* Adherence sliders */}
          <div className="space-y-3">
            <Label className="block text-sm text-slate-700 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-orange-500" /> بازخورد وضعیت (۱ تا ۵)
            </Label>
            <FeedbackSlider icon={Dumbbell} label="پیروی از تمرین" value={workout} onChange={setWorkout} />
            <FeedbackSlider icon={Utensils} label="پیروی از رژیم" value={diet} onChange={setDiet} />
            <FeedbackSlider icon={Moon} label="کیفیت خواب" value={sleep} onChange={setSleep} />
            <FeedbackSlider icon={Activity} label="سطح خستگی" value={fatigue} onChange={setFatigue} />
          </div>

          {/* Notes */}
          <div>
            <Label className="mb-1.5 block text-sm text-slate-700">یادداشت (اختیاری)</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="هر چیزی که مربی هوشمند باید بداند..."
              className="rounded-xl text-sm"
              rows={2}
            />
          </div>

          {/* Phase completed toggle */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={phaseCompleted}
              onChange={(e) => setPhaseCompleted(e.target.checked)}
              className="w-4 h-4 rounded accent-orange-500"
            />
            <span className="text-sm text-slate-700 flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-orange-500" /> این فاز را کامل کرده‌ام
            </span>
          </label>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving} className="rounded-xl">
            انصراف
          </Button>
          <Button
            onClick={submit}
            disabled={saving || !weight}
            className="rounded-xl text-white"
            style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
          >
            {saving ? (
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> در حال تحلیل...
              </span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> ثبت و تحلیل با AI
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MeasureInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <Label className="mb-1 block text-[11px] text-slate-500">{label}</Label>
      <Input
        dir="ltr"
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-lg text-center text-sm h-9"
        inputMode="decimal"
      />
    </div>
  );
}

function FeedbackSlider({
  icon: Icon,
  label,
  value,
  onChange,
}: {
  icon: any;
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-slate-600 flex items-center gap-1">
          <Icon className="w-3 h-3 text-slate-400" /> {label}
        </span>
        <span
          className="text-xs font-bold px-2 py-0.5 rounded-md text-white"
          style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
        >
          {toPersianDigits(value)}
        </span>
      </div>
      <Slider
        dir="rtl"
        value={[value]}
        onValueChange={(v) => onChange(v[0])}
        min={1}
        max={5}
        step={1}
        className="[&_[role=slider]]:bg-orange-500 [&_.bg-primary]:bg-orange-200"
      />
    </div>
  );
}
